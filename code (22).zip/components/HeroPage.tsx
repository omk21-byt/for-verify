import ScrollHero from "@/components/ScrollHero";

export default function HeroPage() {
  return (
    <ScrollHero>
      <div className="flex flex-col items-center justify-center h-full text-white bg-gradient-to-br from-purple-600 to-blue-500">
        <h1 className="text-5xl font-bold mb-4">Welcome to Shiftza</h1>
        <p className="text-lg max-w-md text-center">
          Smart automation for creative teams.
        </p>
      </div>
    </ScrollHero>
  );
}
