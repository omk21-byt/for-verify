"use client"

import { PromptInputBox } from "@/components/ui/ai-prompt-box"
import { cn } from "@/lib/utils"

export function DashboardPreview() {
  return (
    <section className="-mt-10">
      <div
        className={cn(
          "relative mx-auto max-w-5xl overflow-hidden rounded-3xl border shadow-md p-4 bg-transparent px-1.5 py-1.5"
        )}
      >
        <PromptInputBox />
      </div>
    </section>
  )
}
