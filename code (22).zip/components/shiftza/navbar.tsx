"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, LogOut } from 'lucide-react'
import { cn } from "@/lib/utils"
import { useRouter } from 'next/navigation'

interface NavbarProps {
  user?: any
  loading?: boolean
}

export function Navbar({ user, loading }: NavbarProps = {}) {
  const [mounted, setMounted] = useState(false)
  const router = useRouter()

  useEffect(() => {
    setMounted(true)
  }, [])

  const handleLogout = async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST" })
      router.push("/login")
    } catch (error) {
      console.error("Logout failed", error)
    }
  }

  // Shared button style for primary actions
  const primaryButtonClass = cn(
    "rounded-full px-4",
    "bg-neutral-900 hover:bg-neutral-800 text-white",
    "shadow-[inset_0_1px_0_0_rgba(255,255,255,.15)]",
    "flex items-center gap-1"
  )

  return (
    <header>
      <nav
        className={cn(
          "mx-auto flex items-center justify-between gap-3 mt-0",
          "rounded-full border bg-white/70 px-4 py-2 shadow-sm backdrop-blur-md",
          "dark:bg-black/30",
        )}
        aria-label="Primary"
      >
        {/* Logo */}
        <div className="flex items-center gap-2">
          <svg 
            viewBox="0 0 100 100" 
            className="w-8 h-8"
            aria-label="Shiftza logo"
          >
            <defs>
              <style>{`
                @keyframes shiftFlow {
                  0% { transform: translateY(0px); }
                  50% { transform: translateY(-8px); }
                  100% { transform: translateY(0px); }
                }
                @keyframes shiftRotate {
                  0% { transform: rotate(0deg); }
                  100% { transform: rotate(360deg); }
                }
                .shift-element { animation: shiftFlow 2s ease-in-out infinite; }
                .shift-center { animation: shiftRotate 4s linear infinite; }
              `}</style>
            </defs>
            <g className="shift-element" style={{animationDelay: '0s'}}>
              <path d="M 20 50 Q 25 40 35 45 L 35 55 Q 25 60 20 50" fill="#FF6B35" opacity="0.9"/>
            </g>
            <g className="shift-center">
              <circle cx="50" cy="50" r="12" fill="none" stroke="#FF6B35" strokeWidth="2"/>
              <circle cx="50" cy="50" r="8" fill="none" stroke="#00D9FF" strokeWidth="1.5" opacity="0.7"/>
            </g>
            <g className="shift-element" style={{animationDelay: '1s'}}>
              <path d="M 80 50 Q 75 40 65 45 L 65 55 Q 75 60 80 50" fill="#00D9FF" opacity="0.9"/>
            </g>
            <g className="shift-element" style={{animationDelay: '0.5s'}}>
              <path d="M 50 20 L 55 30 L 45 30 Z" fill="#FF6B35" opacity="0.8"/>
            </g>
            <g className="shift-element" style={{animationDelay: '1.5s'}}>
              <path d="M 50 80 L 55 70 L 45 70 Z" fill="#00D9FF" opacity="0.8"/>
            </g>
          </svg>
          <div>
            <span className="font-semibold">Shiftza</span>
          </div>
        </div>

        {/* Menu links */}
        <ul className="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
          <li>
            <Link href="#features" className="transition-colors hover:text-foreground">
              Features
            </Link>
          </li>
          <li>
            <Link href="#how-it-works" className="transition-colors hover:text-foreground">
              How it Works
            </Link>
          </li>
          <li>
            <Link href="#pricing" className="transition-colors hover:text-foreground">
              Pricing
            </Link>
          </li>
        </ul>

        {/* Action buttons */}
        <div className="flex items-center gap-1">
          {!loading && !user ? (
            <>
              {/* Login link */}
              <Link
                href="/login"
                className="hidden text-sm text-muted-foreground transition-colors hover:text-foreground md:inline px-1"
              >
                Login
              </Link>

              {/* Signup button */}
              <Button asChild size="sm" className={primaryButtonClass}>
                <Link href="/signup" aria-label="Try shiftza for free">
                  <span className="mr-1">Try shiftza for Free</span>
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </>
          ) : !loading && user ? (
            <>
              {/* Logout button first with black bg and red hover */}
              <Button
                onClick={handleLogout}
                size="sm"
                className="rounded-full px-4 bg-white border border-white text-gray-700 shadow-sm hover:bg-red-50 hover:text-red-600 flex items-center gap-1"
              >
                <LogOut className="h-0 w-0 mr-0" />
                Logout
              </Button>

              {/* Dashboard button (unchanged) */}
              <Button asChild size="sm" className={primaryButtonClass}>
                <Link href="/dashboard" aria-label="Go to dashboard">
                  <span className="mr-0">Go to Dashboard</span>
                </Link>
              </Button>
            </>
          ) : null}
        </div>
      </nav>
    </header>
  )
}
