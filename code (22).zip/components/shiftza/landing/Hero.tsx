"use client"

import { useEffect, useState, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"
import { LogOut } from "lucide-react"

interface HeroProps {
  user: any
  loading: boolean
  loggingOut: boolean
  onLogout: () => void
}

export const Hero: React.FC<HeroProps> = ({ user, loading, loggingOut, onLogout }) => {
  const router = useRouter()
  const intervalRef = useRef<NodeJS.Timeout | null>(null)

  const topics = [
    "Data Analyst",
    "Web Developer",
    "App Developer",
    "Cloud Engineer",
    "AI/ML Engineer",
    "Cybersecurity",
    "UI/UX Designer",
    "Video Editor",
    "Content Creator",
    "Digital Marketer",
    "SEO Specialist",
    "Social Media",
    "Marketing",
    "Project Manager",
    "Business Analyst",
    "Sales Executive",
  ]
  const [currentIndex, setCurrentIndex] = useState(0)

  const formatTopic = (slug: string) =>
    slug
      .split("-")
      .map((s) => s.charAt(0).toUpperCase() + s.slice(1))
      .join(" ")

  // 🔄 Topic rotation
  useEffect(() => {
    if (intervalRef.current) clearInterval(intervalRef.current)
    intervalRef.current = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % topics.length)
    }, 2300)

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current)
    }
  }, [])

  return (
    <section className="relative mt-10">
      <div className="bg-white rounded-3xl p-8 shadow-lg relative overflow-hidden border my-10">
        {/* Glow */}
        <motion.div
          className="absolute top-0 left-1/3 w-[30rem] h-[30rem] bg-red-400/20 blur-[120px] rounded-full"
          animate={{ scale: [1, 1.2, 1], opacity: [0.15, 0.35, 0.15] }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
        />

     

        {/* Left Heading Section */}
        <div className="max-w-xl">
          <h1 className="text-5xl font-bold text-gray-900 leading-tight">
            The future of <span className="text-red-500">Hiring</span> is skills-first
          </h1>

          <p className="text-gray-600 mt-4 text-lg">
          Join Shiftza.ai to verify your skills, build your profile, <br />
            and get matched with top global opportunities.
          </p>

          {/* Rotating Role Title */}
          <div className="mt-6 text-2xl font-semibold text-red-600 h-8 flex items-center ml-2.5">
   <AnimatePresence mode="wait">
      <motion.span
        key={currentIndex}
        initial={{ rotateX: 90, opacity: 0 }}
        animate={{ rotateX: 0, opacity: 1 }}
        exit={{ rotateX: -90, opacity: 0 }}
        transition={{
          duration: 0.6,
          ease: "easeInOut",
        }}
        className="font-semibold inline-block capitalize drop-shadow-sm whitespace-nowrap absolute text-left w-auto text-pink-10000 text-rose-500"
        style={{
          backfaceVisibility: "hidden",
          WebkitBackfaceVisibility: "hidden",
          transformStyle: "preserve-3d",
        }}
      >
        {formatTopic(topics[currentIndex])}
      </motion.span>
    </AnimatePresence>
  </div>

          {/* CTA */}
          <div className="flex gap-4 mt-2.5">
            <Button
              className="bg-red-500 text-white rounded-full px-6 py-3 text-lg hover:bg-red-600"
              onClick={() => router.push("/signup")}
            >
              Create Profile
            </Button>
            <Button
              variant="outline"
              className="rounded-full px-6 py-3 border-gray-300 hover:bg-red-50"
              onClick={() => router.push("/search")}
            >
              Explore Talent
            </Button>
          </div>
        </div>

        {/* Right preview image */}
        <div className="mt-12 md:mt-0 md:absolute right-6 top-6 w-[420px]">
          <img
            src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f"
            className="rounded-3xl shadow-lg object-cover h-[260px] w-full"
          />
        </div>
      </div>
    </section>
  )
}
