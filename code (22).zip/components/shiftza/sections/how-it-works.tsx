import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function HowItWorksSection() {
  const steps = [
    { n: 1, title: "Create a project", desc: "Start with a goal, due date, and team." },
    { n: 2, title: "Add tasks and owners", desc: "Break work down and assign owners." },
    { n: 3, title: "Track and adapt", desc: "Watch progress, adjust scope, and ship on time." },
  ]
  return (
    <section className="py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold mb-8 text-center">How It Works</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {steps.map((step) => (
            <Card key={step.n} className="rounded-2xl p-6 shadow-md border-0 bg-white">
              <CardHeader>
                <Badge className="w-fit mb-2">{step.n}</Badge>
                <CardTitle className="text-lg">{step.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">{step.desc}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
