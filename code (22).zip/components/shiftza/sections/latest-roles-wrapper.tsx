'use client'

import { Suspense } from 'react'
import LatestRolesSection from './latest-roles'

export function LatestRolesSectionWrapper() {
  return (
    <Suspense fallback={
      <div className="flex items-center justify-center py-12">
        <p className="text-gray-600">Loading profiles...</p>
      </div>
    }>
      <LatestRolesSection />
    </Suspense>
  )
}
