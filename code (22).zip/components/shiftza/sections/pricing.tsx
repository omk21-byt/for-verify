import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function PricingSection() {
  const plans = [
    {
      title: "Starter",
      price: "$29",
      features: ["Up to 5 projects", "Basic support", "Core features"],
      highlight: false,
    },
    {
      title: "Professional",
      price: "$79",
      features: ["Unlimited projects", "Priority support", "Advanced analytics", "API access"],
      highlight: true,
    },
    {
      title: "Enterprise",
      price: "Custom",
      features: ["Everything in Pro", "Dedicated support", "Custom integrations"],
      highlight: false,
    },
  ]

  return (
    <section className="py-12 px-4 bg-gray-50">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold mb-8 text-center">Pricing Plans</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {plans.map((plan) => (
            <Plan key={plan.title} {...plan} />
          ))}
        </div>
      </div>
    </section>
  )
}

function Plan({
  title,
  price,
  features,
  highlight,
}: {
  title: string
  price: string
  features: string[]
  highlight?: boolean
}) {
  return (
    <Card className={highlight ? "border-2 border-[#B6FF00] shadow-lg" : "rounded-2xl p-6 shadow-md border-0 bg-white"}>
      <CardHeader>
        <CardTitle className="flex items-baseline justify-between">
          <span>{title}</span>
          <span className="text-3xl font-semibold">{price}</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="mb-4 space-y-2 text-sm">
          {features.map((f) => (
            <li key={f} className="text-gray-600">
              • {f}
            </li>
          ))}
        </ul>
        <Button asChild className="w-full rounded-full">
          <Link href="/signup">Get Started</Link>
        </Button>
      </CardContent>
    </Card>
  )
}
