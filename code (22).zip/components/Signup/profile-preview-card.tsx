"use client"

export function ProfilePreviewCard({
  skills,
  about,
  sampleUrl,
}: {
  skills: string
  about: string
  sampleUrl: string
}) {
  const skillsList = skills
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)
    .slice(0, 5)

  return (
    <div className="rounded-lg bg-gray-50 border border-gray-300 p-6 mb-6">
      <h3 className="text-sm font-semibold text-gray-900 mb-4 uppercase tracking-wide">Profile Preview</h3>

      <div className="space-y-4">
        {/* Skills Preview */}
        <div>
          <p className="text-xs text-gray-700 mb-2">Skills</p>
          {skillsList.length > 0 ? (
            <div className="flex flex-wrap gap-2">
              {skillsList.map((skill, i) => (
                <span
                  key={i}
                  className="inline-block px-3 py-1 rounded-full bg-yellow-400/20 text-yellow-600 text-xs font-medium"
                >
                  {skill}
                </span>
              ))}
            </div>
          ) : (
            <p className="text-xs text-gray-500 italic">Add skills to see them here</p>
          )}
        </div>

        {/* About Preview */}
        <div>
          <p className="text-xs text-gray-700 mb-2">About</p>
          {about.length > 0 ? (
            <p className="text-sm text-gray-900 line-clamp-2">{about}</p>
          ) : (
            <p className="text-xs text-gray-500 italic">Write about yourself to see it here</p>
          )}
        </div>

        {/* Work Sample Preview */}
        <div>
          <p className="text-xs text-gray-700 mb-2">Work Sample</p>
          {sampleUrl.length > 0 ? (
            <a
              href={sampleUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs text-blue-600 hover:text-blue-700 underline truncate block"
            >
              {sampleUrl}
            </a>
          ) : (
            <p className="text-xs text-gray-500 italic">Add a link to see it here</p>
          )}
        </div>
      </div>

      <div className="mt-4 pt-4 border-t border-gray-300">
        <p className="text-xs text-gray-700">This is how your profile will appear to employers on the dashboard.</p>
      </div>
    </div>
  )
}
