"use client"

import * as React from "react"
import { useState, useEffect, useMemo } from "react"
import {
  Command,
  CommandInput,
  CommandList,
  CommandEmpty,
  CommandGroup,
  CommandItem,
} from "@/components/ui/command"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { X, Sparkles } from "lucide-react"
import Fuse from "fuse.js"

/* ------------------------------------------------------------------
   29 Skill Categories (each with sub-skills & job titles)
------------------------------------------------------------------ */
const SKILL_CATEGORIES = [
  {
    id: "data-analytics",
    name: "Data & Analytics",
    subSkills: ["Data Analysis", "SQL", "Python", "Tableau", "Power BI", "Excel", "Statistics", "Data Visualization"],
    jobs: ["Data Analyst", "Business Analyst", "Data Scientist", "Analytics Engineer"],
  },
  {
    id: "software-dev",
    name: "Software & IT Development",
    subSkills: ["JavaScript", "React", "Node.js", "Python", "Java", "C++", "Full Stack", "API Development"],
    jobs: ["Software Developer", "Full Stack Engineer", "Backend Developer", "Frontend Developer"],
  },
  {
    id: "web-design",
    name: "Web & UI/UX Design",
    subSkills: ["Figma", "UI Design", "UX Design", "Prototyping", "Wireframing", "Web Design", "Responsive Design"],
    jobs: ["UI/UX Designer", "Web Designer", "Product Designer", "Design System Specialist"],
  },
  {
    id: "graphic-design",
    name: "Graphic Design",
    subSkills: ["Adobe Creative Suite", "Branding", "Logo Design", "Illustration", "Typography", "Layout Design"],
    jobs: ["Graphic Designer", "Brand Designer", "Visual Designer", "Illustrator"],
  },
  {
    id: "digital-marketing",
    name: "Digital Marketing",
    subSkills: ["SEO", "Content Marketing", "Social Media", "Email Marketing", "Google Ads", "Analytics", "Copywriting"],
    jobs: ["Digital Marketer", "SEO Specialist", "Content Marketer", "Social Media Manager"],
  },
  {
    id: "video-production",
    name: "Video & Multimedia",
    subSkills: ["Video Editing", "Adobe Premiere", "Motion Graphics", "Animation", "Cinematography", "Audio Editing"],
    jobs: ["Video Editor", "Motion Graphics Designer", "Videographer", "Content Creator"],
  },
  {
    id: "cloud-devops",
    name: "Cloud & DevOps",
    subSkills: ["AWS", "Docker", "Kubernetes", "CI/CD", "Linux", "Infrastructure", "Cloud Architecture"],
    jobs: ["DevOps Engineer", "Cloud Architect", "Infrastructure Engineer", "Site Reliability Engineer"],
  },
  {
    id: "mobile-dev",
    name: "Mobile App Development",
    subSkills: ["React Native", "Flutter", "iOS", "Android", "Swift", "Kotlin", "Mobile UI"],
    jobs: ["Mobile Developer", "iOS Developer", "Android Developer", "React Native Developer"],
  },
  {
    id: "ai-ml",
    name: "AI & Machine Learning",
    subSkills: ["Machine Learning", "Deep Learning", "TensorFlow", "PyTorch", "NLP", "Computer Vision"],
    jobs: ["ML Engineer", "AI Developer", "Data Scientist", "AI Researcher"],
  },
  {
    id: "database",
    name: "Database & SQL",
    subSkills: ["SQL", "PostgreSQL", "MongoDB", "Database Design", "Query Optimization", "NoSQL"],
    jobs: ["Database Administrator", "Database Developer", "Data Engineer", "SQL Developer"],
  },
  {
    id: "cybersecurity",
    name: "Cybersecurity",
    subSkills: ["Network Security", "Penetration Testing", "Ethical Hacking", "Security Audits", "Compliance"],
    jobs: ["Security Engineer", "Penetration Tester", "Security Analyst", "Compliance Officer"],
  },
  {
    id: "project-management",
    name: "Project Management",
    subSkills: ["Agile", "Scrum", "Project Planning", "Risk Management", "Stakeholder Management"],
    jobs: ["Project Manager", "Scrum Master", "Product Manager", "Program Manager"],
  },
  {
    id: "business-analysis",
    name: "Business Analysis",
    subSkills: ["Requirements Gathering", "Process Mapping", "Business Modeling", "Documentation", "Stakeholder Analysis"],
    jobs: ["Business Analyst", "Systems Analyst", "Requirements Analyst", "Solutions Architect"],
  },
  {
    id: "sales",
    name: "Sales & Business Development",
    subSkills: ["Sales Strategy", "Client Relations", "Negotiation", "CRM", "Lead Generation", "Account Management"],
    jobs: ["Sales Executive", "Business Development Manager", "Account Manager", "Sales Manager"],
  },
  {
    id: "customer-service",
    name: "Customer Service & Support",
    subSkills: ["Customer Support", "Ticketing Systems", "Communication", "Problem Solving", "Zendesk", "Intercom"],
    jobs: ["Customer Support Specialist", "Support Manager", "Customer Success Manager", "Help Desk Technician"],
  },
  {
    id: "content-writing",
    name: "Content Writing & Copywriting",
    subSkills: ["Blog Writing", "Copywriting", "Technical Writing", "Content Strategy", "Editing", "Proofreading"],
    jobs: ["Content Writer", "Copywriter", "Technical Writer", "Content Strategist"],
  },
  {
    id: "seo-sem",
    name: "SEO & SEM",
    subSkills: ["SEO", "Google Ads", "Keyword Research", "Link Building", "On-page Optimization", "Analytics"],
    jobs: ["SEO Specialist", "SEM Specialist", "PPC Manager", "Search Marketing Manager"],
  },
  {
    id: "social-media",
    name: "Social Media Management",
    subSkills: ["Social Media Strategy", "Content Creation", "Community Management", "Analytics", "Engagement"],
    jobs: ["Social Media Manager", "Community Manager", "Social Media Strategist", "Content Creator"],
  },
  {
    id: "email-marketing",
    name: "Email & Marketing Automation",
    subSkills: ["Email Marketing", "Mailchimp", "HubSpot", "Automation", "Segmentation", "A/B Testing"],
    jobs: ["Email Marketer", "Marketing Automation Specialist", "Growth Marketer", "Email Strategist"],
  },
  {
    id: "accounting",
    name: "Accounting & Finance",
    subSkills: ["Bookkeeping", "Tax Preparation", "Financial Analysis", "QuickBooks", "Excel", "Auditing"],
    jobs: ["Accountant", "Bookkeeper", "Financial Analyst", "Tax Specialist"],
  },
  {
    id: "hr-recruitment",
    name: "HR & Recruitment",
    subSkills: ["Recruitment", "HR Management", "Onboarding", "Employee Relations", "Payroll", "Compliance"],
    jobs: ["HR Manager", "Recruiter", "HR Specialist", "Talent Acquisition Manager"],
  },
  {
    id: "virtual-assistant",
    name: "Virtual Assistance & Administration",
    subSkills: ["Administrative Support", "Scheduling", "Email Management", "Data Entry", "Research", "Organization"],
    jobs: ["Virtual Assistant", "Administrative Assistant", "Executive Assistant", "Office Manager"],
  },
  {
    id: "translation",
    name: "Translation & Localization",
    subSkills: ["Translation", "Localization", "Proofreading", "Transcription", "Multilingual Support"],
    jobs: ["Translator", "Localization Specialist", "Transcriptionist", "Language Specialist"],
  },
  {
    id: "carpentry",
    name: "Carpentry & Woodworking",
    subSkills: ["Carpentry", "Furniture Making", "Cabinet Making", "Woodworking", "Finishing", "Design"],
    jobs: ["Carpenter", "Furniture Maker", "Cabinet Maker", "Woodworker"],
  },
  {
    id: "electrical",
    name: "Electrical & Wiring",
    subSkills: ["Electrical Wiring", "Circuit Design", "Troubleshooting", "Safety Compliance", "Installation"],
    jobs: ["Electrician", "Electrical Technician", "Electrical Engineer", "Maintenance Technician"],
  },
  {
    id: "plumbing",
    name: "Plumbing & Pipefitting",
    subSkills: ["Plumbing", "Pipe Installation", "Maintenance", "Troubleshooting", "Code Compliance"],
    jobs: ["Plumber", "Pipefitter", "Maintenance Technician", "Plumbing Inspector"],
  },
  {
    id: "hvac",
    name: "HVAC & Climate Control",
    subSkills: ["HVAC Installation", "Maintenance", "Troubleshooting", "Refrigeration", "System Design"],
    jobs: ["HVAC Technician", "HVAC Engineer", "Maintenance Technician", "Service Manager"],
  },
  {
    id: "welding",
    name: "Welding & Metal Fabrication",
    subSkills: ["Welding", "Metal Fabrication", "Cutting", "Assembly", "Quality Control", "Safety"],
    jobs: ["Welder", "Metal Fabricator", "Welding Inspector", "Production Technician"],
  },
  {
    id: "automotive",
    name: "Automotive & Mechanics",
    subSkills: ["Auto Repair", "Diagnostics", "Engine Work", "Transmission", "Electrical Systems", "Maintenance"],
    jobs: ["Mechanic", "Auto Technician", "Service Manager", "Diagnostic Technician"],
  },
]

/* ---------------------
   Build skill → jobs map
---------------------- */
const SKILL_TO_CATEGORY: Record<string, string> = {}
const SKILL_TO_JOBS: Record<string, string[]> = {}
const ALL_SUBSKILLS: string[] = []



for (const cat of SKILL_CATEGORIES) {
  for (const s of cat.subSkills) {
    SKILL_TO_CATEGORY[s.toLowerCase()] = cat.id
    SKILL_TO_JOBS[s.toLowerCase()] = cat.jobs
    ALL_SUBSKILLS.push(s)
  }
}

const fuse = new Fuse(ALL_SUBSKILLS, { threshold: 0.35, ignoreLocation: true })

/* ---------------------
   AI-Smart Job Suggestor
---------------------- */
export function getJobsForSkills(skills: string[]): string[] {
  const jobs = new Set<string>()
  for (const raw of skills) {
    const skill = raw.toLowerCase()
    if (SKILL_TO_JOBS[skill]) {
      SKILL_TO_JOBS[skill].forEach((j) => jobs.add(j))
      continue
    }
    const fuzzy = fuse.search(skill, { limit: 1 })[0]
    if (fuzzy && SKILL_TO_JOBS[fuzzy.item.toLowerCase()]) {
      SKILL_TO_JOBS[fuzzy.item.toLowerCase()].forEach((j) => jobs.add(j))
      continue
    }
    // fallback: nearest category if fuzzy fail
    const foundCat = Object.entries(SKILL_TO_CATEGORY).find(([k]) => skill.includes(k))
    if (foundCat) {
      const catJobs = SKILL_CATEGORIES.find((c) => c.id === foundCat[1])?.jobs || []
      catJobs.forEach((j) => jobs.add(j))
    }
  }
  return Array.from(jobs)
}

/* ---------------------
   Component
---------------------- */
export function SkillCategorySelector({
  selectedSkills,
  onSkillsChange,
}: {
  selectedSkills: string[]
  onSkillsChange: (skills: string[]) => void
}) {
  const [query, setQuery] = useState("")
  const [localSelected, setLocalSelected] = useState<string[]>(selectedSkills || [])
  const [customSkill, setCustomSkill] = useState("")
  const [relatedJobs, setRelatedJobs] = useState<string[]>([])
  const [isExpanded, setIsExpanded] = useState(false)

  useEffect(() => setRelatedJobs(getJobsForSkills(localSelected)), [localSelected])

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return SKILL_CATEGORIES
    return SKILL_CATEGORIES.map((c) => ({
      ...c,
      subSkills: c.subSkills.filter((s) => s.toLowerCase().includes(q)),
    })).filter((c) => c.subSkills.length)
  }, [query])

  function toggleSkill(s: string) {
    const next = localSelected.includes(s)
      ? localSelected.filter((x) => x !== s)
      : [...localSelected, s]
    setLocalSelected(next)
    onSkillsChange(next)
  }

  function addCustom() {
    const v = customSkill.trim()
    if (!v) return
    if (!localSelected.includes(v)) {
      const next = [...localSelected, v]
      setLocalSelected(next)
      onSkillsChange(next)
    }
    setCustomSkill("")
  }

  function remove(s: string) {
    const next = localSelected.filter((x) => x !== s)
    setLocalSelected(next)
    onSkillsChange(next)
  }

  return (
    <div className="space-y-4">
      {/* Search row — only this row is black */}
      
 <Command>
  {/* Entire black area acts like an input */}
  <div
    className="relative w-full bg-black text-white rounded-md px-3 py-2 flex items-center cursor-text"
    onClick={() => {
      const input = document.querySelector<HTMLInputElement>('[cmdk-input]')
      input?.focus()
    }}
  >
    {/* Full-width input (transparent so black bg shows) */}
    <CommandInput
      placeholder="Search & add skills..."
      value={query}
      onValueChange={(v) => {
        setQuery(v)
        if (v.trim().length > 0) setIsExpanded(true)
        else setIsExpanded(false)
      }}
      onFocus={() => setIsExpanded(true)}
      onBlur={() => {
        if (!query.trim()) setIsExpanded(false)
      }}
      className="w-full bg-transparent text-white border-none focus:ring-0 placeholder:text-gray-400 pr-8"
    />

    {/* Sparkles icon (stays on right) */}
    <Sparkles
      size={16}
      className="absolute right-5 text-yellow-400 pointer-events-none"
    />
  </div>

  {/* Expanding skill list */}
  <CommandList
    className={`transition-all duration-300 overflow-y-auto ${
      isExpanded ? "max-h-50" : "max-35"
    }`}
  >
    <CommandEmpty>
      <div className="p-2 text-sm text-gray-500">
        No results. Press Enter to add a custom skill.
      </div>
    </CommandEmpty>

    {filtered.map((cat) => (
      <CommandGroup key={cat.id} heading={cat.name}>
        {cat.subSkills.map((s) => (
          <CommandItem
            key={s}
            onSelect={() => toggleSkill(s)}
            className="flex justify-between px-3 py-1"
          >
            <span>{s}</span>
          </CommandItem>
        ))}
      </CommandGroup>
    ))}
  </CommandList>
</Command>


      {/* Selected tags */}
      <div className="mt-3 flex flex-wrap gap-2">
        {localSelected.map((s) => (
          <div key={s} className="flex items-center gap-1 bg-blue-50 border px-2 py-1 rounded">
            <span>{s}</span>
            <button onClick={() => remove(s)} aria-label={`Remove ${s}`}>
              <X size={14} />
            </button>
          </div>
        ))}
      </div>

      {/* Add custom */}
      <div className="mt-3 flex gap-2">
        <Input
          value={customSkill}
          onChange={(e) => setCustomSkill((e.target as HTMLInputElement).value)}
          placeholder="Add custom skill"
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault()
              addCustom()
            }
          }}
        />
        <Button onClick={addCustom}>Add</Button>
      </div>
    </div>
  )
}

export default SkillCategorySelector
