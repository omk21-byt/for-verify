"use client"

import { Badge } from "@/components/ui/badge"
import { X } from "lucide-react"

interface JobProfileSelectorProps {
  availableJobs: string[]
  selectedJobs: string[]
  onJobsChange: (jobs: string[]) => void
}

export function JobProfileSelector({ availableJobs, selectedJobs, onJobsChange }: JobProfileSelectorProps) {
  const handleJobToggle = (job: string) => {
    if (selectedJobs.includes(job)) {
      onJobsChange(selectedJobs.filter((j) => j !== job))
    } else {
      onJobsChange([...selectedJobs, job])
    }
  }

  const handleRemoveJob = (job: string) => {
    onJobsChange(selectedJobs.filter((j) => j !== job))
  }

  if (availableJobs.length === 0) {
    return (
      <div className="rounded-lg bg-gray-50 border border-gray-300 p-4">
        <p className="text-sm text-gray-700">Select skills first to see suggested job profiles</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {/* Selected Jobs Display */}
      {selectedJobs.length > 0 && (
        <div className="rounded-lg bg-gray-50 border border-gray-300 p-4">
          <p className="text-xs text-gray-700 mb-2">Target Job Profiles ({selectedJobs.length})</p>
          <div className="flex flex-wrap gap-2">
            {selectedJobs.map((job) => (
              <Badge key={job} className="bg-blue-100 border-blue-300 text-blue-900">
                {job}
                <button
                  type="button"
                  onClick={() => handleRemoveJob(job)}
                  className="ml-2 opacity-70 hover:opacity-100"
                  aria-label={`Remove ${job}`}
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            ))}
          </div>
        </div>
      )}

      {/* Available Jobs Grid */}
      <div className="space-y-2">
        <p className="text-xs text-gray-700 uppercase tracking-wide">Suggested Job Profiles</p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {availableJobs.map((job) => (
            <button
              key={job}
              type="button"
              onClick={() => handleJobToggle(job)}
              className={`p-3 rounded-lg border transition text-left ${
                selectedJobs.includes(job)
                  ? "bg-blue-100 border-blue-300"
                  : "bg-gray-50 border-gray-300 hover:bg-gray-100"
              }`}
            >
              <div className="flex items-center gap-2">
                <div
                  className={`w-4 h-4 rounded border ${
                    selectedJobs.includes(job) ? "bg-blue-500 border-blue-500" : "border-gray-300 bg-white"
                  }`}
                />
                <span className="text-sm font-medium text-gray-900">{job}</span>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
