"use client"

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"

interface ExperienceSourceSelectorProps {
  learningSource: string
  hasWorkExperience: boolean
  previousExperience: string
  onLearningSourceChange: (source: string) => void
  onWorkExperienceChange: (has: boolean) => void
  onPreviousExperienceChange: (exp: string) => void
}

export function ExperienceSourceSelector({
  learningSource,
  hasWorkExperience,
  previousExperience,
  onLearningSourceChange,
  onWorkExperienceChange,
  onPreviousExperienceChange,
}: ExperienceSourceSelectorProps) {
  return (
    <div className="space-y-4">
      {/* Learning Source */}
      <div className="rounded-lg bg-gray-50 border border-gray-300 p-4">
        <label className="block text-sm font-medium text-gray-900 mb-2">Where did you learn these skills?</label>
        <Select value={learningSource} onValueChange={onLearningSourceChange}>
          <SelectTrigger className="bg-white border-gray-300 text-gray-900">
            <SelectValue placeholder="Select learning source" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="self-taught">Self-Taught</SelectItem>
            <SelectItem value="college">College / University</SelectItem>
            <SelectItem value="bootcamp">Bootcamp / Training Program</SelectItem>
            <SelectItem value="work-experience">Work Experience</SelectItem>
            <SelectItem value="online-course">Online Course</SelectItem>
            <SelectItem value="apprenticeship">Apprenticeship</SelectItem>
            <SelectItem value="mixed">Mixed / Multiple Sources</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Work Experience */}
      <div className="rounded-lg bg-gray-50 border border-gray-300 p-4">
        <label className="block text-sm font-medium text-gray-900 mb-3">Have you worked in this field before?</label>
        <div className="flex gap-3">
          <button
            type="button"
            onClick={() => onWorkExperienceChange(true)}
            className={`flex-1 py-2 px-3 rounded-lg border transition text-sm font-medium ${
              hasWorkExperience
                ? "bg-green-100 border-green-300 text-green-900"
                : "bg-gray-50 border-gray-300 text-gray-700 hover:bg-gray-100"
            }`}
          >
            Yes
          </button>
          <button
            type="button"
            onClick={() => onWorkExperienceChange(false)}
            className={`flex-1 py-2 px-3 rounded-lg border transition text-sm font-medium ${
              !hasWorkExperience
                ? "bg-orange-100 border-orange-300 text-orange-900"
                : "bg-gray-50 border-gray-300 text-gray-700 hover:bg-gray-100"
            }`}
          >
            No
          </button>
        </div>
      </div>

      {/* Previous Experience Details */}
      {hasWorkExperience && (
        <div className="rounded-lg bg-gray-50 border border-gray-300 p-4">
          <label className="block text-sm font-medium text-gray-900 mb-2">
            Tell us about your previous job or project
          </label>
          <Textarea
            value={previousExperience}
            onChange={(e) => onPreviousExperienceChange(e.target.value)}
            placeholder="e.g., Worked as a Senior Developer at TechCorp for 3 years, built scalable APIs..."
            className="bg-white border-gray-300 text-gray-900 min-h-24"
          />
        </div>
      )}
    </div>
  )
}
