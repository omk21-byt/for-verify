"use client"

export function ProfileCompletionStatus({
  skills,
  about,
  sampleUrl,
}: {
  skills: string
  about: string
  sampleUrl: string
}) {
  const skillsList = skills
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)

  const completionItems = [
    { label: "Skills Added", done: skillsList.length > 0, count: skillsList.length },
    { label: "About Written", done: about.length > 0, count: about.length > 0 ? 1 : 0 },
    { label: "Work Sample", done: sampleUrl.length > 0, count: sampleUrl.length > 0 ? 1 : 0 },
  ]

  const completedCount = completionItems.filter((item) => item.done).length
  const totalCount = completionItems.length
  const completionPercent = Math.round((completedCount / totalCount) * 100)

  return (
    <div className="rounded-lg bg-gray-50 border border-gray-300 p-4 mb-6">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-medium text-gray-900">Profile Completion</h3>
        <span className="text-xs text-gray-700">{completionPercent}%</span>
      </div>

      <div className="w-full h-2 rounded-full bg-gray-200 mb-4">
        <div
          className="h-2 rounded-full bg-yellow-400 transition-all duration-300"
          style={{ width: `${completionPercent}%` }}
        />
      </div>

      <div className="space-y-2">
        {completionItems.map((item, i) => (
          <div key={i} className="flex items-center gap-2 text-sm">
            <div
              className={`w-4 h-4 rounded-full flex items-center justify-center text-xs ${
                item.done ? "bg-green-500/20 text-green-600" : "bg-gray-200 text-gray-400"
              }`}
            >
              {item.done ? "✓" : "○"}
            </div>
            <span className={item.done ? "text-gray-900" : "text-gray-600"}>{item.label}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
