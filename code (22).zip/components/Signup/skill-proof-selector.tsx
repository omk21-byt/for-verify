"use client"

import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

interface SkillProofSelectorProps {
  canProveSkill: boolean
  proofLink: string
  proofDescription: string
  onCanProveChange: (can: boolean) => void
  onProofLinkChange: (link: string) => void
  onProofDescriptionChange: (desc: string) => void
}

export function SkillProofSelector({
  canProveSkill,
  proofLink,
  proofDescription,
  onCanProveChange,
  onProofLinkChange,
  onProofDescriptionChange,
}: SkillProofSelectorProps) {
  return (
    <div className="space-y-4">
      {/* Can Prove Skill */}
      <div className="rounded-lg bg-gray-50 border border-gray-300 p-4">
        <label className="block text-sm font-medium text-gray-900 mb-3">Can you prove this skill?</label>
        <div className="flex gap-3">
          <button
            type="button"
            onClick={() => onCanProveChange(true)}
            className={`flex-1 py-2 px-3 rounded-lg border transition text-sm font-medium ${
              canProveSkill
                ? "bg-purple-100 border-purple-300 text-purple-900"
                : "bg-gray-50 border-gray-300 text-gray-700 hover:bg-gray-100"
            }`}
          >
            Yes
          </button>
          <button
            type="button"
            onClick={() => onCanProveChange(false)}
            className={`flex-1 py-2 px-3 rounded-lg border transition text-sm font-medium ${
              !canProveSkill
                ? "bg-gray-200 border-gray-400 text-gray-900"
                : "bg-gray-50 border-gray-300 text-gray-700 hover:bg-gray-100"
            }`}
          >
            No
          </button>
        </div>
      </div>

      {/* Proof Details */}
      {canProveSkill && (
        <div className="space-y-3">
          <div className="rounded-lg bg-gray-50 border border-gray-300 p-4">
            <label className="block text-sm font-medium text-gray-900 mb-2">Share a link to your work (optional)</label>
            <Input
              value={proofLink}
              onChange={(e) => onProofLinkChange(e.target.value)}
              placeholder="GitHub repo, portfolio, YouTube video, Google Drive link, etc."
              className="bg-white border-gray-300 text-gray-900"
              type="url"
            />
            <p className="text-xs text-gray-600 mt-2">Paste a direct link to your project, portfolio, or work sample</p>
          </div>

          <div className="rounded-lg bg-gray-50 border border-gray-300 p-4">
            <label className="block text-sm font-medium text-gray-900 mb-2">Describe your work (optional)</label>
            <Textarea
              value={proofDescription}
              onChange={(e) => onProofDescriptionChange(e.target.value)}
              placeholder="What did you build? What problem did it solve? What technologies did you use?"
              className="bg-white border-gray-300 text-gray-900 min-h-20"
            />
          </div>
        </div>
      )}
    </div>
  )
}
