"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { Search } from "lucide-react"

interface NavbarSearchBarProps {
  onSearch?: (query: string) => void
}

export default function NavbarSearchBar({ onSearch }: NavbarSearchBarProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const router = useRouter()

  const handleSearch = () => {
    if (searchQuery.trim()) {
      router.push(`/search?q=${encodeURIComponent(searchQuery)}`)
      setSearchQuery("")
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleSearch()
    }
  }

  return (
    <div className="hidden sm:flex items-center gap-0 flex-1 max-w-md mx-4">
      <input
        type="text"
        placeholder="Search for skills or services"
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
        onKeyPress={handleKeyPress}
        className="flex-1 px-4 py-2 rounded-l-lg placeholder:text-gray-500 text-sm focus:outline-none rounded-xs text-background font-medium bg-white shadow-sm opacity-100 border-sky-50 border-0"
      />
      <button
        onClick={handleSearch}
        className="hover:bg-green-600 text-white px-4 py-2 rounded-r-lg transition-colors flex items-center justify-center bg-indigo-600 rounded-sm shadow-xl mx-1"
        aria-label="Search"
      >
        <Search className="h-5 w-5" />
      </button>
    </div>
  )
}
