"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle2, AlertCircle, Loader2 } from "lucide-react"

interface PortfolioVerificationCardProps {
  verificationStatus?: string
  skillScore?: number
  verifiedSkills?: string[]
  lastVerifiedAt?: string
  verificationFeedback?: string
  starRating?: number
  adminFeedback?: string
}

export function PortfolioVerificationCard({
  verificationStatus = "pending",
  skillScore = 0,
  verifiedSkills = [],
  lastVerifiedAt,
  verificationFeedback,
  starRating = 0,
  adminFeedback,
}: PortfolioVerificationCardProps) {
  const isVerified = verificationStatus === "verified"
  const isPending = verificationStatus === "pending_review" || verificationStatus === "pending"
  const isRejected = verificationStatus === "rejected"

  return (
    <Card className="rounded-2xl p-8 shadow-lg border-0 my-0 bg-gray-200 py-0 pt-7 pb-1.5">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              {isVerified && <CheckCircle2 className="h-5 w-5 text-green-600" />}
              {isPending && <AlertCircle className="h-5 w-5 text-yellow-600" />}
              {isRejected && <AlertCircle className="h-5 w-5 text-red-600" />}
              Portfolio Verification
            </CardTitle>
            <CardDescription>
              {isVerified && "Your profile has been verified"}
              {isPending && "Verification pending admin review"}
              {isRejected && "Portfolio was not approved"}
            </CardDescription>
          </div>
          {isPending && <Loader2 className="h-5 w-5 animate-spin text-blue-600" />}
        </div>
      </CardHeader>
      <CardContent className="space-y-0">
        {isVerified && (
          <>
            {/* Star Rating */}
            {starRating > 0 && (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-medium">Admin Rating</span>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <span key={star}>{star <= starRating ? "⭐" : "☆"}</span>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Skill Score */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-medium">AI Skill Score</span>
                <span className="text-2xl font-bold text-blue-600">{skillScore}/100</span>
              </div>
              <div className="h-2 w-full overflow-hidden rounded-full bg-gray-200">
                <div
                  className="h-full bg-gradient-to-r from-blue-500 to-blue-600"
                  style={{ width: `${skillScore}%` }}
                />
              </div>
            </div>

            {/* Verified Skills */}
            {verifiedSkills && verifiedSkills.length > 0 && (
              <div className="space-y-2">
                <span className="font-medium">Verified Skills</span>
                <div className="flex flex-wrap gap-2">
                  {verifiedSkills.map((skill) => (
                    <span
                      key={skill}
                      className="inline-flex items-center rounded-full bg-green-100 px-3 py-1 text-sm font-medium text-green-700"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Admin Feedback */}
            {adminFeedback && (
              <div className="space-y-2">
                <span className="font-medium">Admin Feedback</span>
                <p className="text-sm p-2 rounded py-1.5 px-3 rounded-md text-background bg-gray-800 my-0 mb-1.5 mt-1">{adminFeedback}</p>
              </div>
            )}

            {/* AI Assessment */}
            {verificationFeedback && (
              <div className="space-y-2">
                <span className="font-medium">AI Assessment</span>
                <p className="text-sm text-gray-600">{verificationFeedback}</p>
              </div>
            )}

            {/* Last Verified */}
            {lastVerifiedAt && (
              <div className="text-xs text-gray-500">Verified: {new Date(lastVerifiedAt).toLocaleDateString()}</div>
            )}
          </>
        )}

        {isPending && (
          <div className="space-y-2">
            <p className="text-sm text-gray-600">
              Your portfolio is under admin review. This typically takes 30-40 second.
            </p>
            <div className="space-y-1">
              <div className="h-2 w-full animate-pulse rounded-full bg-gray-300" />
              <div className="h-2 w-4/5 animate-pulse rounded-full bg-gray-300" />
            </div>
          </div>
        )}

        {isRejected && (
          <div className="space-y-2">
            <p className="text-sm text-red-600 font-medium">Portfolio was not approved</p>
            {adminFeedback && <p className="text-sm text-gray-600 bg-red-50 p-2 rounded">{adminFeedback}</p>}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
