"use client"

import { Card } from "@/components/ui/card"
import { CheckCircle2, AlertCircle, Loader2, TrendingUp } from "lucide-react"
import { Badge } from "@/components/ui/badge"

interface AISkillData {
  skill_name: string
  verified: boolean
  ai_score: number
  ai_feedback: string
  proof_link?: string
}

interface AISkillVerificationDisplayProps {
  skills: AISkillData[]
  loading?: boolean
}

export function AISkillVerificationDisplay({ skills, loading = false }: AISkillVerificationDisplayProps) {
  if (loading) {
    return (
      <Card className="rounded-2xl p-6 shadow-md border-0 bg-white">
        <div className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-[#B6FF00]" />
          <span className="ml-3 text-gray-600">Analyzing skills with AI...</span>
        </div>
      </Card>
    )
  }

  if (!skills || skills.length === 0) {
    return (
      <Card className="rounded-2xl p-6 shadow-md border-0 bg-white">
        <div className="text-center py-8">
          <AlertCircle className="h-8 w-8 text-gray-400 mx-auto mb-3" />
          <p className="text-gray-600">No verified skills yet. Submit your first skill for AI verification.</p>
        </div>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      {skills.map((skill) => (
        <Card
          key={skill.skill_name}
          className="rounded-2xl p-6 shadow-md border-0 bg-white hover:shadow-lg transition-shadow"
        >
          <div className="space-y-3">
            {/* Header: Skill name + verification badge */}
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h3 className="text-lg font-semibold text-gray-900">{skill.skill_name}</h3>
                  {skill.verified && <CheckCircle2 className="h-5 w-5 text-green-600 flex-shrink-0" />}
                </div>
              </div>
              {skill.verified ? (
                <Badge className="bg-green-100 text-green-700 border-0">Verified by AI</Badge>
              ) : (
                <Badge className="bg-yellow-100 text-yellow-700 border-0">Pending Review</Badge>
              )}
            </div>

            {/* AI Score Bar */}
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-gray-600 flex items-center gap-1">
                  <TrendingUp className="h-3 w-3" />
                  AI Confidence Score
                </span>
                <span className="text-sm font-bold text-[#B6FF00]">{skill.ai_score}%</span>
              </div>
              <div className="h-2 w-full bg-gray-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-[#B6FF00] to-green-500 transition-all duration-300"
                  style={{ width: `${skill.ai_score}%` }}
                />
              </div>
            </div>

            {/* AI Feedback */}
            {skill.ai_feedback && (
              <div className="bg-blue-50 rounded-lg p-3 border border-blue-100">
                <p className="text-xs font-medium text-blue-900 mb-1">AI Assessment:</p>
                <p className="text-sm text-blue-800">{skill.ai_feedback}</p>
              </div>
            )}

            {/* Proof Link */}
            {skill.proof_link && (
              <div className="text-xs">
                <a
                  href={skill.proof_link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[#0B6B2E] hover:underline font-medium"
                >
                  View Proof →
                </a>
              </div>
            )}
          </div>
        </Card>
      ))}
    </div>
  )
}
