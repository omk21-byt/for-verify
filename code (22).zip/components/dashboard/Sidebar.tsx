"use client"

export { default as EduplexSidebar } from "./eduplex-sidebar"

import EduplexSidebar from "./eduplex-sidebar"

export default EduplexSidebar
