"use client"

import { useState, useEffect } from "react"
import { Grid, BookOpen, Users, MessageSquare, Bell, Calendar, Settings, ChevronLeft, ChevronRight, Bookmark, LogOut } from 'lucide-react'
import { useRouter } from 'next/navigation'
import Image from "next/image"

interface UserProfile {
  id: string
  name: string
  avatar_url: string
}

export default function EduplexSidebar() {
  const router = useRouter()
  const [collapsed, setCollapsed] = useState(false)
  const [user, setUser] = useState<UserProfile | null>(null)

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const sessionRes = await fetch("/api/auth/session")
        const sessionData = await sessionRes.json()
        if (!sessionData?.user?.id) return

        const profileRes = await fetch(`/api/profile/get?userId=${sessionData.user.id}`)
        const profileData = await profileRes.json()
        if (profileData?.user) {
          setUser({
            id: profileData.user.id,
            name: profileData.user.name,
            avatar_url: profileData.user.avatar_url || "/avatars/placeholder.png",
          })
        }
      } catch (err) {
        console.error("Failed to fetch user for sidebar:", err)
      }
    }

    fetchUser()
  }, [])

  const menuItems = [
    { icon: Grid, label: "Dashboard", route: "/dashboard" },
    { icon: Users, label: "Browse Professionals", route: "/dashboard/browse" },
    { icon: MessageSquare, label: "Messages", route: "/messages" },
    { icon: Bookmark, label: "Bookmarks", route: "/bookmarks" },
    { icon: Users, label: "Community", route: "/search" },
    { icon: Settings, label: "Settings", route: "/settings" },
  ]

  const handleLogout = async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST" })
      router.push("/login")
    } catch (err) {
      console.error("Logout error:", err)
    }
  }

  return (
    <>
     <aside
  className={`fixed left-0 top-0 h-screen flex flex-col justify-between bg-black text-white transition-all duration-300 z-40 ${
    collapsed ? "w-20" : "w-64"
  } rounded-r-[40px] shadow-lg`}
>
        {/* Profile Header */}
        <div className="px-4 py-6 pb-0">
          <div className="flex items-center justify-between mb-8">
            {!collapsed && user ? (
              <div className="flex items-center gap-3 bg-transparent">
                <Image
                  src="/images/design-mode/Focusing%20intently%2C%20investing%20time%2C%20and%20pouring%E2%80%A6.jpeg"
                  alt="User Avatar"
                  width={40}
                  height={40}
                  className="rounded-full border border-white/20 object-cover bg-transparent"
                />
                <span className="text-base font-medium truncate">{user.name}</span>
              </div>
            ) : (
              user && (
                <Image
                  src="/images/design-mode/Focusing%20intently%2C%20investing%20time%2C%20and%20pouring%E2%80%A6.jpeg"
                  alt="User Avatar"
                  width={40}
                  height={40}
                  className="rounded-full mx-auto border border-white/20 object-cover"
                />
              )
            )}

            <button
              onClick={() => setCollapsed(!collapsed)}
              className="p-1 rounded-md hover:bg-white/10"
            >
              {collapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
            </button>
          </div>

          {/* Navigation */}
          <nav className="space-y-2">
            {menuItems.map((item, i) => {
              const Icon = item.icon
              return (
                <button
                  key={i}
                  onClick={() => router.push(item.route)}
                  className={`relative w-full flex items-center gap-3 p-3 rounded-xl ${
                    collapsed ? "justify-center" : ""
                  } hover:bg-white/10`}
                >
                  <Icon size={20} />
                  {!collapsed && <span>{item.label}</span>}
                  {item.badge && !collapsed && (
                    <span className="absolute right-4 bg-red-500 text-xs font-bold rounded-full px-2 py-[1px]">
                      {item.badge}
                    </span>
                  )}
                </button>
              )
            })}
          </nav>
        </div>

        {/* Bottom Section */}
        <div className="px-4 pb-6">
          <button
            onClick={handleLogout}
            className={`w-full flex items-center gap-2 p-2 rounded-lg hover:bg-white/10 mt-0 bg-lime-300 ${
              collapsed ? "justify-center" : ""
            }`}
          >
            <LogOut className="text-foreground" size={18} />
            {!collapsed && <span className="text-foreground">Logout</span>}
          </button>
        </div>
      </aside>

      <div className={`transition-all duration-300 ${collapsed ? "w-20" : "w-64"}`} />
    </>
  )
}
