"use client"

import { Bell, Settings } from 'lucide-react'

interface DashboardTopbarProps {
  title: string
  description?: string
}

export default function DashboardTopbar({ title, description }: DashboardTopbarProps) {
  return (
    null
  )
}
