"use client"

import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts"

export function WorkProgressCard({ weekly }: { weekly: number[] }) {
  const days = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"]
  const data = days.map((d, i) => ({ day: d, hours: weekly?.[i] ?? 0 }))

  return (
    <div className="card-surface rounded-xl-2 p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-lg font-semibold">Hours Activity</h3>
        <div className="text-sm text-[#6b7280]">Weekly ▾</div>
      </div>

      <div style={{ height: 160 }}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} barCategoryGap={18}>
            <CartesianGrid vertical={false} strokeOpacity={0.06} />
            <XAxis dataKey="day" tick={{ fill: '#6b7280' }} />
            <YAxis width={28} tick={{ fill: '#6b7280' }} />
            <Tooltip />
            <Bar dataKey="hours" radius={[6,6,0,0]} fill="var(--chart-2)" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-3 text-xs text-[#6b7280]">+3% increase than last week</div>
    </div>
  )
}
