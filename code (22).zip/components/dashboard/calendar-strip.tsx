"use client"

import { useState, useEffect, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { CalendarDays, ChevronLeft, ChevronRight, Briefcase, Brain, Target, Sparkles } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { getSupabaseBrowser } from "@/lib/supabase-browser"
import type { JSX } from "react/jsx-runtime" // Import JSX to fix the undeclared variable error

type EventType = "job" | "skill" | "goal" | "ai"

interface CalendarEvent {
  id?: string
  date: string
  type: EventType
  title: string
  time: string
}

export function CalendarStrip() {
  const today = new Date()
  const [currentMonth, setCurrentMonth] = useState(today.getMonth())
  const [currentYear, setCurrentYear] = useState(today.getFullYear())
  const [selectedDate, setSelectedDate] = useState<string | null>(null)
  const [events, setEvents] = useState<CalendarEvent[]>([])
  const supabase = getSupabaseBrowser()

  const popupRef = useRef<HTMLDivElement | null>(null)

  // 🧩 Close popup when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (popupRef.current && !popupRef.current.contains(event.target as Node)) {
        setSelectedDate(null)
      }
    }
    if (selectedDate) {
      document.addEventListener("mousedown", handleClickOutside)
    }
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [selectedDate])

  // 🌐 Fetch events from Supabase or fallback demo
  useEffect(() => {
    const fetchEvents = async () => {
      const { data: { user } } = await supabase.auth.getUser()
      
      if (!user) {
        // Not authenticated - use demo data
        setEvents([
          { date: `${currentYear}-11-05`, type: "job", title: "Interview – Shiftza", time: "3:00 PM" },
          { date: `${currentYear}-11-05`, type: "goal", title: "Prepare Portfolio", time: "1:30 PM" },
          { date: `${currentYear}-11-09`, type: "skill", title: "Complete UX Design Module", time: "All Day" },
          { date: `${currentYear}-11-14`, type: "goal", title: "Upload Resume Update", time: "6:00 PM" },
          { date: `${currentYear}-11-14`, type: "job", title: "Check Job Matches", time: "10:00 AM" },
          { date: `${currentYear}-11-17`, type: "ai", title: "AI Suggested New Roles", time: "Anytime" },
          { date: `${currentYear}-11-22`, type: "ai", title: "AI Career Insights Generated", time: "8:00 PM" },
          { date: `${currentYear}-11-25`, type: "skill", title: "Complete Skill Test", time: "11:00 AM" },
        ])
        return
      }

      const { data, error } = await supabase.from("calendar_events").select("*").eq("user_id", user.id)
      if (!error && data) {
        setEvents(data)
      } else {
        // Table doesn't exist or error - use demo data
        setEvents([
          { date: `${currentYear}-11-05`, type: "job", title: "Interview – Shiftza", time: "3:00 PM" },
          { date: `${currentYear}-11-05`, type: "goal", title: "Prepare Portfolio", time: "1:30 PM" },
          { date: `${currentYear}-11-09`, type: "skill", title: "Complete UX Design Module", time: "All Day" },
          { date: `${currentYear}-11-14`, type: "goal", title: "Upload Resume Update", time: "6:00 PM" },
          { date: `${currentYear}-11-14`, type: "job", title: "Check Job Matches", time: "10:00 AM" },
          { date: `${currentYear}-11-17`, type: "ai", title: "AI Suggested New Roles", time: "Anytime" },
          { date: `${currentYear}-11-22`, type: "ai", title: "AI Career Insights Generated", time: "8:00 PM" },
          { date: `${currentYear}-11-25`, type: "skill", title: "Complete Skill Test", time: "11:00 AM" },
        ])
      }
    }
    fetchEvents()
  }, [currentYear])

  const getDaysInMonth = (month: number, year: number) => {
    const date = new Date(year, month, 1)
    const days = []
    const firstDayIndex = date.getDay()
    const lastDay = new Date(year, month + 1, 0).getDate()
    for (let i = 0; i < firstDayIndex; i++) days.push(null)
    for (let d = 1; d <= lastDay; d++) days.push(d)
    return days
  }

  const monthDays = getDaysInMonth(currentMonth, currentYear)
  const monthName = new Date(currentYear, currentMonth).toLocaleString("default", { month: "long" })

  const prevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11)
      setCurrentYear(currentYear - 1)
    } else setCurrentMonth(currentMonth - 1)
    setSelectedDate(null)
  }

  const nextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0)
      setCurrentYear(currentYear + 1)
    } else setCurrentMonth(currentMonth + 1)
    setSelectedDate(null)
  }

  const eventsForDate = selectedDate ? events.filter((e) => e.date === selectedDate) : []

  const typeStyles: Record<EventType, { color: string; icon: JSX.Element }> = {
    job: { color: "bg-blue-100 text-blue-700", icon: <Briefcase size={18} /> },
    skill: { color: "bg-green-100 text-green-700", icon: <Brain size={18} /> },
    goal: { color: "bg-orange-100 text-orange-700", icon: <Target size={18} /> },
    ai: { color: "bg-purple-100 text-purple-700", icon: <Sparkles size={18} /> },
  }

  return (
    <Card className="p-6 bg-white rounded-2xl shadow-sm border border-gray-200 relative">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <CalendarDays className="w-5 h-5 text-blue-600" />
          <h2 className="font-semibold text-gray-900">
            {monthName} {currentYear}
          </h2>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={prevMonth}>
            <ChevronLeft />
          </Button>
          <Button variant="outline" size="icon" onClick={nextMonth}>
            <ChevronRight />
          </Button>
        </div>
      </div>

      {/* Week header */}
      <div className="grid grid-cols-7 text-center mb-2 text-xs font-semibold text-gray-500">
        {["S", "M", "T", "W", "T", "F", "S"].map((d) => (
          <div key={d}>{d}</div>
        ))}
      </div>

      {/* Calendar grid */}
      <div className="grid grid-cols-7 gap-1 text-center text-sm relative">
        {monthDays.map((day, i) => {
          if (!day) return <div key={i}></div>

          const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`
          const dayEvents = events.filter((e) => e.date === dateStr)
          const isToday =
            day === today.getDate() && currentMonth === today.getMonth() && currentYear === today.getFullYear()

          return (
            <motion.div
              key={dateStr}
              whileHover={{ scale: 1.05 }}
              onClick={(e) => {
                e.stopPropagation()
                setSelectedDate(dateStr)
              }}
              className={`relative cursor-pointer rounded-lg py-2 transition ${
                isToday ? "bg-green-100 text-green-800 font-semibold" : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              {day}
              {dayEvents.length > 0 && <div className="w-2 h-2 rounded-full bg-blue-500 mx-auto mt-1"></div>}
            </motion.div>
          )
        })}

        {/* Embedded popup */}
        <AnimatePresence>
          {selectedDate && (
            <motion.div
              ref={popupRef}
              key={selectedDate}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 15 }}
              transition={{ duration: 0.25 }}
              className="absolute right-0 top-0 mt-2 mr-[-340px] w-[300px] bg-white rounded-xl shadow-xl border border-gray-100 p-4 z-10"
            >
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold text-gray-900 text-base">AI Schedule</h3>
                <Button size="sm" variant="ghost" onClick={() => setSelectedDate(null)}>
                  ✕
                </Button>
              </div>

              <p className="text-sm text-gray-500 mb-3">
                {new Date(selectedDate).toLocaleDateString("en-US", {
                  day: "numeric",
                  month: "long",
                })}
              </p>

              {eventsForDate.length > 0 ? (
                <div className="max-h-[260px] overflow-y-auto space-y-3 pr-1">
                  {eventsForDate.map((event, idx) => (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.05 }}
                      className={`p-3 rounded-lg flex items-center gap-3 ${typeStyles[event.type].color}`}
                    >
                      <div className="w-9 h-9 flex items-center justify-center bg-white/70 rounded-full">
                        {typeStyles[event.type].icon}
                      </div>
                      <div>
                        <h4 className="font-medium leading-tight">{event.title}</h4>
                        <p className="text-sm opacity-80">{event.time}</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500 text-sm text-center py-6">No events for this date.</p>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </Card>
  )
}
