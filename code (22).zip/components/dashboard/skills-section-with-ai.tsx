"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AISkillCard } from "@/components/ai-skill-card"
import { Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface UserSkill {
  id: string
  skill_name: string
  verified: boolean
  ai_score?: number
  ai_feedback?: string
  verified_by_ai?: boolean
  proof_link?: string
  proof_description?: string
}

interface SkillsSectionProps {
  userId: string
  initialSkills: UserSkill[]
}

export function SkillsSectionWithAI({ userId, initialSkills }: SkillsSectionProps) {
  const [skills, setSkills] = useState<UserSkill[]>(initialSkills)
  const [loading, setLoading] = useState(false)
  const [verifyingSkills, setVerifyingSkills] = useState<Set<string>>(new Set())
  const { toast } = useToast()

  const verifySkillWithAI = async (skill: UserSkill) => {
    if (skill.verified_by_ai) {
      toast({
        title: "Already Verified",
        description: "This skill has already been verified by AI",
      })
      return
    }

    const skillId = skill.id
    setVerifyingSkills((prev) => new Set(prev).add(skillId))

    try {
      console.log("[v0] Starting AI verification for skill:", skill.skill_name)

      const response = await fetch("/api/skills/verify-with-ai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          skill_name: skill.skill_name,
          proof_link: skill.proof_link || "",
          proof_description: skill.proof_description || "",
          user_id: userId,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Verification failed")
      }

      const result = await response.json()

      console.log("[v0] AI verification result:", result)

      // Update skill with AI results
      setSkills((prev) =>
        prev.map((s) =>
          s.id === skillId
            ? {
                ...s,
                ai_score: result.ai_score,
                ai_feedback: result.ai_feedback,
                verified_by_ai: result.verified,
                verified: result.verified,
              }
            : s,
        ),
      )

      toast({
        title: "Skill Verified",
        description: `AI score: ${result.ai_score}% - ${result.ai_feedback}`,
      })
    } catch (error) {
      console.error("[v0] AI verification error:", error)
      toast({
        title: "Verification Failed",
        description:
          error instanceof Error
            ? error.message
            : "Failed to verify skill with OpenAI. Check your API key and model access.",
        variant: "destructive",
      })
    } finally {
      setVerifyingSkills((prev) => {
        const next = new Set(prev)
        next.delete(skillId)
        return next
      })
    }
  }

  const verifyAllSkills = async () => {
    setLoading(true)
    const unverifiedSkills = skills.filter((s) => !s.verified_by_ai)

    try {
      for (const skill of unverifiedSkills) {
        await verifySkillWithAI(skill)
        // Small delay between API calls to avoid rate limiting
        await new Promise((resolve) => setTimeout(resolve, 500))
      }

      toast({
        title: "Complete",
        description: "All skills have been verified by AI",
      })
    } catch (error) {
      console.error("[v0] Batch verification error:", error)
      toast({
        title: "Error",
        description: "Some skills failed to verify",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const verifiedCount = skills.filter((s) => s.verified_by_ai).length
  const averageScore =
    skills.filter((s) => s.ai_score).length > 0
      ? Math.round(
          skills.filter((s) => s.ai_score).reduce((sum, s) => sum + (s.ai_score || 0), 0) /
            skills.filter((s) => s.ai_score).length,
        )
      : 0

  return (
    <Card className="rounded-2xl p-6 shadow-md border-0 bg-white">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Skills Verified by AI</h3>
          <p className="text-sm text-gray-600 mt-1">Real-time verification using OpenAI GPT-4</p>
        </div>

        <div className="flex items-center gap-4">
          <div className="text-right">
            <p className="text-xs text-gray-500">Average Score</p>
            <p className="text-2xl font-bold text-[#0B6B2E]">{averageScore}%</p>
          </div>

          <Button
            onClick={verifyAllSkills}
            disabled={loading || skills.filter((s) => !s.verified_by_ai).length === 0}
            className="bg-[#B6FF00] text-[#1C073A] hover:bg-[#A8E600]"
          >
            {loading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
            {loading ? "Verifying..." : `Verify All (${skills.filter((s) => !s.verified_by_ai).length})`}
          </Button>
        </div>
      </div>

      {/* Skills grid */}
      {skills.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {skills.map((skill) => (
            <div key={skill.id}>
              <AISkillCard skill={skill} />
              {!skill.verified_by_ai && (
                <Button
                  onClick={() => verifySkillWithAI(skill)}
                  disabled={verifyingSkills.has(skill.id)}
                  variant="outline"
                  className="w-full mt-2 text-xs"
                >
                  {verifyingSkills.has(skill.id) && <Loader2 className="w-3 h-3 mr-2 animate-spin" />}
                  {verifyingSkills.has(skill.id) ? "Verifying..." : "Verify with AI"}
                </Button>
              )}
            </div>
          ))}
        </div>
      ) : (
        <p className="text-gray-600 text-center py-8">No skills added yet. Add skills to get AI verification.</p>
      )}

      <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
        <p className="text-xs text-blue-900">
          <strong>How it works:</strong> Each skill is verified by OpenAI GPT-4, which analyzes the proof link and
          description to provide an accurate confidence score and detailed feedback.
        </p>
      </div>
    </Card>
  )
}
