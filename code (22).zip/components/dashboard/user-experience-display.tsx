"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Briefcase, Link2 } from "lucide-react"

interface UserExperienceProps {
  learningSource?: string
  hasWorkExperience?: boolean
  previousExperience?: string
  selectedJobs?: string[]
  proofLink?: string
  proofDescription?: string
}

export function UserExperienceDisplay({
  learningSource,
  hasWorkExperience,
  previousExperience,
  selectedJobs,
  proofLink,
  proofDescription,
}: UserExperienceProps) {
  return (
    <div className="space-y-4">
      {/* Learning Source */}
      {learningSource && (
        <Card className="rounded-lg border border-gray-200 shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <BookOpen className="w-4 h-4" />
              Learning Background
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-700">{learningSource}</p>
          </CardContent>
        </Card>
      )}

      {/* Work Experience */}
      <Card className="rounded-lg border border-gray-200 shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Briefcase className="w-4 h-4" />
            Work Experience
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <p className="text-sm">
            <span className="font-semibold">Field Experience:</span> {hasWorkExperience ? "Yes" : "No"}
          </p>
          {previousExperience && (
            <div className="bg-blue-50 p-3 rounded border border-blue-100">
              <p className="text-sm text-gray-700">{previousExperience}</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Proof of Skills */}
      {proofLink || proofDescription ? (
        <Card className="rounded-lg border border-gray-200 shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <Link2 className="w-4 h-4" />
              Proof of Skills
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {proofLink && (
              <div>
                <p className="text-xs font-medium text-gray-500 uppercase mb-1">Portfolio Link</p>
                <a
                  href={proofLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:underline break-all text-sm"
                >
                  {proofLink}
                </a>
              </div>
            )}
            {proofDescription && (
              <div>
                <p className="text-xs font-medium text-gray-500 uppercase mb-1">Description</p>
                <p className="text-sm text-gray-700">{proofDescription}</p>
              </div>
            )}
          </CardContent>
        </Card>
      ) : null}

      {/* Target Roles */}
      {selectedJobs && selectedJobs.length > 0 && (
        <Card className="rounded-lg border border-gray-200 shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Target Roles</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {selectedJobs.map((job) => (
                <Badge key={job} variant="secondary" className="bg-blue-100 text-blue-900 border-blue-200">
                  {job}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
