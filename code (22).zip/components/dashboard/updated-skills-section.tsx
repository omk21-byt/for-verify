"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AISkillVerificationDisplay } from "@/components/ai-skill-verification-display"
import { Plus } from "lucide-react"

interface Skill {
  id: string
  skill_name: string
  verified: boolean
  ai_score?: number
  ai_feedback?: string
  proof_link?: string
}

interface UpdatedSkillsSectionProps {
  skills: Skill[]
  loading?: boolean
  onVerifySkill?: (skillId: string) => Promise<void>
}

export function UpdatedSkillsSection({ skills, loading = false, onVerifySkill }: UpdatedSkillsSectionProps) {
  const [verifyingSkillId, setVerifyingSkillId] = useState<string | null>(null)

  const handleVerifySkill = async (skillId: string) => {
    setVerifyingSkillId(skillId)
    try {
      if (onVerifySkill) {
        await onVerifySkill(skillId)
      }
    } finally {
      setVerifyingSkillId(null)
    }
  }

  const skillsWithAI = skills.map((skill) => ({
    ...skill,
    ai_score: skill.ai_score ?? 0,
    ai_feedback: skill.ai_feedback ?? "",
    verified: skill.verified || (skill.ai_score ?? 0) >= 70,
  }))

  return (
    <Card className="rounded-2xl p-6 shadow-md border-0 bg-white">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">AI-Verified Skills</h3>
          <p className="text-sm text-gray-600 mt-1">Your skills analyzed and verified by OpenAI</p>
        </div>
        <Button className="gap-2 bg-[#B6FF00] text-[#1C073A] hover:brightness-90">
          <Plus className="h-4 w-4" />
          Add Skill
        </Button>
      </div>

      {skills.length === 0 ? (
        <div className="py-12 text-center">
          <p className="text-gray-600">No skills added yet. Start by adding your first skill for AI verification.</p>
        </div>
      ) : (
        <AISkillVerificationDisplay skills={skillsWithAI} loading={loading} />
      )}
    </Card>
  )
}
