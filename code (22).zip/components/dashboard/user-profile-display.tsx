"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle2 } from "lucide-react"

interface UserProfileData {
  name?: string
  email?: string
  learningSource?: string
  hasWorkExperience?: boolean
  previousExperience?: string
  canProveSkill?: boolean
  proofLink?: string
  proofDescription?: string
  selectedJobs?: string[]
  verified?: boolean
}

export function UserProfileDisplay({ data }: { data: UserProfileData }) {
  return (
    <div className="space-y-4">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div>
              <CardTitle>{data.name}</CardTitle>
              <CardDescription>{data.email}</CardDescription>
            </div>
            {data.verified && <CheckCircle2 className="h-5 w-5 text-green-600" />}
          </div>
        </CardHeader>
      </Card>

      {/* Learning Source */}
      {data.learningSource && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Learning Background</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm">
              <span className="font-semibold">Learned through:</span> {data.learningSource}
            </p>
          </CardContent>
        </Card>
      )}

      {/* Work Experience */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Experience</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <p className="text-sm">
            <span className="font-semibold">Field Experience:</span> {data.hasWorkExperience ? "Yes" : "No"}
          </p>
          {data.previousExperience && (
            <div className="bg-blue-50 p-3 rounded-lg border border-blue-100">
              <p className="text-sm text-gray-700">{data.previousExperience}</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Proof Information */}
      {data.canProveSkill && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Proof of Skills</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {data.proofLink && (
              <div>
                <p className="text-xs font-medium text-gray-500 uppercase mb-1">Portfolio Link</p>
                <a
                  href={data.proofLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:underline break-all text-sm"
                >
                  {data.proofLink}
                </a>
              </div>
            )}
            {data.proofDescription && (
              <div>
                <p className="text-xs font-medium text-gray-500 uppercase mb-1">Description</p>
                <p className="text-sm text-gray-700">{data.proofDescription}</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Job Profiles */}
      {data.selectedJobs && data.selectedJobs.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Target Roles</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {data.selectedJobs.map((job) => (
                <Badge key={job} variant="secondary">
                  {job}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
