"use client"

import { useState } from "react"
import EduplexSidebar from "@/components/dashboard/eduplex-sidebar"
import DashboardTopbar from "@/components/dashboard/dashboard-topbar"

interface DashboardLayoutProps {
  children: React.ReactNode
  title: string
  description?: string
}

export default function DashboardLayout({ children, title, description }: DashboardLayoutProps) {
  return (
    <div className="flex min-h-screen bg-[#FAFAF8] text-gray-900">
      <EduplexSidebar />
      
      {/* Main Content Wrapper */}
      <div className="flex-1 flex flex-col min-h-screen">
        {/* Fixed Topbar */}
        <DashboardTopbar title={title} description={description} />
        
        {/* Content Area - added support for editable profile and full-width content */}
        <main className="flex-1 overflow-y-auto pb-8 px-8 pt-10">
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  )
}
