"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Save, X, AlertCircle, CheckCircle2, Loader2 } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { AvatarUpload } from "./avatar-upload"

export interface ProfileData {
  id: string
  name: string
  email: string
  phone: string
  bio: string
  role: string
  location: string
  skills: string[]
  username: string
  avatar_url: string
  created_at: string
  updated_at: string
}

interface ProfileFormProps {
  profile: ProfileData
  onSave: (data: Partial<ProfileData>) => Promise<void>
  onCancel: () => void
  isLoading?: boolean
}

interface ValidationErrors {
  [key: string]: string
}

export function ProfileForm({ profile, onSave, onCancel, isLoading = false }: ProfileFormProps) {
  const [formData, setFormData] = useState<Partial<ProfileData>>(profile)
  const [errors, setErrors] = useState<ValidationErrors>({})
  const [isSaving, setIsSaving] = useState(false)
  const [saveMessage, setSaveMessage] = useState<{ type: "success" | "error"; text: string } | null>(null)

  const validateForm = (): boolean => {
    const newErrors: ValidationErrors = {}

    if (!formData.name?.trim()) newErrors.name = "Name is required"
    if (!formData.email?.trim()) newErrors.email = "Email is required"
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Invalid email format"
    }
    if (formData.phone && !/^\+?[\d\s\-()]+$/.test(formData.phone)) {
      newErrors.phone = "Invalid phone format"
    }
    if (formData.username && formData.username.length < 3) {
      newErrors.username = "Username must be at least 3 characters"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleChange = (field: keyof ProfileData, value: string | string[]) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    // Clear error for this field when user starts typing
    if (errors[field]) {
      setErrors((prev) => {
        const newErrors = { ...prev }
        delete newErrors[field]
        return newErrors
      })
    }
  }

  const handleSkillsChange = (skill: string) => {
    const currentSkills = formData.skills || []
    if (currentSkills.includes(skill)) {
      handleChange("skills", currentSkills.filter((s) => s !== skill))
    } else {
      handleChange("skills", [...currentSkills, skill])
    }
  }

  const handleSave = async () => {
    if (!validateForm()) return

    setIsSaving(true)
    setSaveMessage(null)

    try {
      await onSave(formData)
      setSaveMessage({ type: "success", text: "Profile updated successfully!" })
      setTimeout(() => setSaveMessage(null), 3000)
    } catch (error) {
      setSaveMessage({
        type: "error",
        text: error instanceof Error ? error.message : "Failed to save profile",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const skillsOptions = [
    "React",
    "TypeScript",
    "Next.js",
    "Tailwind CSS",
    "Node.js",
    "Python",
    "UI Design",
    "Web Development",
  ]

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="space-y-6"
    >
      {/* Message Alert */}
      {saveMessage && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className={`p-4 rounded-lg flex items-center gap-2 ${
            saveMessage.type === "success"
              ? "bg-green-50 text-green-800 border border-green-200"
              : "bg-red-50 text-red-800 border border-red-200"
          }`}
        >
          {saveMessage.type === "success" ? (
            <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
          ) : (
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
          )}
          <span className="text-sm font-medium">{saveMessage.text}</span>
        </motion.div>
      )}

      {/* Avatar Upload */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Profile Picture</h3>
        <AvatarUpload
          currentUrl={formData.avatar_url}
          onUpload={(url) => handleChange("avatar_url", url)}
        />
      </div>

      {/* Basic Information */}
      <div className="bg-white rounded-lg border border-gray-200 p-6 space-y-4">
        <h3 className="text-lg font-semibold text-gray-900">Basic Information</h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Name</label>
            <Input
              value={formData.name || ""}
              onChange={(e) => handleChange("name", e.target.value)}
              placeholder="Your full name"
              className={errors.name ? "border-red-500" : ""}
            />
            {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Username</label>
            <Input
              value={formData.username || ""}
              onChange={(e) => handleChange("username", e.target.value)}
              placeholder="username"
              className={errors.username ? "border-red-500" : ""}
            />
            {errors.username && <p className="text-red-500 text-xs mt-1">{errors.username}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
            <Input
              type="email"
              value={formData.email || ""}
              onChange={(e) => handleChange("email", e.target.value)}
              placeholder="your@email.com"
              className={errors.email ? "border-red-500" : ""}
            />
            {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Phone</label>
            <Input
              type="tel"
              value={formData.phone || ""}
              onChange={(e) => handleChange("phone", e.target.value)}
              placeholder="+1 (555) 123-4567"
              className={errors.phone ? "border-red-500" : ""}
            />
            {errors.phone && <p className="text-red-500 text-xs mt-1">{errors.phone}</p>}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
          <Input
            value={formData.location || ""}
            onChange={(e) => handleChange("location", e.target.value)}
            placeholder="City, Country"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Role</label>
          <Input
            value={formData.role || ""}
            onChange={(e) => handleChange("role", e.target.value)}
            placeholder="e.g., Full Stack Developer"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Bio</label>
          <Textarea
            value={formData.bio || ""}
            onChange={(e) => handleChange("bio", e.target.value)}
            placeholder="Tell us about yourself..."
            className="min-h-24"
          />
        </div>
      </div>

      {/* Skills */}
      <div className="bg-white rounded-lg border border-gray-200 p-6 space-y-4">
        <h3 className="text-lg font-semibold text-gray-900">Skills</h3>
        <div className="flex flex-wrap gap-2">
          {skillsOptions.map((skill) => (
            <button
              key={skill}
              onClick={() => handleSkillsChange(skill)}
              className={`px-4 py-2 rounded-lg font-medium transition ${
                formData.skills?.includes(skill)
                  ? "bg-indigo-600 text-white"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              {skill}
            </button>
          ))}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex gap-4">
        <Button
          onClick={handleSave}
          disabled={isSaving || isLoading}
          className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white"
        >
          {isSaving ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin mr-2" />
              Saving...
            </>
          ) : (
            <>
              <Save className="w-4 h-4 mr-2" />
              Save Changes
            </>
          )}
        </Button>
        <Button onClick={onCancel} variant="outline" disabled={isSaving}>
          <X className="w-4 h-4 mr-2" />
          Cancel
        </Button>
      </div>
    </motion.div>
  )
}
