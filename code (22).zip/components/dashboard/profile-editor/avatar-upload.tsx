"use client"

import { useState, useRef } from "react"
import { motion } from "framer-motion"
import { Upload, X, CheckCircle2 } from 'lucide-react'
import Image from "next/image"

interface AvatarUploadProps {
  currentUrl?: string
  onUpload: (url: string) => void
}

export function AvatarUpload({ currentUrl, onUpload }: AvatarUploadProps) {
  const [preview, setPreview] = useState<string | null>(currentUrl || null)
  const [isLoading, setIsLoading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    // Validate file type
    if (!file.type.startsWith("image/")) {
      alert("Please select an image file")
      return
    }

    // Validate file size (5MB max)
    if (file.size > 5 * 1024 * 1024) {
      alert("File size must be less than 5MB")
      return
    }

    // Create preview
    const reader = new FileReader()
    reader.onload = (e) => {
      const result = e.target?.result as string
      setPreview(result)

      // Simulate upload (in production, send to backend/storage)
      setIsLoading(true)
      setTimeout(() => {
        onUpload(result)
        setIsLoading(false)
      }, 500)
    }
    reader.readAsDataURL(file)
  }

  const handleRemove = () => {
    setPreview(null)
    onUpload("")
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  return (
    <div className="space-y-4">
      {preview ? (
        <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} className="relative w-32 h-32 mx-auto">
          <div className="relative w-full h-full rounded-full overflow-hidden border-4 border-indigo-600 bg-gray-100">
            <Image src={preview || "/placeholder.svg"} alt="Avatar preview" fill className="object-cover" />
          </div>
          {isLoading ? (
            <div className="absolute inset-0 flex items-center justify-center bg-black/20 rounded-full">
              <div className="animate-spin">
                <div className="w-8 h-8 border-4 border-white border-t-transparent rounded-full" />
              </div>
            </div>
          ) : (
            <motion.button
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              onClick={handleRemove}
              className="absolute -top-2 -right-2 bg-red-500 hover:bg-red-600 text-white rounded-full p-2 transition"
            >
              <X className="w-4 h-4" />
            </motion.button>
          )}
        </motion.div>
      ) : (
        <motion.button
          whileHover={{ scale: 1.02 }}
          onClick={() => fileInputRef.current?.click()}
          className="w-32 h-32 mx-auto rounded-full border-2 border-dashed border-gray-300 hover:border-indigo-600 bg-gray-50 hover:bg-indigo-50 flex items-center justify-center transition cursor-pointer"
        >
          <Upload className="w-6 h-6 text-gray-400 group-hover:text-indigo-600" />
        </motion.button>
      )}

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileSelect}
        className="hidden"
      />

      <p className="text-center text-sm text-gray-600">
        {preview ? "Click the X to change" : "Click to upload a profile picture"}
      </p>
    </div>
  )
}
