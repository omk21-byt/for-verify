import { Edit } from "lucide-react"

export default function ProfileCard({ profile = {}, onEdit }: any) {
  return (
    <div className="card-surface p-6 rounded-xl-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <img src={profile.avatar || "/placeholder.svg?height=80&width=80"} alt="avatar" className="h-16 w-16 rounded-2xl object-cover" />
          <div>
            <div className="font-semibold text-[#0f172a]">{profile.name || "Taylor Smith"}</div>
            <div className="text-xs text-[#6b7280]">{profile.title || "Product Designer"}</div>
            <div className="text-xs text-[#6b7280] mt-2">{profile.location || "San Francisco, CA"}</div>
          </div>
        </div>

        <button onClick={onEdit} className="px-3 py-2 rounded-md border" style={{ borderColor: 'var(--border)' }}>
          <Edit className="w-4 h-4 mr-2 inline" /> Edit
        </button>
      </div>

      <div className="mt-4 border-t pt-4" style={{ borderColor: 'var(--border)' }}>
        <div className="text-sm text-[#6b7280]">Skills</div>
        <div className="mt-2 flex flex-wrap gap-2">
          {(profile.skills || ["UI/UX", "Figma", "Prototyping"]).slice(0,6).map((s: string, i: number) => (
            <div key={i} className="text-xs px-3 py-1 rounded-full bg-[#f1eaff] text-[#7c3aed]">{s}</div>
          ))}
        </div>
      </div>
    </div>
  )
}
