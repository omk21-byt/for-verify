"use client"

import { Bell, Settings, LogOut, User } from 'lucide-react'
import { useRouter, usePathname } from 'next/navigation'
import { useState, useEffect } from "react"
import { useAuth } from '@/app/providers'

interface TopbarProps {
  name?: string
}

export default function Topbar({ name }: TopbarProps) {
  const router = useRouter()
  const pathname = usePathname()
  const { user } = useAuth()
  const [showMenu, setShowMenu] = useState(false)
  const [unreadCount, setUnreadCount] = useState(0)
  const [showNotifications, setShowNotifications] = useState(false)

  useEffect(() => {
    if (!user) return

    const fetchUnreadCount = async () => {
      try {
        const res = await fetch(`/api/notifications?userId=${user.id}&unreadOnly=true`)
        if (!res.ok) throw new Error("Failed to fetch notifications")
        const data = await res.json()
        setUnreadCount(data.length)
      } catch (error) {
        console.error("[v0] Error fetching unread count:", error)
      }
    }

    fetchUnreadCount()
    const interval = setInterval(fetchUnreadCount, 3000)
    return () => clearInterval(interval)
  }, [user])

  const getPageName = () => {
    if (name) return name
    
    const routeNames: Record<string, string> = {
      "/dashboard": "Dashboard",
      "/messages": "Messages",
      "/bookmarks": "Bookmarks",
      "/notifications": "Notifications",
      "/calendar": "Calendar",
      "/settings": "Settings",
      "/search": "Community",
      "/courses": "My Courses",
      "/classes": "My Classes",
    }
    
    return routeNames[pathname] || "Dashboard"
  }

  const handleLogout = async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST" })
      router.push("/login")
    } catch (err) {
      console.error("Logout error:", err)
    }
  }

  const handleNotificationClick = () => {
    router.push("/notifications")
  }

  const pageName = getPageName()

  return (
    <div className="fixed top-0 right-0 left-0 lg:left-64 h-16 bg-white border-b border-gray-200 px-6 flex items-center justify-between z-30">
      {/* Left side - Title */}
      <h2 className="text-lg font-semibold text-gray-900">{pageName}</h2>

      {/* Right side - Actions */}
      <div className="flex items-center gap-4">
        {/* Notifications */}
        <button 
          onClick={handleNotificationClick}
          className="p-2 hover:bg-gray-100 rounded-lg transition relative"
        >
          <Bell className="w-5 h-5 text-gray-600" />
          {unreadCount > 0 && (
            <span className="absolute top-0 right-0 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center font-semibold">
              {unreadCount > 9 ? '9+' : unreadCount}
            </span>
          )}
        </button>

        {/* Settings */}
        <button className="p-2 hover:bg-gray-100 rounded-lg transition">
          <Settings className="w-5 h-5 text-gray-600" />
        </button>

        {/* User Menu */}
        <div className="relative">
          <button
            onClick={() => setShowMenu(!showMenu)}
            className="flex items-center gap-2 px-3 py-2 hover:bg-gray-100 rounded-lg transition"
          >
            <div className="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center text-white text-sm font-medium">
              {pageName.charAt(0).toUpperCase()}
            </div>
            <span className="text-sm font-medium text-gray-700 hidden sm:inline">{pageName}</span>
          </button>

          {/* Dropdown Menu */}
          {showMenu && (
            <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 py-2 z-40">
              <button className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-100 flex items-center gap-2">
                <User className="w-4 h-4" />
                Profile
              </button>
              <button
                onClick={handleLogout}
                className="w-full px-4 py-2 text-left text-sm text-red-600 hover:bg-red-50 flex items-center gap-2"
              >
                <LogOut className="w-4 h-4" />
                Logout
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
