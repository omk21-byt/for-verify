export default function SkillVerificationCard({ skills = [] }: any) {
  const list = skills.length
    ? skills.slice(0, 5).map((s: any) => {
        // If it's an object with a skills property, use that. Otherwise use the skill name or string value
        if (typeof s === "object" && s.skills?.name) {
          return s.skills.name
        } else if (typeof s === "object" && s.name) {
          return s.name
        } else if (typeof s === "string") {
          return s
        }
        return "Skill"
      })
    : ["Figma", "Sketch", "React", "SQL", "Photoshop"]

  return (
    <div className="card-surface p-6 rounded-xl-2">
      <div className="flex items-center justify-between">
        <div className="text-lg font-semibold">Skill Verification</div>
        <div className="text-sm text-[#6b7280]">Verify</div>
      </div>

      <div className="mt-3 flex flex-wrap gap-2">
        {list.map((s: string, i: number) => (
          <div key={i} className="px-3 py-1 rounded-full text-xs bg-[#f1eaff] text-[#7c3aed]">
            {s}
          </div>
        ))}
      </div>
    </div>
  )
}
