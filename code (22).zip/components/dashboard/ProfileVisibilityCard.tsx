"use client"

import { Eye, EyeOff } from "lucide-react"
import { useState } from "react"

export function ProfileVisibilityCard({ isPublic = true, onToggle }: { isPublic?: boolean; onToggle?: () => void }) {
  const [loading, setLoading] = useState(false)

  const handleToggle = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/profiles/toggle-visibility", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isPublic: !isPublic }),
      })

      if (!response.ok) throw new Error("Failed to update visibility")

      const data = await response.json()
      console.log("[v0] Profile visibility updated:", data)
      if (onToggle) onToggle()
    } catch (error) {
      console.error("[v0] Error toggling visibility:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="card-surface p-6 rounded-2xl shadow-sm border border-gray-200">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-semibold text-gray-900 mb-1">Profile Visibility</h3>
          <p className="text-xs text-gray-600">
            {isPublic
              ? "Your profile is visible to other users on the search page"
              : "Your profile is hidden from the search page"}
          </p>
        </div>
        <button
          onClick={handleToggle}
          disabled={loading}
          className={`px-4 py-2 rounded-lg font-medium flex items-center gap-2 transition ${
            isPublic ? "bg-green-100 text-green-700 hover:bg-green-200" : "bg-gray-100 text-gray-700 hover:bg-gray-200"
          } ${loading ? "opacity-50 cursor-not-allowed" : ""}`}
        >
          {isPublic ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
          {isPublic ? "Visible" : "Hidden"}
        </button>
      </div>
    </div>
  )
}
