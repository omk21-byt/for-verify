"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { ProfilePreviewCard } from "@/components/Signup/profile-preview-card"
import { ProfileCompletionStatus } from "@/components/Signup/profile-completion-status"
import { JobProfileSelector } from "@/components/Signup/job-profile-selector"
import { ExperienceSourceSelector } from "@/components/Signup/experience-source-selector"
import { SkillProofSelector } from "@/components/Signup/skill-proof-selector"
import { SkillCategorySelector, getJobsForSkills } from "@/components/Signup/skill-category-selector"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"

interface VerifySkillsProps {
  formData?: {
    name: string
    email: string
    expertise: string
    interests: string
    portfolio: string
    experience: string
  }
}

export default function VerifySkills({ formData }: VerifySkillsProps) {
  const router = useRouter()
  const { toast } = useToast()

  const [selectedSkills, setSelectedSkills] = useState<string[]>([])
  const [availableJobs, setAvailableJobs] = useState<string[]>([])
  const [selectedJobs, setSelectedJobs] = useState<string[]>([])
  const [learningSource, setLearningSource] = useState<string>("")
  const [hasWorkExperience, setHasWorkExperience] = useState<boolean | null>(null)
  const [previousExperience, setPreviousExperience] = useState<string>("")
  const [canProveSkill, setCanProveSkill] = useState<boolean | null>(null)
  const [proofLink, setProofLink] = useState<string>("")
  const [proofDescription, setProofDescription] = useState<string>("")
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false)
  const [isSaving, setIsSaving] = useState<boolean>(false)

  const skillsString = selectedSkills.join(", ")

  async function analyzeSkills() {
    if (selectedSkills.length === 0) {
      toast({ title: "Select skills", description: "Choose at least one skill to analyze." })
      return
    }
    setIsAnalyzing(true)
    await new Promise((r) => setTimeout(r, 1500))
    const jobs = getJobsForSkills(selectedSkills)
    setAvailableJobs(jobs.length ? jobs : ["Freelancer", "Generalist"])
    setIsAnalyzing(false)
    toast({ title: "Analysis complete", description: "Suggested job roles added." })
  }

  async function analyzeExperience() {
    setIsAnalyzing(true)
    await new Promise((r) => setTimeout(r, 1200))
    if (hasWorkExperience && availableJobs.length === 0) {
      setAvailableJobs(["Experienced Professional", "Mid-level Specialist"])
    }
    setIsAnalyzing(false)
    toast({ title: "Experience analyzed", description: "AI reviewed your experience." })
  }

  async function verifyProof() {
    setIsAnalyzing(true)
    await new Promise((r) => setTimeout(r, 1500))
    if (proofDescription && selectedSkills.length === 0) {
      const inferred = proofDescription
        .split(/\W+/)
        .map((w) => w.trim())
        .filter(Boolean)
        .slice(0, 5)
      setSelectedSkills((prev) => Array.from(new Set([...prev, ...inferred])))
    }
    setIsAnalyzing(false)
    toast({ title: "Proof verified", description: "AI reviewed your proof and updated profile preview." })
  }

  async function handleSaveProfile() {
    setIsSaving(true)

    const userId = sessionStorage.getItem("userId")
    if (!userId) {
      toast({ title: "Error", description: "User ID not found", variant: "destructive" })
      setIsSaving(false)
      return
    }

    try {
      const skillsData = selectedSkills.map((skill) => ({
        name: skill,
        proofLink,
        proofDescription,
      }))

      const response = await fetch("/api/skills/save", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId,
          skills: skillsData,
          learningSource,
          hasWorkExperience,
          previousExperience,
          canProveSkill,
          selectedJobs,
        }),
      })

      const result = await response.json()
      if (!response.ok) throw new Error(result.error || "Failed to save skills")

      toast({ title: "Profile saved", description: "Starting verification..." })

      sessionStorage.removeItem("userId")
      sessionStorage.removeItem("userData")

      setTimeout(() => router.push("/dashboard"), 1500)
    } catch (error: any) {
      console.error("[verify-skills] save error:", error)
      toast({ title: "Save failed", description: error.message, variant: "destructive" })
    } finally {
      setIsSaving(false)
    }
  }

  // Recalculate available jobs when skills change (debounced)
  useEffect(() => {
    const handler = setTimeout(() => {
      const jobs = getJobsForSkills(selectedSkills)
      setAvailableJobs(jobs.length ? jobs : ["Freelancer"])
    }, 300)
    return () => clearTimeout(handler)
  }, [selectedSkills])

  return (
    <section className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 mt-12 mb-9">
      {/* LEFT SIDE */}
      <div className="lg:col-span-7 space-y-6">
        <div className="bg-white border border-gray-200 rounded-2xl p-4 shadow-sm">
          <h3 className="text-sm font-medium text-gray-900 mb-3">Select skills</h3>
          <SkillCategorySelector selectedSkills={selectedSkills} onSkillsChange={setSelectedSkills} />
          <div className="mt-4 flex gap-3">
            <Button onClick={analyzeSkills} disabled={isAnalyzing}>
              {isAnalyzing ? "Analyzing..." : "Analyze Skills"}
            </Button>
          </div>
        </div>

        <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm">
          <h2 className="text-lg font-semibold text-gray-900 mb-3">Experience & Proof</h2>
          <ExperienceSourceSelector
            learningSource={learningSource}
            hasWorkExperience={hasWorkExperience ?? false}
            previousExperience={previousExperience}
            onLearningSourceChange={setLearningSource}
            onWorkExperienceChange={setHasWorkExperience}
            onPreviousExperienceChange={setPreviousExperience}
          />
          <div className="mt-4">
            <SkillProofSelector
              canProveSkill={canProveSkill ?? false}
              proofLink={proofLink}
              proofDescription={proofDescription}
              onCanProveChange={setCanProveSkill}
              onProofLinkChange={setProofLink}
              onProofDescriptionChange={setProofDescription}
            />
          </div>
          <div className="mt-4 flex gap-3">
            <Button onClick={analyzeExperience} disabled={isAnalyzing}>
              {isAnalyzing ? "Analyzing..." : "Analyze Experience"}
            </Button>
            <Button onClick={verifyProof} disabled={isAnalyzing || !canProveSkill}>
              {isAnalyzing ? "Verifying..." : "Verify Proof"}
            </Button>
          </div>
        </div>

        <Button onClick={handleSaveProfile} className="w-full mt-6" disabled={isSaving || selectedSkills.length === 0}>
          {isSaving ? "Saving..." : "Save & Go to Dashboard"}
        </Button>
      </div>

      {/* RIGHT SIDE */}
      <aside className="lg:col-span-5">
        <div className="sticky top-20 space-y-5">
          <div className="bg-white border border-gray-200 rounded-2xl p-4 shadow-sm">
            <ProfileCompletionStatus
              skills={skillsString}
              about={formData?.expertise || ""}
              sampleUrl={formData?.portfolio || ""}
            />
          </div>

          <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm">
            <h2 className="text-lg font-semibold text-gray-900 mb-3">Suggested job profiles</h2>
            <p className="text-sm text-gray-600 mb-4">
              These roles are suggested based on your selected skills. Pick roles you want to target.
            </p>
            <JobProfileSelector
              availableJobs={availableJobs}
              selectedJobs={selectedJobs}
              onJobsChange={setSelectedJobs}
            />
          </div>

          <div className="bg-white border border-gray-200 rounded-2xl p-4 shadow-sm">
            <ProfilePreviewCard
              skills={skillsString}
              about={formData?.expertise || ""}
              sampleUrl={formData?.portfolio || ""}
            />
          </div>
        </div>
      </aside>
    </section>
  )
}
