"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, LogOut } from "lucide-react"
import { cn } from "@/lib/utils"
import { useRouter } from "next/navigation"

interface NavbarProps {
  user?: any
  loading?: boolean
}

export function Navbar({ user, loading }: NavbarProps = {}) {
  const [mounted, setMounted] = useState(false)
  const router = useRouter()

  useEffect(() => {
    setMounted(true)
  }, [])

  const handleLogout = async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST" })
      router.push("/login")
    } catch (error) {
      console.error("Logout failed", error)
    }
  }

  // Shared button style for primary actions
  const primaryButtonClass = cn(
    "rounded-full px-4",
    "bg-neutral-900 hover:bg-neutral-800 text-white",
    "shadow-[inset_0_1px_0_0_rgba(255,255,255,.15)]",
    "flex items-center gap-1"
  )

  return (
    <header>
      <nav
        className={cn(
          "mx-auto mt-2 flex items-center justify-between gap-3",
          "rounded-full border bg-white/70 px-4 py-2 shadow-sm backdrop-blur-md",
          "dark:bg-black/30",
        )}
        aria-label="Primary"
      >
        {/* Logo */}
        <div className="flex items-center gap-2">
          <div className="grid h-7 w-7 place-items-center rounded-full bg-rose-500 text-white font-semibold text-center leading-4 text-2xl">
            {"✺"}
          </div>
          <span className="font-semibold">Shiftza</span>
        </div>

        {/* Menu links */}
        <ul className="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
          <li>
            <Link href="#features" className="transition-colors hover:text-foreground">
              Features
            </Link>
          </li>
          <li>
            <Link href="#how-it-works" className="transition-colors hover:text-foreground">
              How it Works
            </Link>
          </li>
          <li>
            <Link href="#pricing" className="transition-colors hover:text-foreground">
              Pricing
            </Link>
          </li>
        </ul>

        {/* Action buttons */}
        <div className="flex items-center gap-2">
          {mounted && !loading && !user ? (
            <>
              {/* Login link */}
              <Link
                href="/login"
                className="hidden text-sm text-muted-foreground transition-colors hover:text-foreground md:inline"
              >
                Login
              </Link>

              {/* Signup button */}
              <Button asChild size="sm" className={primaryButtonClass}>
                <Link href="/signup" aria-label="Try shiftza for free">
                  <span className="mr-1">Try shiftza for Free</span>
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </>
          ) : mounted && !loading && user ? (
            <>
              {/* Dashboard button */}
              <Button asChild size="sm" className={primaryButtonClass}>
                <Link href="/dashboard" aria-label="Go to dashboard">
                  <span className="mr-0">Go to Dashboard</span>
                  
                </Link>
              </Button>

              {/* Logout button with LogOut icon */}
              <Button onClick={handleLogout} size="sm" className={primaryButtonClass}>
                <span className="mr-0">Logout</span>
               
              </Button>
            </>
          ) : null}
        </div>
      </nav>
    </header>
  )
}
