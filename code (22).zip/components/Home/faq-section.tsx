"use client"

import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Button } from "@/components/ui/button"

const faqs = [
  {
    question: "Do I really not need a degree to join?",
    answer: (
      <>
        Absolutely not.
        <br />
        <br />
        Shiftza is built for skilled professionals — whether you're self-taught, bootcamp-trained, or learned on the
        job.
        <br />
        <br />
        We verify your skills through portfolios, tests, and real work — not diplomas.
      </>
    ),
  },
  {
    question: "Is it free to join?",
    answer: (
      <>
        Yes — creating a profile and applying to projects is completely free.
        <br />
        <br />
        We only take a small commission when you successfully complete a paid project.
      </>
    ),
  },
  {
    question: "How do you verify skills without degrees?",
    answer: (
      <>
        We use multiple verification methods:
        <br />
        <br />
        Portfolio reviews, skill assessments, peer endorsements, and most importantly — your actual work on the platform
        builds your reputation.
      </>
    ),
  },
  {
    question: "What kind of projects can I find?",
    answer: (
      <>
        Everything from short-term gigs to long-term contracts.
        <br />
        <br />
        Web development, mobile apps, design, data analysis, content creation, and more.
        <br />
        <br />
        Companies post projects ranging from $500 to $50,000+.
      </>
    ),
  },
  {
    question: "How does payment work?",
    answer: (
      <>
        All payments go through our secure escrow system.
        <br />
        <br />
        Companies fund projects upfront, and you get paid when milestones are completed.
        <br />
        <br />
        No chasing invoices. No payment disputes.
      </>
    ),
  },
  {
    question: "Can companies really hire without worrying about layoffs?",
    answer: (
      <>
        Yes — that's the whole point.
        <br />
        <br />
        Project-based hiring means companies scale up when they need talent and scale down naturally when projects end.
        <br />
        <br />
        No awkward layoffs. No severance packages. Just flexible collaboration.
      </>
    ),
  },
]

interface FAQSectionProps {
  onOpenInstall?: () => void
}

export default function FAQSection({ onOpenInstall }: FAQSectionProps) {
  return (
    <section className="relative shadow-sm border border-[#E2E8F0] p-4 sm:p-6 md:p-10 bg-white overflow-hidden md:px-10 mx-auto md:py-3 my-11 rounded-xl mt-0">
      <div className="max-w-4xl mx-auto my-3.5">
        <div className="text-center mb-8 mt-8">
          <h2 className="text-3xl md:text-4xl font-bold text-[#0F172A] mb-2">Frequently Asked Questions</h2>
          <p className="text-[#64748B] text-lg">Everything you need to know about Shiftza</p>
        </div>

        <Accordion type="single" collapsible className="w-full space-y-3">
          {faqs.map((faq, index) => (
            <AccordionItem key={index} value={`item-${index}`} className="border border-[#E2E8F0] rounded-lg px-4">
              <AccordionTrigger className="text-left font-semibold text-[#0F172A] hover:text-[#2563EB] py-4">
                {faq.question}
              </AccordionTrigger>
              <AccordionContent className="text-[#475569] pb-4">{faq.answer}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>

        <div className="text-center mt-2">
          <p className="text-[#64748B] mb-4">Still have questions?</p>
          <Button
            onClick={onOpenInstall}
            className="bg-[#2563EB] text-white hover:bg-[#1d4ed8] px-6 py-2 rounded-lg font-medium"
          >
            Contact Support
          </Button>
        </div>
      </div>
    </section>
  )
}
