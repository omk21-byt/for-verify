"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Send, X, Linkedin, Instagram } from "lucide-react"

const MAX_HISTORY = 500

// ✅ Full KNOWLEDGE_BASE from ai-chatbot (2).tsx
const KNOWLEDGE_BASE = {
  platform: [
    {
      q: ["what is shiftza", "tell me about shiftza", "shiftza platform"],
      a: "⚙️ Shiftza is a skills-first job & gig platform connecting talent with verified projects, learning, and real opportunities. 💼",
    },
    {
      q: ["who founded shiftza", "who is the founder", "who owns shiftza"],
      a: "🏆 Shiftza was founded by sc0tt, a visionary for a skills-first job world! 🌍",
    },
    {
      q: ["shiftza mission", "what is shiftza mission", "shiftza goal"],
      a: "🌍 Shiftza's mission: hiring is skills-first and fair. Talent gets noticed for ability, not background. 💫",
    },
    {
      q: ["how does shiftza work", "how shiftza works", "explain shiftza"],
      a: "🔧 Shiftza connects your skills to verified projects. You apply, deliver, and earn—all in one spot! ⚡",
    },
    {
      q: ["shiftza features", "what features does shiftza have", "shiftza tools"],
      a: "🧩 Shiftza offers skill tests, badges, verified portfolios, and a real talent marketplace. 🎯",
    },
    {
      q: ["is shiftza free", "shiftza pricing", "shiftza cost"],
      a: "💰 Shiftza's core is free for all users! Upgrade for pro features and more exposure. ⚡",
    },
    {
      q: ["shiftza website", "shiftza platform website", "where is shiftza"],
      a: "🌐 Shiftza is a smart platform where your skills speak louder than resumes. Build your portfolio, get hired, and grow! 🚀",
    },
  ],
  jobs: [
    {
      q: ["find jobs", "how to find jobs", "job search"],
      a: "💼 Browse trending jobs matching your skills. Keep your portfolio strong—opportunity comes to prepared minds! 🌟",
    },
    {
      q: ["apply for job", "how to apply", "job application"],
      a: "📄 Applying is easy! Upload your resume or create a skills-based profile. Stand out and get hired! 💪",
    },
    {
      q: ["full time jobs", "permanent jobs", "full time work"],
      a: "💼 Shiftza has full-time positions for all skill levels. Build your profile and get discovered by employers! 🎯",
    },
    {
      q: ["part time jobs", "part time work", "flexible jobs"],
      a: "⏰ Find part-time roles that fit your schedule. Work flexibly while building your career! 🌈",
    },
    {
      q: ["job categories", "types of jobs", "what jobs available"],
      a: "🎯 Shiftza has jobs in tech, design, writing, marketing, sales, and more. Find your perfect fit! 💡",
    },
    {
      q: ["how to get hired", "get job offer", "land a job"],
      a: "🚀 Complete skill challenges, earn badges, and build a strong portfolio. Employers notice verified talent! ⭐",
    },
    {
      q: ["job requirements", "what skills needed", "job qualifications"],
      a: "🎓 Each job lists required skills. Take challenges to prove your expertise and apply with confidence! 💪",
    },
    {
      q: ["job salary", "how much earn", "job payment"],
      a: "💸 Salaries vary by role and experience. Shiftza shows pay ranges upfront so you know what to expect! 💰",
    },
  ],
  gigs: [
    {
      q: ["what is gig", "gig work", "gig jobs"],
      a: "🎯 Gigs are short-term projects you can complete flexibly. Perfect for freelancers and side hustlers! 🌟",
    },
    {
      q: ["find gigs", "browse gigs", "gig opportunities"],
      a: "🔍 Browse available gigs, check requirements, and apply instantly. Work on your terms! ⚡",
    },
    {
      q: ["gig payment", "gig earnings", "how much gig pay"],
      a: "💵 Get paid per completed gig. Payments are secure and processed quickly to your account! 🔐",
    },
    {
      q: ["gig duration", "how long gig", "gig timeline"],
      a: "⏱️ Gigs range from hours to weeks. Choose projects that fit your schedule! 🎯",
    },
    {
      q: ["multiple gigs", "work multiple gigs", "gig stacking"],
      a: "🚀 Work multiple gigs simultaneously! Build income and experience faster. 💪",
    },
    {
      q: ["gig reviews", "client feedback", "gig rating"],
      a: "⭐ Complete gigs well and earn 5-star reviews. Great reviews unlock better opportunities! 🌟",
    },
  ],
  skills: [
    {
      q: ["verify skills", "skill verification", "how to verify skills"],
      a: "✅ Take skill challenges to verify your expertise. Verified skills boost your profile visibility! 🎯",
    },
    {
      q: ["skill challenges", "take challenge", "skill test"],
      a: "🧠 Complete timed challenges to prove your skills. Pass and earn badges that employers trust! 💡",
    },
    {
      q: ["earn badges", "badges", "skill badges"],
      a: "🏅 Earn badges for each verified skill. Badges prove your expertise and increase job offers! ⭐",
    },
    {
      q: ["learn new skills", "skill development", "improve skills"],
      a: "📚 Take courses and challenges to learn. Every new skill opens more job opportunities! 🚀",
    },
    {
      q: ["skill categories", "types of skills", "skill types"],
      a: "🎯 Shiftza covers tech, design, writing, marketing, sales, and more. Pick your path! 💼",
    },
    {
      q: ["skill level", "beginner intermediate advanced", "skill difficulty"],
      a: "📊 Skills range from beginner to expert. Start where you are and level up! 🌟",
    },
    {
      q: ["skill endorsement", "get endorsed", "skill recommendation"],
      a: "👥 Get endorsed by colleagues and clients. Endorsements boost your credibility! 💪",
    },
  ],
  portfolio: [
    {
      q: ["build portfolio", "create portfolio", "portfolio building"],
      a: "🎨 Showcase your work on Shiftza. A strong portfolio attracts more job offers! 🌟",
    },
    {
      q: ["portfolio projects", "add projects", "portfolio examples"],
      a: "📁 Add completed projects to your portfolio. Show employers what you can do! 💼",
    },
    {
      q: ["portfolio visibility", "portfolio exposure", "get noticed"],
      a: "👀 Complete challenges and earn badges to boost portfolio visibility. Get discovered! 🚀",
    },
    {
      q: ["portfolio tips", "improve portfolio", "portfolio advice"],
      a: "💡 Use high-quality images, clear descriptions, and verified skills. Make it shine! ✨",
    },
    {
      q: ["portfolio reviews", "portfolio feedback", "improve portfolio"],
      a: "📝 Get feedback from mentors and peers. Refine your portfolio to stand out! 🎯",
    },
  ],
  freelance: [
    {
      q: ["freelance work", "freelancing", "become freelancer"],
      a: "🌍 Freelance for freedom! Browse gigs that fit your style or showcase your verified skills for more clients. 💼",
    },
    {
      q: ["remote work", "work from home", "remote jobs"],
      a: "🏠 Most Shiftza jobs are remote. Work from anywhere, anytime! 🌎",
    },
    {
      q: ["freelance income", "freelance earnings", "make money freelance"],
      a: "💰 Build steady income with multiple gigs. Earn more as you gain experience and reviews! 📈",
    },
    {
      q: ["freelance rates", "set rates", "freelance pricing"],
      a: "💵 Set competitive rates based on your skills and experience. Shiftza shows market rates! 📊",
    },
    {
      q: ["freelance contracts", "project agreement", "work contract"],
      a: "📋 Clear contracts protect both you and clients. Understand terms before accepting! ✅",
    },
  ],
  hiring: [
    {
      q: ["hire talent", "post job", "hire on shiftza"],
      a: "🚀 Want to hire? Post a project and connect with verified Shiftza professionals instantly! 💼",
    },
    {
      q: ["find talent", "search talent", "talent pool"],
      a: "🔍 Browse verified professionals filtered by skills, experience, and ratings. Find your perfect match! ⭐",
    },
    {
      q: ["post project", "create job posting", "post gig"],
      a: "📝 Post your project with clear requirements and budget. Qualified talent will apply! 🎯",
    },
    {
      q: ["hire freelancer", "hire contractor", "hire professional"],
      a: "👥 Hire vetted freelancers with proven skills and great reviews. Risk-free hiring! ✅",
    },
    {
      q: ["team building", "hire team", "build team"],
      a: "👨‍💼 Build your dream team on Shiftza. Access talent from around the world! 🌍",
    },
  ],
  payments: [
    {
      q: ["payment method", "how to pay", "payment options"],
      a: "💳 Shiftza accepts multiple payment methods. Choose what works for you! 💰",
    },
    {
      q: ["secure payment", "payment security", "safe payment"],
      a: "🔐 Payments on Shiftza are secure and encrypted. Your money is protected! ✅",
    },
    {
      q: ["withdraw money", "cash out", "get paid"],
      a: "💸 Complete gigs, withdraw, and earn steadily. Fast payouts to your account! 🏦",
    },
    {
      q: ["payment processing", "how long payment", "payment time"],
      a: "⏱️ Payments process within 3-5 business days. Track your earnings anytime! 📊",
    },
    {
      q: ["payment dispute", "payment issue", "payment problem"],
      a: "⚠️ Contact support for payment issues. Shiftza protects both parties fairly! 🤝",
    },
    {
      q: ["invoice", "billing", "payment receipt"],
      a: "📄 Get invoices for all transactions. Keep records for taxes and accounting! 📋",
    },
  ],
  profile: [
    {
      q: ["create profile", "set up profile", "profile setup"],
      a: "👤 Create your profile with skills, experience, and a professional photo. Make a great first impression! 📸",
    },
    {
      q: ["profile picture", "profile photo", "upload photo"],
      a: "📷 Use a clear, professional photo. Good photos increase job offers by 40%! 📈",
    },
    {
      q: ["profile headline", "bio", "about me"],
      a: "✍️ Write a compelling headline and bio. Show employers why you're the best fit! 💡",
    },
    {
      q: ["profile completeness", "complete profile", "profile score"],
      a: "✅ Complete all profile sections for better visibility. Full profiles get 3x more offers! 🚀",
    },
    {
      q: ["profile verification", "verify profile", "profile badge"],
      a: "✔️ Verify your email and skills. Verified profiles rank higher in searches! ⭐",
    },
  ],
  learning: [
    {
      q: ["learn skills", "skill courses", "training"],
      a: "📚 Take courses and challenges to learn. Every new skill opens more opportunities! 🎓",
    },
    {
      q: ["skill improvement", "get better", "level up"],
      a: "📈 Practice with challenges, learn from feedback, and improve daily. Growth never stops! 💪",
    },
    {
      q: ["mentorship", "find mentor", "get guidance"],
      a: "👨‍🏫 Connect with experienced mentors on Shiftza. Learn from the best! 🌟",
    },
    {
      q: ["resources", "learning materials", "tutorials"],
      a: "📖 Access guides, tutorials, and resources. Learn at your own pace! 🎯",
    },
    {
      q: ["certification", "get certified", "skill certificate"],
      a: "🎓 Earn certificates for completed courses. Boost your resume! 📜",
    },
  ],
  community: [
    {
      q: ["community", "shiftza community", "connect people"],
      a: "👥 Join a community of talented professionals. Network and grow together! 🤝",
    },
    {
      q: ["networking", "meet professionals", "connect"],
      a: "🌐 Connect with peers, mentors, and clients. Build valuable relationships! 💼",
    },
    {
      q: ["events", "webinars", "workshops"],
      a: "🎤 Attend webinars and workshops to learn and network. Free for all members! 📅",
    },
    {
      q: ["forums", "discussion", "ask questions"],
      a: "💬 Ask questions and share knowledge in forums. Get help from the community! 🤗",
    },
  ],
  support: [
    {
      q: ["help", "support", "need help"],
      a: "🧠 Need help? Tell me what's confusing, and I'll guide you. Every problem is a new skill challenge! 😉",
    },
    {
      q: ["contact support", "customer service", "help desk"],
      a: "📞 Contact our support team anytime. We're here to help you succeed! 💬",
    },
    {
      q: ["faq", "frequently asked", "common questions"],
      a: "❓ Check our FAQ section for quick answers. Most questions are answered there! 📖",
    },
    {
      q: ["report issue", "bug report", "problem"],
      a: "🐛 Report issues to our support team. We fix bugs quickly! ⚡",
    },
    {
      q: ["feedback", "suggestion", "improvement"],
      a: "💡 Share your feedback! We use it to improve Shiftza for everyone! 🙌",
    },
  ],
  motivation: [
    {
      q: ["motivation", "inspire me", "motivate"],
      a: "🔥 You're doing amazing. Every new skill brings you closer to your dream job. Keep pushing! 💫",
    },
    {
      q: ["success stories", "success", "inspiration"],
      a: "🌟 Thousands earn on Shiftza daily. Your success story starts now! 🚀",
    },
    {
      q: ["believe in yourself", "confidence", "self doubt"],
      a: "💪 You have what it takes! Shiftza is here to help you shine. Start today! ✨",
    },
    {
      q: ["future", "career growth", "next step"],
      a: "🌠 The future of work is skills-first—and Shiftza leads with verified talent! ⚙️",
    },
  ],
  general: [
    {
      q: ["hello", "hi", "hey"],
      a: "👋 Hi! I'm VibeBot, your Shiftza guide. Ready to boost your skills and career? 🌈",
    },
    {
      q: ["bye", "goodbye", "see you"],
      a: "😊 You're welcome! Keep learning and shining—your new career is waiting! 🌟",
    },
    { q: ["thank you", "thanks", "appreciate"], a: "🙏 Happy to help! Now go build something amazing on Shiftza! 🚀" },
    {
      q: ["how are you", "how you doing", "whats up"],
      a: "😄 I'm great! Ready to help you succeed on Shiftza. What can I do? 💼",
    },
  ],
}

// ✅ Keep full advanced logic from socialai-chatbot.tsx
function calculateSimilarity(str1: string, str2: string) {
  const s1 = str1.toLowerCase().replace(/[^a-z0-9 ]/g, "").trim()
  const s2 = str2.toLowerCase().replace(/[^a-z0-9 ]/g, "").trim()
  if (s1 === s2) return 1
  const words1 = new Set(s1.split(" "))
  const words2 = new Set(s2.split(" "))
  const intersection = new Set([...words1].filter((x) => words2.has(x)))
  const union = new Set([...words1, ...words2])
  return intersection.size / union.size
}

function findBestAnswer(userInput: string, conversationHistory: any[]) {
  const cleanInput = userInput.toLowerCase().trim()

  if (cleanInput.includes("tode") || cleanInput.includes("omkar")) {
    return {
      type: "social",
      text: "🤖 I don't know about this person, but this platform was created by sc0tt. You can contact him here to know better:",
    }
  }

  if (cleanInput.includes("contact")) {
    return { type: "social", text: "📞 You can reach Shiftza here:" }
  }

  let bestMatch = null
  let bestScore = 0
  for (const category in KNOWLEDGE_BASE) {
    for (const item of KNOWLEDGE_BASE[category]) {
      for (const question of item.q) {
        const similarity = calculateSimilarity(cleanInput, question)
        if (similarity > bestScore) {
          bestScore = similarity
          bestMatch = item.a
        }
      }
    }
  }

  if (bestScore > 0.4) return { type: "text", text: bestMatch }

  const recentMessages = conversationHistory.slice(-6).map((m) => m.text.toLowerCase())
  const hasJobContext = recentMessages.some((m) => m.includes("job") || m.includes("work"))
  const hasSkillContext = recentMessages.some((m) => m.includes("skill") || m.includes("learn"))
  const hasGigContext = recentMessages.some((m) => m.includes("gig") || m.includes("project"))

  if (hasJobContext)
    return { type: "text", text: "💼 Looking for jobs? Browse trending positions that match your skills. Keep your portfolio strong! 🌟" }
  else if (hasSkillContext)
    return { type: "text", text: "🎓 Want to improve? Take skill challenges to earn badges and unlock better opportunities! 💪" }
  else if (hasGigContext)
    return { type: "text", text: "🎯 Explore available gigs and work on projects that fit your schedule. Earn while you learn! 💰" }

  return { type: "text", text: "✨ That's interesting! How can I help you find jobs, gigs, or skill growth on Shiftza today? 🚀" }
}

export default function AIChatBot() {
  const [isOpen, setIsOpen] = useState(false)
  const [input, setInput] = useState("")
  const [messages, setMessages] = useState([
    {
      role: "bot",
      text: "🤖 Hey there! I'm VibeBot — your friendly AI guide for Shiftza, jobs & skills. Ready to level up? 🚀",
      type: "text",
    },
  ])

  function addMessage(newMsg: any) {
    setMessages((prev) => {
      const next = [...prev, newMsg]
      return next.length > MAX_HISTORY ? next.slice(-MAX_HISTORY) : next
    })
  }

  const sendMessage = () => {
    if (!input.trim()) return
    const userInput = input.trim()
    setInput("")
    addMessage({ role: "user", text: userInput, type: "text" })
    addMessage({ role: "bot", text: "⚡ Thinking...", type: "text" })

    setTimeout(() => {
      const reply = findBestAnswer(userInput, messages)
      setMessages((prev) => [...prev.slice(0, -1), { role: "bot", ...reply }])
    }, 600)
  }

  return (
    <div className="fixed bottom-8 right-8 z-50">
      <motion.div
        animate={{ y: [0, -6, 0], rotate: [0, 1.5, 0, -1.5, 0] }}
        transition={{ duration: 4, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
        className="relative cursor-pointer"
        onClick={() => setIsOpen(!isOpen)}
      >
        <motion.div
          animate={{ opacity: [0.5, 0.8, 0.5], scale: [1, 1.1, 1] }}
          transition={{ duration: 2.5, repeat: Number.POSITIVE_INFINITY }}
          className="absolute inset-0 bg-[#2563EB]/40 blur-2xl rounded-full"
        />
        <div className="relative bg-gradient-to-br from-[#2563EB] to-[#1E40AF] rounded-2xl border-2 border-white shadow-lg flex items-center justify-center h-11 w-20">
          <motion.div
            animate={{ y: [0, -4, 0] }}
            transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
            className="absolute -top-2 w-2 h-2 bg-[#38BDF8] rounded-full shadow-md"
          />
          <div className="flex gap-2 items-center">
            <motion.div
              animate={{ scaleY: [1, 0.1, 1] }}
              transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY, delay: 0.2 }}
              className="w-2 h-2 bg-white rounded-full shadow-md"
            />
            <motion.div
              animate={{ scaleY: [1, 0.1, 1] }}
              transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY, delay: 1.5 }}
              className="w-2 h-2 bg-white rounded-full shadow-md"
            />
          </div>
        </div>
      </motion.div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ type: "spring", stiffness: 200, damping: 18 }}
            className="absolute bottom-20 right-0 w-80 bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden"
          >
            <div className="bg-[#2563EB] text-white text-sm font-medium px-4 py-2 flex items-center justify-between">
              <div>VibeBot — Shiftza Assistant</div>
              <button onClick={() => setIsOpen(false)}>
                <X size={16} />
              </button>
            </div>

            <div className="p-3 max-h-80 overflow-y-auto space-y-2 text-sm">
              {messages.map((msg, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.2 }}
                  className={`px-3 py-2 rounded-lg ${
                    msg.role === "user"
                      ? "bg-[#2563EB] text-white ml-auto max-w-[80%]"
                      : "bg-slate-100 text-slate-700 mr-auto max-w-[85%]"
                  }`}
                >
                  {msg.type === "social" ? (
                    <div className="flex flex-col gap-2">
                      <p>{msg.text}</p>
                      <div className="flex gap-4 mt-1">
                        <a
                          href="https://www.linkedin.com/company/shiftzaa/"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="hover:text-[#0A66C2] transition-colors"
                        >
                          <Linkedin size={20} />
                        </a>
                        <a
                          href="https://www.instagram.com/shiftza.in/"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="hover:text-pink-500 transition-colors"
                        >
                          <Instagram size={20} />
                        </a>
                      </div>
                    </div>
                  ) : (
                    <p className="whitespace-pre-line">{msg.text}</p>
                  )}
                </motion.div>
              ))}
            </div>

            <div className="flex items-center gap-2 border-t border-slate-100 p-2">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && sendMessage()}
                className="flex-1 px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none"
                placeholder="Ask me about Shiftza..."
              />
              <button onClick={sendMessage} className="p-2 rounded-full bg-[#2563EB] text-white hover:bg-[#1D4ED8]">
                <Send size={16} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
