"use client"

import { Twitter } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

export default function Footer() {
  return (
    <footer className="w-full bg-white border-t-0 border-transparent">
      <div className="max-w-[1200px] px-6 md:px-8 py-10 md:py-14 md:pt-5 md:pl-0 md:pr-0 md:pb-3 mx-auto bg-white">
        {/* Top: Columns */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 md:gap-10">
          {/* Features */}
          <div>
            <h3 className="text-xs tracking-[0.18em] font-semibold text-[#07204A]/70 mb-4">FEATURES</h3>
            <ul className="space-y-3 text-[#07204A]/80">
              <li><a href="#" className="hover:text-[#2563EB] transition-colors">Feedback Boards</a></li>
              <li><a href="#" className="hover:text-[#2563EB] transition-colors">Voting System</a></li>
              <li><a href="#" className="hover:text-[#2563EB] transition-colors">Roadmap Management</a></li>
              <li><a href="#" className="hover:text-[#2563EB] transition-colors">Analytics Dashboard</a></li>
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h3 className="text-xs tracking-[0.18em] font-semibold text-[#07204A]/70 mb-4">RESOURCES</h3>
            <ul className="space-y-3 text-[#07204A]/80">
              <li><a href="#" className="hover:text-[#2563EB] transition-colors">Customer Stories</a></li>
              <li><a href="#" className="hover:text-[#2563EB] transition-colors">Migration Guide</a></li>
              <li><a href="#" className="hover:text-[#2563EB] transition-colors">API Documentation</a></li>
              <li><a href="#" className="hover:text-[#2563EB] transition-colors">Help Center</a></li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h3 className="text-xs tracking-[0.18em] font-semibold text-[#07204A]/70 mb-4">COMPANY</h3>
            <ul className="space-y-3 text-[#07204A]/80">
              <li><a href="#" className="hover:text-[#2563EB] transition-colors">About Shiftza</a></li>
              <li><a href="#" className="hover:text-[#2563EB] transition-colors">Pricing</a></li>
              <li><a href="#" className="hover:text-[#2563EB] transition-colors">Contact Us</a></li>
              <li><a href="#" className="hover:text-[#2563EB] transition-colors">Canny vs Shiftza</a></li>
            </ul>
          </div>

          {/* Stay in touch */}
          <div>
            <h3 className="text-xs tracking-[0.18em] font-semibold text-[#07204A]/70 mb-4">STAY IN TOUCH</h3>

            {/* Email input */}
            <form
              className="flex items-center gap-3"
              onSubmit={(e) => e.preventDefault()}
            >
              <div className="flex-1">
                <Input
                  type="email"
                  placeholder="you@example.com"
                  aria-label="Email address"
                  className="h-11 rounded-xl bg-white/80 border-slate-300 text-[#07204A] placeholder:text-[#07204A]/40 backdrop-blur-sm focus:ring-[#2563EB]"
                  required
                />
              </div>
              <Button
                type="submit"
                className="h-11 rounded-xl bg-[#2563EB] text-white hover:bg-[#1D4ED8]"
                aria-label="Join mailing list"
              >
                Join
              </Button>
            </form>

            {/* Social Icons */}
            <div className="flex items-center gap-3 mt-5">
              {/* Instagram */}
              <a
                href="https://www.instagram.com/shiftza.in/?utm_source=ig_web_button_share_sheet"
                aria-label="Instagram"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full border border-slate-300 flex items-center justify-center hover:border-[#2563EB]/50 transition-colors"
              >
                <svg className="w-5 h-5" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                  <defs>
                    <linearGradient id="igGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#F58529" />
                      <stop offset="35%" stopColor="#DD2A7B" />
                      <stop offset="60%" stopColor="#8134AF" />
                      <stop offset="100%" stopColor="#515BD4" />
                    </linearGradient>
                  </defs>
                  <rect x="1.5" y="1.5" width="21" height="21" rx="5" fill="url(#igGradient)" />
                  <path
                    fill="#fff"
                    d="M12 7.8c2.32 0 4.2 1.88 4.2 4.2s-1.88 4.2-4.2 4.2-4.2-1.88-4.2-4.2 1.88-4.2 4.2-4.2zm0 1.8a2.4 2.4 0 100 4.8 2.4 2.4 0 000-4.8zM16.8 6.9a.9.9 0 110 1.8.9.9 0 010-1.8zM8.4 5.5h7.2A3.9 3.9 0 0119.5 9.4v5.2a3.9 3.9 0 01-3.9 3.9H8.4a3.9 3.9 0 01-3.9-3.9V9.4A3.9 3.9 0 018.4 5.5z"
                  />
                </svg>
              </a>

              {/* Twitter */}
              <a
                href="#"
                aria-label="Twitter"
                className="w-10 h-10 rounded-full border border-slate-300 flex items-center justify-center text-[#07204A]/80 hover:text-[#2563EB] hover:border-[#2563EB]/50 transition-colors"
              >
                <Twitter className="w-5 h-5" />
              </a>

              {/* LinkedIn */}
              <a
                href="https://www.linkedin.com/company/shiftzaa/"
                aria-label="LinkedIn"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full border border-slate-300 flex items-center justify-center hover:border-[#2563EB]/50 transition-colors"
              >
                <svg className="w-5 h-5" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                  <rect x="1" y="1" width="22" height="22" rx="4" fill="#0A66C2" />
                  <path
                    fill="#fff"
                    d="M6.94 9.18H4.3v10.04h2.64V9.18zM5.62 4.78c-.86 0-1.56.7-1.56 1.56 0 .86.7 1.56 1.56 1.56.86 0 1.56-.7 1.56-1.56 0-.86-.7-1.56-1.56-1.56zM19.7 19.22v-5.44c0-2.64-1.41-3.87-3.29-3.87-1.52 0-2.2.84-2.58 1.43v-1.25H11.3c.03.83 0 10.13 0 10.13h2.54v-5.66c0-.3.02-.6.11-.82.25-.6.81-1.22 1.76-1.22 1.24 0 1.74.92 1.74 2.27v5.43H19.7z"
                  />
                </svg>
              </a>
            </div>
          </div>
        </div>

        {/* Divider */}
        

        {/* Bottom Row */}
        <div className="mt-6 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-[#07204A]/70">
          <p
            className="font-mono flex items-center gap-1.5"
            style={{
              fontFamily:
                'GeistMono, ui-monospace, SFMono-Regular, "Roboto Mono", Menlo, Monaco, "Liberation Mono", "DejaVu Sans Mono", "Courier New", monospace',
            }}
          >
            © {new Date().getFullYear()} Shiftza. All rights reserved.
          </p>

          <nav className="flex items-center gap-6">
            <a href="#" className="hover:text-[#2563EB] transition-colors">Privacy</a>
            <span className="text-[#07204A]/30">•</span>
            <a href="#" className="hover:text-[#2563EB] transition-colors">Terms</a>
            <span className="text-[#07204A]/30">•</span>
            <a href="#top" className="hover:text-[#2563EB] transition-colors">Back to top</a>
          </nav>
        </div>
      </div>
    </footer>
  )
}
