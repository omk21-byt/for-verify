"use client"

import { Badge } from "@/components/ui/badge"
import { Card } from "@/components/ui/card"
import { CheckCircle, AlertCircle, Clock } from "lucide-react"

interface AISkillCardProps {
  skill: {
    id: string
    skill_name: string
    verified: boolean
    ai_score?: number
    ai_feedback?: string
    verified_by_ai?: boolean
    proof_link?: string
    proof_description?: string
  }
}

export function AISkillCard({ skill }: AISkillCardProps) {
  const getVerificationStatus = () => {
    if (skill.verified_by_ai === undefined) return "pending"
    if (skill.verified_by_ai === true) return "verified"
    return "needs-review"
  }

  const status = getVerificationStatus()
  const scorePercentage = skill.ai_score || 0

  return (
    <Card className="p-4 bg-white border hover:shadow-lg transition-shadow">
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <h3 className="font-semibold text-gray-900">{skill.skill_name}</h3>
          {skill.proof_link && (
            <a
              href={skill.proof_link}
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm text-blue-600 hover:underline mt-1 inline-block"
            >
              View Proof →
            </a>
          )}
        </div>

        <div className="flex items-center gap-2">
          {status === "verified" && (
            <Badge className="bg-[#E8FFB8] text-[#0B6B2E] flex items-center gap-1">
              <CheckCircle className="w-3 h-3" />
              Verified
            </Badge>
          )}
          {status === "needs-review" && (
            <Badge className="bg-yellow-100 text-yellow-800 flex items-center gap-1">
              <AlertCircle className="w-3 h-3" />
              Review
            </Badge>
          )}
          {status === "pending" && (
            <Badge className="bg-gray-100 text-gray-700 flex items-center gap-1">
              <Clock className="w-3 h-3" />
              Pending
            </Badge>
          )}
        </div>
      </div>

      {skill.ai_score !== undefined && (
        <div className="mb-3">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-medium text-gray-600">AI Confidence</span>
            <span className="text-xs font-semibold text-gray-900">{skill.ai_score}%</span>
          </div>
          <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all ${
                skill.ai_score >= 70 ? "bg-[#0B6B2E]" : skill.ai_score >= 50 ? "bg-yellow-500" : "bg-red-500"
              }`}
              style={{ width: `${skill.ai_score}%` }}
            />
          </div>
        </div>
      )}

      {skill.ai_feedback && (
        <div className="p-3 bg-gray-50 rounded-md">
          <p className="text-xs text-gray-700">{skill.ai_feedback}</p>
        </div>
      )}
    </Card>
  )
}
