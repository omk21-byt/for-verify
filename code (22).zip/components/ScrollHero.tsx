"use client";

import React, { useRef, useEffect, useState } from "react";

interface ScrollHeroProps {
  children: React.ReactNode; // your page/content inside
  startScale?: number;
  enableAnimations?: boolean;
  stiffness?: number;
  damping?: number;
  scrollBoost?: number;
}

export default function ScrollHero({
  children,
  startScale = 0.25,
  enableAnimations = true,
  stiffness = 0.15,
  damping = 0.1,
  scrollBoost = 1.3, // controls scroll speed
}: ScrollHeroProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [targetScale, setTargetScale] = useState(startScale);
  const [smoothScale, setSmoothScale] = useState(startScale);
  const [opacity, setOpacity] = useState(0);

  // update target scale + opacity on scroll
  useEffect(() => {
    if (!enableAnimations) return;

    const handleScroll = () => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const windowHeight = window.innerHeight;

      let progress = Math.min(Math.max(1 - rect.top / windowHeight, 0), 1);
      progress = Math.min(progress * scrollBoost, 1);

      const newScale = startScale + progress * (1 - startScale);
      setTargetScale(newScale);
      setOpacity(Math.min(progress * 1.3, 1));
    };

    window.addEventListener("scroll", handleScroll);
    handleScroll();
    return () => window.removeEventListener("scroll", handleScroll);
  }, [startScale, enableAnimations, scrollBoost]);

  // smooth animation loop
  useEffect(() => {
    if (!enableAnimations) {
      setSmoothScale(targetScale);
      return;
    }

    let animationFrame: number;

    const smoothUpdate = () => {
      setSmoothScale((prev) => {
        const diff = targetScale - prev;
        const next = prev + diff * stiffness;
        return Math.abs(diff) < damping ? targetScale : next;
      });
      animationFrame = requestAnimationFrame(smoothUpdate);
    };

    smoothUpdate();
    return () => cancelAnimationFrame(animationFrame);
  }, [targetScale, stiffness, damping, enableAnimations]);

  return (
    <div
      ref={containerRef}
      className="block rounded-2xl shadow-2xl mx-auto my-11 mt-3.5 overflow-hidden bg-black"
      style={{
        width: "80vw",
        height: "60vh",
        transform: `scale(${smoothScale})`,
        transformOrigin: "center center",
        opacity,
        transition: "opacity 0.6s ease-out, transform 0.1s ease-out",
        willChange: "transform, opacity",
      }}
    >
      {children}
    </div>
  );
}
