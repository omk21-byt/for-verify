"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle2, Loader2, Brain, Clock, CheckCheck, AlertCircle } from "lucide-react"

interface AIVerificationProcessProps {
  status: string
  skillScore?: number
  adminFeedback?: string
  starRating?: number
}

export function AIVerificationProcess({
  status,
  skillScore = 0,
  adminFeedback,
  starRating = 0,
}: AIVerificationProcessProps) {
  const [currentStep, setCurrentStep] = useState(0)
  const [isProcessing, setIsProcessing] = useState(status === "pending_review" || status === "pending")

  useEffect(() => {
    if (!isProcessing) return

    const steps = [
      { label: "Analyzing Skills", duration: 2000 },
      { label: "Cross-referencing Experience", duration: 2000 },
      { label: "Verifying Credentials", duration: 2000 },
      { label: "Assigning to Admin", duration: 1000 },
    ]

    let currentStepIndex = 0
    const interval = setInterval(() => {
      if (currentStepIndex < steps.length) {
        setCurrentStep(currentStepIndex)
        currentStepIndex++
      } else {
        clearInterval(interval)
      }
    }, steps[currentStepIndex]?.duration || 1000)

    return () => clearInterval(interval)
  }, [isProcessing])

  const isPending = status === "pending_review" || status === "pending"
  const isVerified = status === "verified" || status === "approved"
  const isRejected = status === "rejected"

  return (
    <Card className="rounded-2xl border-0 shadow-lg overflow-hidden">
      <CardHeader className="bg-gradient-to-r from-white-50 to-white-50 border-b">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Brain className="w-5 h-5 text-blue-600" />
              AI-Powered Verification Process
            </CardTitle>
            <CardDescription>
              {isPending && "Your profile is being analyzed by our AI verification system"}
              {isVerified && "Your profile has been verified and approved"}
              {isRejected && "Your profile requires additional information"}
            </CardDescription>
          </div>
          {isPending && <Loader2 className="w-6 h-6 animate-spin text-blue-600" />}
        </div>
      </CardHeader>

      <CardContent className="pt-6 space-y-6">
        {/* AI Processing Steps */}
        {isPending && (
          <div className="space-y-4">
            <p className="text-sm text-slate-600 font-medium">Verification Steps:</p>
            {[
              { icon: Brain, label: "Analyzing Skills", desc: "Examining your technical expertise" },
              { icon: Clock, label: "Cross-referencing Experience", desc: "Verifying work history" },
              { icon: CheckCheck, label: "Verifying Credentials", desc: "Validating your background" },
              { icon: AlertCircle, label: "Assigning to Admin", desc: "Sending to human reviewer" },
            ].map((step, idx) => {
              const Icon = step.icon
              const isActive = idx === currentStep
              const isComplete = idx < currentStep

              return (
                <div
                  key={step.label}
                  className={`flex gap-4 p-3 rounded-lg border transition-all ${
                    isActive
                      ? "bg-blue-50 border-blue-300"
                      : isComplete
                        ? "bg-green-50 border-green-200"
                        : "bg-slate-50 border-slate-200"
                  }`}
                >
                  <div
                    className={`flex-shrink-0 p-2 rounded-lg ${
                      isActive
                        ? "bg-blue-200 text-blue-700"
                        : isComplete
                          ? "bg-green-200 text-green-700"
                          : "bg-slate-200 text-slate-500"
                    }`}
                  >
                    {isActive ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : isComplete ? (
                      <CheckCircle2 className="w-4 h-4" />
                    ) : (
                      <Icon className="w-4 h-4" />
                    )}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-sm text-slate-900">{step.label}</p>
                    <p className="text-xs text-slate-600">{step.desc}</p>
                  </div>
                </div>
              )
            })}
            <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-xs text-blue-700">
                ℹ️ After AI analysis, your profile will be reviewed by our admin team (typically 30-40 seconds)
              </p>
            </div>
          </div>
        )}

        {/* Verification Complete */}
        {isVerified && (
          <div className="space-y-2">
            {/* Skill Score */}
            {skillScore > 0 && (
              <div className="p-4 rounded-lg bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200">
                <p className="text-sm font-semibold text-slate-700 mb-2">AI Skill Score</p>
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <div className="h-3 rounded-full bg-blue-100 overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-blue-500 to-indigo-600"
                        style={{ width: `${skillScore}%` }}
                      />
                    </div>
                  </div>
                  <span className="font-bold text-lg text-blue-600">{skillScore}/100</span>
                </div>
              </div>
            )}

            {/* Admin Rating */}
            {starRating > 0 && (
              <div className="p-4 rounded-lg bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 py-2.5">
                <p className="text-sm font-semibold text-slate-700 mb-2">Admin Rating</p>
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <span key={star} className="text-2xl">
                      {star <= starRating ? "⭐" : "☆"}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Admin Feedback */}
            {adminFeedback && (
              <div className="p-4 rounded-lg bg-green-50 border border-green-200 py-2.5">
                <p className="text-sm font-semibold text-slate-700 mb-2">Admin Feedback</p>
                <p className="text-sm text-slate-700">{adminFeedback}</p>
              </div>
            )}

            <Badge className="bg-blue-600 text-white hover:bg-green-200">✓ Verified & Approved</Badge>
          </div>
        )}

        {/* Rejected */}
        {isRejected && (
          <div className="p-4 rounded-lg bg-red-50 border border-red-200">
            <p className="font-semibold text-red-900 mb-2 flex items-center gap-2">
              <AlertCircle className="w-4 h-4" />
              Profile Not Approved
            </p>
            {adminFeedback && <p className="text-sm text-red-700">{adminFeedback}</p>}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
