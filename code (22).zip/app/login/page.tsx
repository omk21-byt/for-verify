"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useToast } from "@/hooks/use-toast"
import { Eye, EyeOff, ArrowLeft } from "lucide-react"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()
  const router = useRouter()

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      })

      if (!response.ok) {
        const error = await response.json()
        toast({
          title: "Login failed",
          description: error.error || "Invalid email or password",
          variant: "destructive",
        })
        setIsLoading(false)
        return
      }

      const { user } = await response.json()

      toast({
        title: "Logged in successfully",
        description: "Welcome back!",
      })

      setTimeout(() => {
        router.push("/dashboard")
      }, 500)
    } catch (error) {
      console.error("[v0] login error:", error)
      toast({
        title: "Error",
        description: "Login failed. Please try again.",
        variant: "destructive",
      })
      setIsLoading(false)
    }
  }

  return (
    <main className="min-h-screen py-10 px-6 flex items-center justify-center bg-gradient-to-b from-gray-50 to-white">
      <div className="absolute top-6 left-6">
        <Link
          href="/"
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Home
        </Link>
      </div>

      <section className="w-full max-w-md bg-white border border-gray-200 rounded-2xl shadow-sm p-8">
        <div className="text-center mb-6">
          <h1 className="text-3xl font-semibold mb-2">Welcome Back</h1>
          <p className="text-sm text-muted-foreground">
            Log in to continue your journey with <span className="font-medium text-foreground">{"Shiftza"}</span>
          </p>
        </div>

        <form onSubmit={onSubmit} className="grid gap-4">
          <Input
            type="email"
            placeholder="you@example.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            disabled={isLoading}
            className="rounded-lg"
          />

          <div className="relative">
            <Input
              type={showPassword ? "text" : "password"}
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              minLength={6}
              required
              disabled={isLoading}
              className="rounded-lg pr-10"
            />
            <button
              type="button"
              onClick={() => setShowPassword((prev) => !prev)}
              className="absolute inset-y-0 right-3 flex items-center text-gray-500 hover:text-gray-700"
              tabIndex={-1}
            >
              {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
            </button>
          </div>

          <Button
            type="submit"
            disabled={isLoading}
            className="rounded-full mt-2 w-full font-medium transition-all duration-300 hover:shadow-md"
          >
            {isLoading ? "Logging in..." : "Continue"}
          </Button>
        </form>

        <div className="mt-6 text-center text-sm text-muted-foreground">
          <p>
            Don't have an account?{" "}
            <Link href="/signup" className="text-foreground underline font-medium hover:text-primary">
              Sign up
            </Link>
          </p>
        </div>
      </section>
    </main>
  )
}
