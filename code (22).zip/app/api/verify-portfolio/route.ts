import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"
import { generateText } from "ai"

// Helper to extract GitHub username/repo from URL
function extractGitHubInfo(url: string): { username: string; repo?: string } | null {
  try {
    const urlObj = new URL(url)
    if (!urlObj.hostname.includes("github.com")) return null

    const parts = urlObj.pathname.split("/").filter(Boolean)
    return {
      username: parts[0],
      repo: parts[1],
    }
  } catch {
    return null
  }
}

// Fetch GitHub user data
async function fetchGitHubData(username: string) {
  try {
    const userRes = await fetch(`https://api.github.com/users/${username}`, {
      headers: {
        Accept: "application/vnd.github.v3+json",
      },
    })

    if (!userRes.ok) return null
    const userData = await userRes.json()

    // Fetch user's repositories
    const reposRes = await fetch(`https://api.github.com/users/${username}/repos?sort=stars&per_page=30`, {
      headers: {
        Accept: "application/vnd.github.v3+json",
      },
    })

    const repos = reposRes.ok ? await reposRes.json() : []

    return {
      username: userData.login,
      name: userData.name || userData.login,
      publicRepos: userData.public_repos,
      followers: userData.followers,
      bio: userData.bio,
      repositories: repos.slice(0, 10).map((repo: any) => ({
        name: repo.name,
        stars: repo.stargazers_count,
        language: repo.language,
        description: repo.description,
      })),
      languages: [...new Set(repos.map((r: any) => r.language).filter(Boolean))],
    }
  } catch (error) {
    console.error("[v0] GitHub fetch error:", error)
    return null
  }
}

// Generate AI analysis and score
async function analyzePortfolio(githubData: any) {
  const prompt = `Analyze this GitHub profile data and provide:
1. A skill score from 0-100
2. Top 3-5 verified skills/technologies
3. Brief assessment

GitHub Profile Data:
- Username: ${githubData.username}
- Public Repos: ${githubData.publicRepos}
- Followers: ${githubData.followers}
- Main Languages: ${githubData.languages.join(", ")}
- Top Repositories (${githubData.repositories.length}):
${githubData.repositories.map((r: any) => `  - ${r.name}: ${r.stars} stars, ${r.language || "Unknown"} - ${r.description || "No description"}`).join("\n")}

Respond in JSON format:
{
  "score": <0-100>,
  "skills": ["skill1", "skill2", "skill3"],
  "assessment": "brief assessment"
}`

  try {
    const { text } = await generateText({
      model: "openai/gpt-4-mini",
      prompt,
    })

    return JSON.parse(text)
  } catch (error) {
    console.error("[v0] AI analysis error:", error)
    return {
      score: 50,
      skills: githubData.languages.slice(0, 3),
      assessment: "Unable to fully analyze profile",
    }
  }
}

export async function POST(request: NextRequest) {
  try {
    const { portfolioUrl, userId } = await request.json()

    if (!portfolioUrl || !userId) {
      return NextResponse.json({ error: "Portfolio URL and user ID required" }, { status: 400 })
    }

    // Extract GitHub info
    const githubInfo = extractGitHubInfo(portfolioUrl)
    if (!githubInfo) {
      return NextResponse.json({ error: "Invalid GitHub URL" }, { status: 400 })
    }

    // Fetch GitHub data
    const githubData = await fetchGitHubData(githubInfo.username)
    if (!githubData) {
      return NextResponse.json({ error: "GitHub profile not found" }, { status: 404 })
    }

    // Analyze with AI
    const analysis = await analyzePortfolio(githubData)

    // Update database
    const cookieStore = await cookies()
    const supabase = createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
      cookies: {
        getAll: () => cookieStore.getAll(),
        setAll: (cookiesToSet) => {
          cookiesToSet.forEach(({ name, value, options }) => {
            cookieStore.set(name, value, options)
          })
        },
      },
    })

    const { error } = await supabase
      .from("users")
      .update({
        skill_score: analysis.score,
        verified_skills: analysis.skills,
        verification_status: "pending_review",
        admin_review_status: "pending_review",
        star_rating: 0,
        verification_feedback: analysis.assessment,
      })
      .eq("id", userId)

    if (error) {
      console.error("[v0] Database update error:", error)
      return NextResponse.json({ error: "Failed to update verification status" }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      score: analysis.score,
      skills: analysis.skills,
      assessment: analysis.assessment,
      status: "pending_review",
    })
  } catch (error) {
    console.error("[v0] Verification API error:", error)
    return NextResponse.json({ error: "Verification failed" }, { status: 500 })
  }
}
