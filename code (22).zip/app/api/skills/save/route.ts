import { getAdminClient } from "@/lib/supabase/admin"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId, skills, learningSource, hasWorkExperience, previousExperience, canProveSkill, selectedJobs } = body

    if (!userId || !Array.isArray(skills)) {
      return NextResponse.json({ error: "Missing userId or skills" }, { status: 400 })
    }

    const supabase = getAdminClient()

    const { error: updateError } = await supabase
      .from("users")
      .update({
        experience: previousExperience || "",
        interests: selectedJobs?.join(", ") || "",
        expertise: learningSource || "",
        verified_skills: skills.map((s: any) => s.name || s),
        verification_status: "pending_review",
        admin_review_status: "pending_review",
      })
      .eq("id", userId)

    if (updateError) {
      console.error("[v0] profile update error:", updateError.message)
      return NextResponse.json({ error: "Failed to update profile" }, { status: 500 })
    }

    // Delete old skills
    await supabase.from("user_skills").delete().eq("user_id", userId)

    if (skills.length > 0) {
      const skillsData = skills.map((skill: any) => ({
        user_id: userId,
        skill_name: skill.name || skill,
        verified: false,
        proof_link: skill.proofLink || "",
        proof_description: skill.proofDescription || "",
      }))

      const { error } = await supabase.from("user_skills").insert(skillsData)

      if (error) {
        console.error("[v0] skills insert error:", error.message)
        return NextResponse.json({ error: "Failed to save skills" }, { status: 500 })
      }
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("[v0] skills error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
