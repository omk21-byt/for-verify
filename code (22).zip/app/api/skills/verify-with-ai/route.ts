import { type NextRequest, NextResponse } from "next/server"
import { generateText } from "ai"

// IMPORTANT: Ensure your Vercel AI Gateway is configured properly

export async function POST(request: NextRequest) {
  try {
    const { skill_name, proof_link, proof_description, user_id } = await request.json()

    if (!skill_name || !user_id) {
      return NextResponse.json({ error: "Missing required fields: skill_name, user_id" }, { status: 400 })
    }

    // This is free and uses the Gateway by default (no API key needed beyond environment)
    const { text } = await generateText({
      model: "openai/gpt-4o-mini", // Gateway defaults to this, no separate key needed
      prompt: `You are an expert skill verification AI. Analyze this skill submission and provide verification.

Skill: ${skill_name}
Proof Link: ${proof_link || "Not provided"}
Proof Description: ${proof_description || "Not provided"}

Respond ONLY with valid JSON (no markdown, no extra text):
{
  "score": <0-100 number>,
  "feedback": "<string explaining your assessment>",
  "verified": <true if score >= 65, false otherwise>
}`,
      maxOutputTokens: 300,
      temperature: 0.7,
    })

    // Parse the AI response
    let aiResult
    try {
      aiResult = JSON.parse(text)
    } catch (e) {
      console.error("[v0] Failed to parse AI response:", text)
      // Fallback response if parsing fails
      aiResult = {
        score: 50,
        feedback: "Skill verified by AI (parsing mode)",
        verified: false,
      }
    }

    return NextResponse.json({
      skill_name,
      ai_score: Math.min(100, Math.max(0, aiResult.score || 0)),
      ai_feedback: aiResult.feedback || "Skill verified by AI",
      verified: aiResult.verified || aiResult.score >= 65,
    })
  } catch (error) {
    console.error("[v0] Error in skill verification:", error)
    return NextResponse.json({ error: "Internal server error during skill verification" }, { status: 500 })
  }
}
