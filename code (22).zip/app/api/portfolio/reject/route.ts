import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"

export async function POST(request: NextRequest) {
  try {
    const { userId, rejectionReason } = await request.json()

    if (!userId || !rejectionReason) {
      return NextResponse.json({ error: "User ID and rejection reason required" }, { status: 400 })
    }

    const cookieStore = await cookies()
    const supabase = createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
      cookies: {
        getAll: () => cookieStore.getAll(),
        setAll: (cookiesToSet) => {
          cookiesToSet.forEach(({ name, value, options }) => {
            cookieStore.set(name, value, options)
          })
        },
      },
    })

    // Get current admin user
    const sessionRes = await fetch(new URL("/api/auth/session", request.url), {
      headers: { cookie: request.headers.get("cookie") || "" },
    })
    const sessionData = await sessionRes.json()

    if (!sessionData.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { data: adminUser } = await supabase.from("users").select("is_admin").eq("id", sessionData.user.id).single()

    if (!adminUser?.is_admin) {
      return NextResponse.json({ error: "Only admins can reject portfolios" }, { status: 403 })
    }

    // Update user with rejection
    const { error } = await supabase
      .from("users")
      .update({
        admin_review_status: "rejected",
        verification_status: "rejected",
        reviewed_by_admin: sessionData.user.id,
        reviewed_at: new Date().toISOString(),
        admin_feedback: rejectionReason,
      })
      .eq("id", userId)

    if (error) {
      console.error("[v0] Database update error:", error)
      return NextResponse.json({ error: "Failed to reject portfolio" }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      message: "Portfolio rejected",
    })
  } catch (error) {
    console.error("[v0] Rejection API error:", error)
    return NextResponse.json({ error: "Rejection failed" }, { status: 500 })
  }
}
