import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"

export async function POST(request: NextRequest) {
  try {
    const { userId, starRating, adminFeedback, selectedJob, profileType, profileTags } = await request.json()

    if (!userId || !starRating || starRating < 1 || starRating > 5) {
      return NextResponse.json({ error: "User ID and star rating (1-5) required" }, { status: 400 })
    }

    if (!selectedJob || !profileType) {
      return NextResponse.json({ error: "Job title and profile type are required" }, { status: 400 })
    }

    const cookieStore = await cookies()
    const supabase = createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
      cookies: {
        getAll: () => cookieStore.getAll(),
        setAll: (cookiesToSet) => {
          cookiesToSet.forEach(({ name, value, options }) => {
            cookieStore.set(name, value, options)
          })
        },
      },
    })

    // Get current admin user
    const sessionRes = await fetch(new URL("/api/auth/session", request.url), {
      headers: { cookie: request.headers.get("cookie") || "" },
    })
    const sessionData = await sessionRes.json()

    if (!sessionData.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { data: adminUser } = await supabase.from("users").select("is_admin").eq("id", sessionData.user.id).single()

    if (!adminUser?.is_admin) {
      return NextResponse.json({ error: "Only admins can approve portfolios" }, { status: 403 })
    }

    const { data: skills, error: skillsError } = await supabase
      .from("user_skills")
      .select("skill_name")
      .eq("user_id", userId)

    if (!skillsError && skills && skills.length > 0) {
      const skillNames = skills.map((s: any) => s.skill_name)

      // Update each skill to verified: true
      for (const skill of skills) {
        await supabase
          .from("user_skills")
          .update({ verified: true })
          .eq("user_id", userId)
          .eq("skill_name", skill.skill_name)
      }

      // Populate verified_skills array in users table
      await supabase.from("users").update({ verified_skills: skillNames }).eq("id", userId)
    }

    const { error } = await supabase
      .from("users")
      .update({
        admin_review_status: "approved",
        verification_status: "verified",
        star_rating: starRating,
        reviewed_by_admin: sessionData.user.id,
        reviewed_at: new Date().toISOString(),
        admin_feedback: adminFeedback || null,
        selected_job: selectedJob,
        profile_type: profileType,
        profile_tags: profileTags || [],
      })
      .eq("id", userId)

    if (error) {
      console.error("[v0] Database update error:", error)
      return NextResponse.json({ error: "Failed to approve portfolio" }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      message: "Portfolio approved with job role and tags",
      starRating,
      selectedJob,
      profileType,
    })
  } catch (error) {
    console.error("[v0] Approval API error:", error)
    return NextResponse.json({ error: "Approval failed" }, { status: 500 })
  }
}
