import { NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"

// ✅ Define the structure of the request body
interface PortfolioSubmitBody {
  userId: string
}

export async function POST(request: NextRequest) {
  try {
    const body: PortfolioSubmitBody = await request.json()

    if (!body?.userId) {
      return NextResponse.json(
        { error: "User ID is required" },
        { status: 400 }
      )
    }

    // ✅ cookies() is synchronous — no await
    const cookieStore = cookies()

    // ✅ Create secure server-side Supabase client
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.SUPABASE_SERVICE_ROLE_KEY!,
      {
        cookies: {
          getAll: () => cookieStore.getAll(),
          setAll: (cookiesToSet) => {
            cookiesToSet.forEach(({ name, value, options }) => {
              cookieStore.set(name, value, options)
            })
          },
        },
      }
    )

    // ✅ Perform the update query
    const { data: updatedUser, error } = await supabase
      .from("users")
      .update({
        admin_review_status: "pending",
        verification_status: "pending",
      })
      .eq("id", body.userId)
      .select()
      .single()

    if (error) {
      console.error("[portfolio.submit] Supabase update error:", error)
      return NextResponse.json(
        { error: "Failed to submit portfolio" },
        { status: 500 }
      )
    }

    return NextResponse.json({
      success: true,
      message: "Portfolio submitted. Awaiting admin verification.",
      user: updatedUser,
    })
  } catch (err) {
    console.error("[portfolio.submit] Unexpected error:", err)
    return NextResponse.json(
      { error: "Portfolio submission failed" },
      { status: 500 }
    )
  }
}
