import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(req: NextRequest) {
  try {
    const cookieStore = await cookies()
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          getAll() {
            return cookieStore.getAll()
          },
          setAll(cookiesToSet) {
            cookiesToSet.forEach(({ name, value, options }) => cookieStore.set(name, value, options))
          },
        },
      },
    )

    const {
      userId,
      name,
      email,
      expertise,
      interests,
      experience,
      portfolio_url,
      verified_skills,
      selected_job,
      profile_tags,
      skills,
      learningSource,
      hasWorkExperience,
      previousExperience,
      canProveSkill,
      proofLink,
      proofDescription,
    } = await req.json()

    if (!userId) {
      return NextResponse.json({ error: "userId required" }, { status: 400 })
    }

    const { data: updatedProfile, error } = await supabase
      .from("users")
      .update({
        name,
        expertise,
        interests,
        experience,
        portfolio_url,
        verified_skills: [], // Reset to empty until admin verifies
        selected_job,
        profile_tags,
        admin_review_status: "pending_review",
        updated_at: new Date().toISOString(),
        learning_source: learningSource || null,
        work_experience: previousExperience || null,
        has_work_experience: hasWorkExperience || false,
        can_prove_skill: canProveSkill || false,
      })
      .eq("id", userId)
      .select()
      .single()

    if (error) throw error

    if (skills && Array.isArray(skills)) {
      for (const skill of skills) {
        await supabase.from("user_skills").upsert(
          {
            user_id: userId,
            skill_name: skill.skill_name,
            verified: false, // Always unverified until admin approves
            proof_link: skill.proof_link || null,
            proof_description: skill.proof_description || null,
          },
          { onConflict: "user_id,skill_name" },
        )
      }
    }

    return NextResponse.json(updatedProfile)
  } catch (error) {
    console.error("[v0] Error updating profile:", error)
    return NextResponse.json({ error: "Failed to update profile" }, { status: 500 })
  }
}
