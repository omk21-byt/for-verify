import { getAdminClient } from "@/lib/supabase/admin"
import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    const userId = request.nextUrl.searchParams.get("userId")

    if (!userId) {
      return NextResponse.json({ error: "User ID required" }, { status: 400 })
    }

    const supabase = getAdminClient()

    const { data: profile, error: profileError } = await supabase.from("users").select("*").eq("id", userId).single()

    if (profileError || !profile) {
      return NextResponse.json({ error: "Profile not found" }, { status: 404 })
    }

    const { data: skills, error: skillsError } = await supabase.from("user_skills").select("*").eq("user_id", userId)

    if (skillsError) {
      console.error("[v0] skills fetch error:", skillsError)
      return NextResponse.json({ error: "Failed to fetch skills" }, { status: 500 })
    }

    return NextResponse.json({
      profile: {
        id: profile.id,
        name: profile.name,
        email: profile.email,
        expertise: profile.expertise,
        interests: profile.interests,
        portfolio_url: profile.portfolio_url,
        experience: profile.experience,
        avatar_url: profile.avatar_url,
        created_at: profile.created_at,
      },
      skills: skills || [],
    })
  } catch (error) {
    console.error("[v0] dashboard error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
