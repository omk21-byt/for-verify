import { getServerClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId, name, expertise, interests, portfolio, experience, selected_job } = body

    if (!userId) {
      return NextResponse.json({ error: "Missing userId" }, { status: 400 })
    }

    const supabase = await getServerClient()

    const updateData: any = {
      updated_at: new Date().toISOString(),
    }

    if (name) updateData.name = name
    if (expertise) updateData.expertise = expertise
    if (interests) updateData.interests = interests
    if (experience) updateData.experience = experience
    if (selected_job) updateData.selected_job = selected_job

    if (portfolio) {
      updateData.portfolio_url = portfolio
      updateData.verification_status = "pending"
      updateData.admin_review_status = "pending_review"
    }

    const { data: user, error } = await supabase.from("users").update(updateData).eq("id", userId).select().single()

    if (error) {
      console.error("[v0] update error:", error)
      return NextResponse.json({ error: "Failed to update profile" }, { status: 500 })
    }

    if (portfolio) {
      setTimeout(async () => {
        try {
          const baseUrl = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"
          await fetch(`${baseUrl}/api/auto-verify-portfolio`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ userId }),
          })
        } catch (err) {
          console.error("[v0] Auto-verify trigger error:", err)
        }
      }, 2000)
    }

    return NextResponse.json({ user })
  } catch (error) {
    console.error("[v0] update error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
