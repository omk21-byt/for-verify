import { getAdminClient } from "@/lib/supabase/admin"
import { type NextRequest, NextResponse } from "next/server"

const MAX_FILE_SIZE = 100 * 1024 // 100KB in bytes

export async function POST(request: NextRequest) {
  try {
    console.log("[v0] Avatar upload started")
    
    const formData = await request.formData()
    const file = formData.get("file") as File
    const userId = formData.get("userId") as string

    console.log("[v0] FormData received - userId:", userId, "file:", file?.name, "size:", file?.size)

    if (!file || !userId) {
      console.log("[v0] Missing file or userId")
      return NextResponse.json({ error: "File and userId required" }, { status: 400 })
    }

    if (file.size > MAX_FILE_SIZE) {
      console.log("[v0] File size too large:", file.size)
      return NextResponse.json(
        { error: `File size must be under 100KB. Your file is ${Math.round(file.size / 1024)}KB.` },
        { status: 400 }
      )
    }

    const validMimeTypes = ["image/jpeg", "image/png", "image/webp", "image/gif"]
    if (!validMimeTypes.includes(file.type)) {
      console.log("[v0] Invalid file type:", file.type)
      return NextResponse.json(
        { error: "Invalid file type. Only JPEG, PNG, WebP, and GIF are allowed." },
        { status: 400 }
      )
    }

    const supabase = getAdminClient()
    console.log("[v0] Supabase admin client created")

    const { data: userData, error: fetchError } = await supabase
      .from("users")
      .select("avatar_url")
      .eq("id", userId)
      .single()

    console.log("[v0] User data fetched - error:", fetchError, "avatar_url:", userData?.avatar_url)

    if (!fetchError && userData?.avatar_url) {
      try {
        // Extract file path from public URL
        const urlParts = userData.avatar_url.split("/avatars/")
        if (urlParts.length > 1) {
          const oldFilePath = `${userId}/${urlParts[1]}`
          console.log("[v0] Deleting old avatar:", oldFilePath)
          // Instead, we'll skip old deletion and just upload the new one
          console.log("[v0] Skipping old avatar deletion to proceed with new upload")
        }
      } catch (deleteError) {
        console.log("[v0] Error handling old avatar (non-fatal):", deleteError)
      }
    }

    const arrayBuffer = await file.arrayBuffer()
    const uint8Array = new Uint8Array(arrayBuffer)
    
    const fileName = `${userId}-${Date.now()}.jpg`
    const filePath = `${userId}/${fileName}`

    console.log("[v0] Uploading file to storage:", filePath)

    // Upload to storage
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from("avatars")
      .upload(filePath, uint8Array, {
        contentType: file.type,
        upsert: true,
      })

    if (uploadError) {
      console.error("[v0] Upload error:", uploadError)
      const errorMsg = typeof uploadError === "object" && uploadError !== null && "message" in uploadError 
        ? String(uploadError.message)
        : "Upload failed"
      return NextResponse.json({ error: errorMsg }, { status: 500 })
    }

    console.log("[v0] File uploaded successfully:", uploadData)

    // Get public URL
    const { data } = supabase.storage.from("avatars").getPublicUrl(filePath)
    const publicUrl = data.publicUrl

    console.log("[v0] Public URL generated:", publicUrl)

    // Update user profile with avatar URL
    const { error: updateError } = await supabase
      .from("users")
      .update({ avatar_url: publicUrl })
      .eq("id", userId)

    if (updateError) {
      console.error("[v0] Update error:", updateError)
      const errorMsg = typeof updateError === "object" && updateError !== null && "message" in updateError
        ? String(updateError.message)
        : "Failed to update profile"
      return NextResponse.json({ error: errorMsg }, { status: 500 })
    }

    console.log("[v0] Avatar upload complete and profile updated")
    return NextResponse.json({ avatar_url: publicUrl }, { status: 200 })
  } catch (error) {
    console.error("[v0] Avatar upload catch error:", error)
    let errorMessage = "Internal server error"
    if (error instanceof Error) {
      errorMessage = error.message
    } else if (typeof error === "string") {
      errorMessage = error
    }
    return NextResponse.json({ error: errorMessage }, { status: 500 })
  }
}
