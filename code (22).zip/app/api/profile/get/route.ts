import { getServerClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    const userId = request.nextUrl.searchParams.get("userId")

    if (!userId) {
      return NextResponse.json({ error: "Missing userId" }, { status: 400 })
    }

    const supabase = await getServerClient()

    // Get user profile
    const { data: user, error: userError } = await supabase
      .from("users")
      .select(
        "id, name, email, expertise, interests, portfolio_url, experience, avatar_url, verification_status, verification_feedback, skill_score, verified_skills, last_verified_at, star_rating, admin_feedback, admin_review_status",
      )
      .eq("id", userId)
      .single()

    if (userError || !user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    // Get user skills
    const { data: skills, error: skillsError } = await supabase
      .from("user_skills")
      .select("id, skill_name, verified, proof_link")
      .eq("user_id", userId)

    if (skillsError) {
      console.error("[v0] skills error:", skillsError)
    }

    return NextResponse.json({
      user,
      skills: skills || [],
    })
  } catch (error) {
    console.error("[v0] profile error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
