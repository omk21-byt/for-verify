import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"
import { NextResponse } from "next/server"

export async function GET() {
  try {
    const cookieStore = await cookies()
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          getAll() {
            return cookieStore.getAll()
          },
          setAll(cookiesToSet) {
            cookiesToSet.forEach(({ name, value, options }) => cookieStore.set(name, value, options))
          },
        },
      },
    )

    // Get current user
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

    // Fetch conversations for current user
    const { data: conversations, error } = await supabase
      .from("conversations")
      .select(`
        id,
        user_1_id,
        user_2_id,
        created_at,
        updated_at,
        messages(content, created_at, sender_id)
      `)
      .or(`user_1_id.eq.${user.id},user_2_id.eq.${user.id}`)
      .order("updated_at", { ascending: false })

    if (error) throw error

    // Fetch user details for each conversation
    const conversationsWithUsers = await Promise.all(
      conversations.map(async (conv: any) => {
        const otherId = conv.user_1_id === user.id ? conv.user_2_id : conv.user_1_id
        const { data: otherUser } = await supabase
          .from("users")
          .select("id,name,avatar_url,email")
          .eq("id", otherId)
          .single()

        return {
          ...conv,
          otherUser,
          lastMessage: conv.messages?.[0],
        }
      }),
    )

    return NextResponse.json({ conversations: conversationsWithUsers })
  } catch (error) {
    console.error("[v0] Error fetching conversations:", error)
    return NextResponse.json({ error: "Failed to fetch conversations" }, { status: 500 })
  }
}
