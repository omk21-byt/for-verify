import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"
import { NextResponse, type NextRequest } from "next/server"

export async function POST(req: NextRequest) {
  try {
    const cookieStore = await cookies()
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          getAll() {
            return cookieStore.getAll()
          },
          setAll(cookiesToSet) {
            cookiesToSet.forEach(({ name, value, options }) => cookieStore.set(name, value, options))
          },
        },
      },
    )

    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

    const { recipientId } = await req.json()

    if (!recipientId) {
      return NextResponse.json({ error: "Missing recipientId" }, { status: 400 })
    }

    // Create or get conversation
    const [id1, id2] = user.id < recipientId ? [user.id, recipientId] : [recipientId, user.id]

    const { data: conversation, error: convError } = await supabase
      .from("conversations")
      .upsert({ user_1_id: id1, user_2_id: id2 })
      .select()
      .single()

    if (convError) throw convError

    return NextResponse.json({ conversation })
  } catch (error) {
    console.error("[v0] Error starting conversation:", error)
    return NextResponse.json({ error: "Failed to start conversation" }, { status: 500 })
  }
}
