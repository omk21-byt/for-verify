import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"

export async function GET(request: NextRequest) {
  try {
    const cookieStore = await cookies()
    const supabase = createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
      cookies: {
        getAll: () => cookieStore.getAll(),
        setAll: (cookiesToSet) => {
          cookiesToSet.forEach(({ name, value, options }) => {
            cookieStore.set(name, value, options)
          })
        },
      },
    })

    // Get current user session
    const sessionRes = await fetch(new URL("/api/auth/session", request.url), {
      headers: { cookie: request.headers.get("cookie") || "" },
    })
    const sessionData = await sessionRes.json()

    if (!sessionData.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Check if user is admin
    const { data: adminUser } = await supabase.from("users").select("is_admin").eq("id", sessionData.user.id).single()

    if (!adminUser?.is_admin) {
      return NextResponse.json({ error: "Only admins can access pending portfolios" }, { status: 403 })
    }

    // Fetch all portfolios pending review
    const { data, error } = await supabase
      .from("users")
      .select(
        "id, name, email, portfolio_url, skill_score, verified_skills, verification_feedback, admin_review_status",
      )
      .eq("admin_review_status", "pending_review")
      .order("created_at", { ascending: false })

    if (error) {
      console.error("[v0] Database query error:", error)
      return NextResponse.json({ error: "Failed to fetch portfolios" }, { status: 500 })
    }

    return NextResponse.json({ portfolios: data || [] })
  } catch (error) {
    console.error("[v0] API error:", error)
    return NextResponse.json({ error: "Failed to fetch portfolios" }, { status: 500 })
  }
}
