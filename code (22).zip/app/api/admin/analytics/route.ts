import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"
import { NextResponse } from "next/server"

export async function GET() {
  try {
    const cookieStore = await cookies()
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          getAll() {
            return cookieStore.getAll()
          },
          setAll(cookiesToSet) {
            cookiesToSet.forEach(({ name, value, options }) => cookieStore.set(name, value, options))
          },
        },
      },
    )

    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

    // Check if user is admin
    const { data: adminUser } = await supabase.from("users").select("is_admin").eq("id", user.id).single()

    if (!adminUser?.is_admin) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    // Get total users
    const { count: totalUsers } = await supabase.from("users").select("id", { count: "exact", head: true })

    // Get verified profiles
    const { count: verifiedProfiles } = await supabase
      .from("users")
      .select("id", { count: "exact", head: true })
      .eq("admin_review_status", "approved")

    // Get pending profiles
    const { count: pendingProfiles } = await supabase
      .from("users")
      .select("id", { count: "exact", head: true })
      .eq("admin_review_status", "pending")

    // Get rejected profiles
    const { count: rejectedProfiles } = await supabase
      .from("users")
      .select("id", { count: "exact", head: true })
      .eq("admin_review_status", "rejected")

    // Get total skills verified
    const { count: verifiedSkills } = await supabase
      .from("user_skills")
      .select("id", { count: "exact", head: true })
      .eq("verified", true)

    // Get top workers by rating
    const { data: topWorkers } = await supabase
      .from("users")
      .select("id,name,email,star_rating,admin_review_status")
      .eq("admin_review_status", "approved")
      .order("star_rating", { ascending: false })
      .limit(5)

    // Get recent signups
    const { data: recentSignups } = await supabase
      .from("users")
      .select("id,name,email,created_at")
      .order("created_at", { ascending: false })
      .limit(10)

    // Get average completion score (based on profile fields filled)
    const { data: allUsers } = await supabase
      .from("users")
      .select("id,name,email,expertise,interests,portfolio_url,avatar_url")

    const avgCompletionScore =
      allUsers && allUsers.length > 0
        ? Math.round(
            (allUsers.reduce((sum: number, user: any) => {
              let score = 0
              if (user.name) score += 20
              if (user.email) score += 20
              if (user.expertise) score += 20
              if (user.interests) score += 20
              if (user.portfolio_url) score += 20
              return sum + score
            }, 0) /
              allUsers.length) *
              100,
          ) / 100
        : 0

    return NextResponse.json({
      stats: {
        totalUsers: totalUsers || 0,
        verifiedProfiles: verifiedProfiles || 0,
        pendingProfiles: pendingProfiles || 0,
        rejectedProfiles: rejectedProfiles || 0,
        verifiedSkills: verifiedSkills || 0,
        avgCompletionScore,
      },
      topWorkers: topWorkers || [],
      recentSignups: recentSignups || [],
    })
  } catch (error) {
    console.error("[v0] Error fetching analytics:", error)
    return NextResponse.json({ error: "Failed to fetch analytics" }, { status: 500 })
  }
}
