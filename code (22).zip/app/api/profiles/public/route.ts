import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"
import { type NextRequest, NextResponse } from "next/server"

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const search = searchParams.get("search") || ""
  const page = Number.parseInt(searchParams.get("page") || "1")
  const limit = 12

  try {
    const cookieStore = await cookies()
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          getAll() {
            return cookieStore.getAll()
          },
          setAll(cookiesToSet) {
            cookiesToSet.forEach(({ name, value, options }) => cookieStore.set(name, value, options))
          },
        },
      },
    )

    let query = supabase
      .from("users")
      .select(
        "id,name,email,expertise,interests,avatar_url,star_rating,skill_score,verification_status,is_admin,admin_feedback,profile_tags,admin_review_status,selected_job",
      )
      .eq("profile_public", true)
      .order("star_rating", { ascending: false })
      .range((page - 1) * limit, page * limit - 1)

    // Add search filter if provided
    if (search.trim()) {
      query = query.or(`name.ilike.%${search}%,expertise.ilike.%${search}%,interests.ilike.%${search}%`)
    }

    const { data, error, count } = await query

    if (error) throw error

    return NextResponse.json({
      profiles: data,
      total: count,
      page,
      pageSize: limit,
      totalPages: Math.ceil((count || 0) / limit),
    })
  } catch (error) {
    console.error("[v0] Error fetching public profiles:", error)
    return NextResponse.json({ error: "Failed to fetch profiles" }, { status: 500 })
  }
}
