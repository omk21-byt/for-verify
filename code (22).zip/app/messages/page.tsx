"use client"

import type React from "react"
import { useEffect, useState } from "react"
import { useSearchParams } from 'next/navigation'
import { Send, MessageCircle, Loader2, Bell } from 'lucide-react'
import { useAuth } from '@/app/providers'
import DashboardLayout from "@/components/dashboard/layout-wrapper"

interface Conversation {
  id: string
  otherUser: {
    id: string
    name: string
    avatar_url: string
    email: string
  }
  lastMessage: {
    content: string
    created_at: string
  }
}

interface Message {
  id: string
  sender_id: string
  content: string
  created_at: string
}

interface MessageNotification {
  id: string
  type: string
  title: string
  description?: string
  created_at: string
  read: boolean
}

export default function MessagesPage() {
  const searchParams = useSearchParams()
  const targetUserId = searchParams.get("userId")
  const { user, loading: userLoading } = useAuth()

  const [conversations, setConversations] = useState<Conversation[]>([])
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [messageInput, setMessageInput] = useState("")
  const [loading, setLoading] = useState(true)
  const [sending, setSending] = useState(false)
  const [notifications, setNotifications] = useState<MessageNotification[]>([])
  const [showNotifications, setShowNotifications] = useState(false)

  useEffect(() => {
    if (userLoading || !user) return

    const fetchConversations = async () => {
      try {
        const response = await fetch("/api/messages/conversations")
        if (!response.ok) throw new Error("Failed to fetch conversations")
        const data = await response.json()
        setConversations(data.conversations || [])
        
        // If userId param exists, find and select the conversation with that user
        if (targetUserId) {
          const targetConv = data.conversations?.find((c: any) => c.otherUser.id === targetUserId)
          if (targetConv) {
            setSelectedConversation(targetConv.id)
          }
        } else if (data.conversations?.length > 0) {
          // Otherwise, select first conversation
          setSelectedConversation(data.conversations[0].id)
        }
      } catch (error) {
        console.error("[v0] Error fetching conversations:", error)
      } finally {
        setLoading(false)
      }
    }
    fetchConversations()
  }, [user, userLoading, targetUserId])

  useEffect(() => {
    if (!user) return

    const fetchNotifications = async () => {
      try {
        const response = await fetch(`/api/notifications?userId=${user.id}&unreadOnly=true`)
        if (!response.ok) throw new Error("Failed to fetch notifications")
        const data = await response.json()
        setNotifications(data.filter((n: any) => n.type === 'message'))
      } catch (error) {
        console.error("[v0] Error fetching notifications:", error)
      }
    }

    fetchNotifications()
    const interval = setInterval(fetchNotifications, 2000)
    return () => clearInterval(interval)
  }, [user])

  useEffect(() => {
    if (!selectedConversation || !user) return

    const fetchMessages = async () => {
      try {
        const response = await fetch(`/api/messages/${selectedConversation}`)
        if (!response.ok) throw new Error("Failed to fetch messages")
        const data = await response.json()
        setMessages(data.messages || [])

        if (notifications.length > 0) {
          const selectedConv = conversations.find(c => c.id === selectedConversation)
          const relatedNotifications = notifications.filter(n => n.description?.includes(selectedConv?.otherUser.name || ''))
          
          for (const notif of relatedNotifications) {
            await fetch(`/api/notifications/${notif.id}`, {
              method: 'PATCH',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ read: true })
            })
          }

          if (relatedNotifications.length > 0) {
            setNotifications(prev => prev.filter(n => !relatedNotifications.some(rn => rn.id === n.id)))
          }
        }
      } catch (error) {
        console.error("[v0] Error fetching messages:", error)
      }
    }

    fetchMessages()
    const interval = setInterval(fetchMessages, 2000)
    return () => clearInterval(interval)
  }, [selectedConversation, user, notifications, conversations])

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!messageInput.trim() || !selectedConversation || !user) return

    setSending(true)
    try {
      const conversation = conversations.find((c) => c.id === selectedConversation)
      const recipientId = conversation?.otherUser.id

      if (!recipientId) throw new Error("Recipient not found")

      const response = await fetch("/api/messages/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          recipientId,
          content: messageInput,
        }),
      })

      if (!response.ok) throw new Error("Failed to send message")

      setMessageInput("")

      await fetch('/api/notifications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: recipientId,
          type: 'message',
          title: 'New message',
          description: `${user.name} sent you a message: "${messageInput.substring(0, 50)}..."`,
          related_user_id: user.id,
          related_item_id: selectedConversation,
        }),
      })

      const messagesResponse = await fetch(`/api/messages/${selectedConversation}`)
      const messagesData = await messagesResponse.json()
      setMessages(messagesData.messages || [])
    } catch (error) {
      console.error("[v0] Error sending message:", error)
    } finally {
      setSending(false)
    }
  }

  if (userLoading || loading) {
    return (
      <DashboardLayout title="Messages" description="Chat with professionals">
        <div className="flex items-center justify-center h-96">
          <p className="text-gray-600">Loading messages...</p>
        </div>
      </DashboardLayout>
    )
  }

  const selectedConv = conversations.find((c) => c.id === selectedConversation)
  const unreadNotificationCount = notifications.length

  return (
    <DashboardLayout title="Messages" description="Chat with professionals">
      <div className="flex gap-6 h-[calc(100vh-12rem)]">
        {/* Conversations List */}
        <div className="w-80 bg-white rounded-xl border border-gray-200 overflow-hidden flex flex-col shadow-sm">
          <div className="p-4 border-b border-gray-200 flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900">Conversations</h2>
            <div className="relative">
              <button 
                onClick={() => setShowNotifications(!showNotifications)}
                className="p-2 hover:bg-gray-100 rounded-lg transition relative"
              >
                <Bell className="w-5 h-5 text-gray-600" />
                {unreadNotificationCount > 0 && (
                  <span className="absolute top-0 right-0 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center font-semibold">
                    {unreadNotificationCount}
                  </span>
                )}
              </button>

              {/* Notification Dropdown */}
              {showNotifications && (
                <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg border border-gray-200 z-50 max-h-96 overflow-y-auto">
                  <div className="p-3 border-b border-gray-200 font-semibold text-gray-900">Message Notifications</div>
                  {notifications.length === 0 ? (
                    <div className="p-4 text-center text-gray-500 text-sm">No new notifications</div>
                  ) : (
                    <div className="divide-y divide-gray-200">
                      {notifications.map((notif) => (
                        <div key={notif.id} className="p-3 hover:bg-gray-50 cursor-pointer">
                          <p className="text-sm font-medium text-gray-900">{notif.title}</p>
                          <p className="text-xs text-gray-600 mt-1">{notif.description}</p>
                          <p className="text-xs text-gray-400 mt-2">{new Date(notif.created_at).toLocaleTimeString()}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          <div className="flex-1 overflow-y-auto">
            {conversations.length === 0 ? (
              <div className="p-6 text-center text-gray-500">
                <MessageCircle className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">No conversations yet</p>
              </div>
            ) : (
              conversations.map((conv) => (
                <button
                  key={conv.id}
                  onClick={() => setSelectedConversation(conv.id)}
                  className={`w-full p-4 border-b border-gray-100 text-left transition ${
                    selectedConversation === conv.id
                      ? "bg-indigo-50 border-l-4 border-l-indigo-600"
                      : "hover:bg-gray-50"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={conv.otherUser.avatar_url || "/placeholder.svg?height=40&width=40"}
                      alt={conv.otherUser.name}
                      className="w-10 h-10 rounded-full object-cover"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm text-gray-900">{conv.otherUser.name}</p>
                      <p className="text-xs text-gray-600 truncate">{conv.lastMessage?.content || "No messages"}</p>
                    </div>
                  </div>
                </button>
              ))
            )}
          </div>
        </div>

        {/* Chat Area */}
        {selectedConv ? (
          <div className="flex-1 bg-white rounded-xl border border-gray-200 overflow-hidden flex flex-col shadow-sm">
            {/* Chat Header */}
            <div className="p-4 border-b border-gray-200 flex items-center gap-3">
              <img
                src={selectedConv.otherUser.avatar_url || "/placeholder.svg?height=40&width=40"}
                alt={selectedConv.otherUser.name}
                className="w-10 h-10 rounded-full object-cover"
              />
              <div>
                <p className="font-semibold text-gray-900">{selectedConv.otherUser.name}</p>
                <p className="text-xs text-gray-500">{selectedConv.otherUser.email}</p>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
              {messages.length === 0 ? (
                <div className="flex items-center justify-center h-full text-gray-500">
                  <p className="text-sm">No messages yet. Start the conversation!</p>
                </div>
              ) : (
                messages.map((msg) => (
                  <div key={msg.id} className={`flex ${msg.sender_id === user?.id ? "justify-end" : "justify-start"}`}>
                    <div
                      className={`max-w-xs px-4 py-2 rounded-lg ${
                        msg.sender_id === user?.id
                          ? "bg-indigo-600 text-white rounded-br-none"
                          : "bg-gray-200 text-gray-900 rounded-bl-none"
                      }`}
                    >
                      <p className="text-sm">{msg.content}</p>
                      <p className="text-xs mt-1 opacity-70">{new Date(msg.created_at).toLocaleTimeString()}</p>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Message Input */}
            <form onSubmit={handleSendMessage} className="p-4 border-t border-gray-200 flex gap-3">
              <input
                type="text"
                value={messageInput}
                onChange={(e) => setMessageInput(e.target.value)}
                placeholder="Type a message..."
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-600"
              />
              <button
                type="submit"
                disabled={sending || !messageInput.trim()}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition disabled:opacity-50 flex items-center gap-2"
              >
                {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              </button>
            </form>
          </div>
        ) : (
          <div className="flex-1 bg-white rounded-xl border border-gray-200 flex items-center justify-center shadow-sm">
            <div className="text-center text-gray-500">
              <MessageCircle className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p className="text-sm">Select a conversation to start messaging</p>
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  )
}
