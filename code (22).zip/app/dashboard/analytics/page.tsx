"use client"

import DashboardLayout from "@/components/dashboard/layout-wrapper"
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

const analyticsData = [
  { month: "Jan", views: 400, interactions: 240 },
  { month: "Feb", views: 300, interactions: 221 },
  { month: "Mar", views: 200, interactions: 229 },
  { month: "Apr", views: 278, interactions: 200 },
  { month: "May", views: 189, interactions: 221 },
  { month: "Jun", views: 239, interactions: 250 },
]

export default function AnalyticsPage() {
  return (
    <DashboardLayout title="Analytics" description="View your profile analytics">
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Profile Views</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-indigo-600">1,429</p>
              <p className="text-sm text-gray-600 mt-1">+12% from last month</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Interactions</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-purple-600">342</p>
              <p className="text-sm text-gray-600 mt-1">+8% from last month</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Engagement Rate</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-pink-600">24%</p>
              <p className="text-sm text-gray-600 mt-1">+3% from last month</p>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Activity Trend</CardTitle>
            <CardDescription>Your profile views and interactions over time</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={analyticsData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="views" stroke="#4f46e5" name="Views" strokeWidth={2} />
                <Line type="monotone" dataKey="interactions" stroke="#a855f7" name="Interactions" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
