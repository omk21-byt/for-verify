"use client"

import type React from "react"
import { useEffect, useState, useRef } from "react"
import { CalendarStrip } from "@/components/dashboard/calendar-strip"
import { UserExperienceDisplay } from "@/components/dashboard/user-experience-display"
import { useRouter } from 'next/navigation'
import { useToast } from "@/hooks/use-toast"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import DashboardLayout from "@/components/dashboard/layout-wrapper"
import { Edit2, Upload, Home } from 'lucide-react'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { AIVerificationProcess } from "@/components/ai-verification-process"
import { WorkProgressCard } from "@/components/dashboard/work-progress-card"


interface UserProfile {
  id: string
  name: string
  email: string
  portfolio_url: string
  avatar_url: string
  verification_status: string
  skill_score: number
  verified_skills: Skill[]
  last_verified_at: string
  verification_feedback: string
  star_rating: number
  admin_feedback: string
  profile_public: boolean
  selected_job: string
  profile_tags: string[]
  profile_type: string
  expertise: string
  experience: string
  interests: string
}

interface Skill {
  id: string
  skill_name: string
  verified: boolean
  proof_link: string
}

const JOB_TITLES = [
  "Software Engineer",
  "Data Analyst",
  "Web Developer",
  "App Developer",
  "Cloud Engineer",
  "AI/ML Engineer",
  "Cybersecurity",
  "Database Engineer",
  "Graphic Designer",
  "UI/UX Designer",
  "Video Editor",
  "Content Creator",
  "Digital Marketer",
  "SEO Specialist",
  "Social Media",
  "Email Marketing",
  "Project Manager",
  "Business Analyst",
  "Sales Executive",
  "Customer Support",
  "Virtual Assistant",
]

export default function DashboardPage() {
  const router = useRouter()
  const { toast } = useToast()

  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [skills, setSkills] = useState<Skill[]>([])
  const [loading, setLoading] = useState(true)
  const [isEditing, setIsEditing] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [isUploading, setIsUploading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const pollingIntervalRef = useRef<NodeJS.Timeout | null>(null)
  const pollCountRef = useRef(0)

  const [editData, setEditData] = useState({
    name: "",
    portfolio: "",
    selected_job: "",
  })

  const [isPublic, setIsPublic] = useState(false)
  const [isTogglingVisibility, setIsTogglingVisibility] = useState(false)

  const fetchProfile = async (userId?: string) => {
    try {
      let userIdToUse = userId

      if (!userIdToUse) {
        const sessionRes = await fetch("/api/auth/session")
        const sessionData = await sessionRes.json()

        if (!sessionData.user) {
          toast({ title: "Error", description: "Not authenticated", variant: "destructive" })
          router.push("/login")
          return
        }

        userIdToUse = sessionData.user.id
      }

      const response = await fetch(`/api/profile/get?userId=${userIdToUse}`)
      if (!response.ok) throw new Error("Failed to fetch profile")

      const data = await response.json()
      setProfile(data.user)
      setSkills(data.skills || [])
      setEditData({
        name: data.user.name,
        portfolio: data.user.portfolio_url || "",
        selected_job: data.user.selected_job || "",
      })
      setIsPublic(data.user.profile_public || false)

      return data.user
    } catch (error) {
      console.error("[v0] fetch profile error:", error)
    }
  }

  const startVerificationPolling = (userId: string) => {
    if (pollingIntervalRef.current) {
      clearInterval(pollingIntervalRef.current)
    }

    pollCountRef.current = 0
    const maxPolls = 120

    pollingIntervalRef.current = setInterval(async () => {
      pollCountRef.current++
      const updatedProfile = await fetchProfile(userId)

      if (updatedProfile?.verification_status === "verified") {
        if (pollingIntervalRef.current) {
          clearInterval(pollingIntervalRef.current)
          pollingIntervalRef.current = null
        }
        toast({ title: "Success", description: "Portfolio verified successfully!" })
        return
      }

      if (pollCountRef.current >= maxPolls) {
        if (pollingIntervalRef.current) {
          clearInterval(pollingIntervalRef.current)
          pollingIntervalRef.current = null
        }
      }
    }, 1000)
  }

  useEffect(() => {
    const fetchProfileOnMount = async () => {
      try {
        const sessionRes = await fetch("/api/auth/session")
        const sessionData = await sessionRes.json()

        if (!sessionData.user) {
          toast({ title: "Error", description: "Not authenticated", variant: "destructive" })
          router.push("/login")
          return
        }

        const userId = sessionData.user.id
        const userData = await fetchProfile(userId)

        if (userData?.verification_status === "pending" && userData?.portfolio_url) {
          startVerificationPolling(userId)
        }
      } catch (error) {
        console.error("[v0] fetch profile error:", error)
        toast({ title: "Error", description: "Failed to load profile", variant: "destructive" })
      } finally {
        setLoading(false)
      }
    }

    fetchProfileOnMount()

    return () => {
      if (pollingIntervalRef.current) {
        clearInterval(pollingIntervalRef.current)
      }
    }
  }, [toast, router])

  const handleEditChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setEditData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSaveProfile = async () => {
    if (!profile?.id) return
    setIsSaving(true)

    try {
      const response = await fetch("/api/profile/update", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: profile.id,
          name: editData.name,
          portfolio: editData.portfolio,
          selected_job: editData.selected_job,
        }),
      })

      if (!response.ok) throw new Error("Failed to update profile")

      const updatedUser = await response.json()
      setProfile(updatedUser.user)
      setIsEditing(false)

      if (editData.portfolio && updatedUser.user.verification_status === "pending") {
        startVerificationPolling(profile.id)
      }

      toast({ title: "Success", description: "Profile updated successfully" })
    } catch (error) {
      console.error("[v0] save profile error:", error)
      toast({ title: "Error", description: "Failed to update profile", variant: "destructive" })
    } finally {
      setIsSaving(false)
    }
  }

  const handleAvatarClick = () => {
    if (isEditing) {
      fileInputRef.current?.click()
    }
  }

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file || !profile?.id) return

    if (file.size > 100 * 1024) {
      toast({
        title: "File too large",
        description: `File size must be under 100KB. Your file is ${Math.round(file.size / 1024)}KB.`,
        variant: "destructive",
      })
      return
    }

    const validMimeTypes = ["image/jpeg", "image/png", "image/webp", "image/gif"]
    if (!validMimeTypes.includes(file.type)) {
      toast({
        title: "Invalid file type",
        description: "Only JPEG, PNG, WebP, and GIF are allowed.",
        variant: "destructive",
      })
      return
    }

    setIsUploading(true)
    try {
      const formData = new FormData()
      formData.append("file", file)
      formData.append("userId", profile.id)

      const response = await fetch("/api/profile/upload-avatar", {
        method: "POST",
        body: formData,
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Upload failed")
      }

      const { avatar_url } = await response.json()
      setProfile((prev) => (prev ? { ...prev, avatar_url } : null))

      toast({
        title: "Success",
        description: "Profile picture updated",
      })
    } catch (error) {
      console.error("[v0] upload error:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to upload profile picture",
        variant: "destructive",
      })
    } finally {
      setIsUploading(false)
    }
  }

  const handleLogout = async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST" })
      router.push("/login")
    } catch (error) {
      console.error("[v0] logout error:", error)
      toast({ title: "Error", description: "Failed to logout", variant: "destructive" })
    }
  }

  const handleGoHome = () => {
    router.push("/")
  }

  const handleToggleVisibility = async () => {
    if (!profile?.id) return
    setIsTogglingVisibility(true)

    try {
      const response = await fetch("/api/profiles/toggle-visibility", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isPublic: !isPublic }),
      })

      if (!response.ok) throw new Error("Failed to toggle visibility")

      const data = await response.json()
      setProfile(data.user)
      setIsPublic(data.user.profile_public)

      toast({
        title: "Success",
        description: isPublic ? "Your profile is now private" : "Your profile is now visible to everyone",
      })
    } catch (error) {
      console.error("[v0] toggle visibility error:", error)
      toast({
        title: "Error",
        description: "Failed to update profile visibility",
        variant: "destructive",
      })
    } finally {
      setIsTogglingVisibility(false)
    }
  }

  if (loading) {
    return (
      <DashboardLayout title="Dashboard" description="Manage your profile and verification">
        <div className="flex items-center justify-center h-96">
          <p className="text-gray-600">Loading your profile...</p>
        </div>
      </DashboardLayout>
    )
  }

  if (!profile) {
    return (
      <DashboardLayout title="Dashboard" description="Manage your profile and verification">
        <div className="flex items-center justify-center h-96">
          <p className="text-gray-600">Profile not found</p>
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout title="Welcome back" description={`${profile.name}, manage your profile here`}>
            {/* Top header */}
            <div className="flex items-center justify-between mb-5">
              <div>
                <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
                  Welcome {profile.name}
                </h1>
                <p className="text-sm text-gray-600 mt-1">
                  Manage your profile, verification and verified skills.
                </p>
              </div>

              <div className="flex items-center gap-3">
                <Button
                  onClick={handleGoHome}
                  variant="ghost"
                  className="border border-transparent bg-white/60 text-[#1C073A]"
                >
                  <Home className="w-4 h-4 mr-2" />
                  Home
                </Button>

                <Button onClick={() => setIsEditing(!isEditing)} variant="outline" className="hidden sm:flex gap-2">
                  <Edit2 className="w-4 h-4" />
                  {isEditing ? "Cancel" : "Edit Profile"}
                </Button>
              </div>
            </div>


      {/* Grid layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Column 1: Profile & Visibility (span 4) */}
        <div className="lg:col-span-4 space-y-6">
          {/* Profile Card */}
          <Card className="rounded-2xl p-6 shadow-md border-0 bg-white">
            <div className="flex items-start gap-4">
              <div className="relative">
                <img
                  src={profile.avatar_url || "/placeholder.svg?height=120&width=120"}
                  alt="Avatar"
                  className={`h-20 w-20 rounded-lg object-cover bg-gray-200 ${isEditing ? "cursor-pointer" : "cursor-default"}`}
                  onClick={handleAvatarClick}
                />
                {isEditing && (
                  <div className="absolute right-0 bottom-0">
                    <button
                      onClick={handleAvatarClick}
                      disabled={isUploading}
                      className="p-1 rounded bg-[#B6FF00] hover:brightness-90 disabled:opacity-50"
                      title="Change avatar"
                    >
                      <Upload className="w-4 h-4 text-[#1C073A]" />
                    </button>
                  </div>
                )}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileChange}
                  className="hidden"
                  disabled={isUploading}
                />
              </div>

              <div className="flex-1">
                <h2 className="text-xl font-semibold">{profile.name}</h2>
                <p className="text-sm text-gray-600">{profile.email}</p>
                {profile.selected_job && (
                  <p className="text-sm text-[#0B6B2E] font-medium mt-2">{profile.selected_job}</p>
                )}

                {profile.profile_tags && profile.profile_tags.length > 0 && (
                  <div className="flex gap-2 mt-3 flex-wrap">
                    {profile.profile_tags.map((tag) => (
                      <span
                        key={tag}
                        className="text-xs px-2 py-1 bg-[#F1FFE0] text-[#0B6B2E] rounded-full text-background bg-blue-600"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                )}

                <div className="mt-4 flex gap-2">
                  <Button onClick={() => setIsEditing(!isEditing)} variant="default" className="flex-1">
                    {isEditing ? "Cancel" : "Edit"}
                  </Button>
                  <Button onClick={handleGoHome} variant="outline" className="flex-1 bg-transparent">
                    <Home className="w-4 h-4" />
                    Home
                  </Button>
                </div>
              </div>
            </div>

            {/* Edit form (mobile friendly) */}
            {isEditing && (
              <div className="mt-6 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                  <Input name="name" value={editData.name} onChange={handleEditChange} placeholder="Your name" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Job Title / Role</label>
                  <Select
                    value={editData.selected_job}
                    onValueChange={(value) => setEditData({ ...editData, selected_job: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select your job title" />
                    </SelectTrigger>
                    <SelectContent>
                      {JOB_TITLES.map((job) => (
                        <SelectItem key={job} value={job}>
                          {job}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Portfolio / Work Link</label>
                  <Input
                    name="portfolio"
                    type="url"
                    value={editData.portfolio}
                    onChange={handleEditChange}
                    placeholder="https://example.com/portfolio"
                  />
                </div>

                <div className="flex gap-3 pt-4">
                  <Button onClick={handleSaveProfile} disabled={isSaving} className="flex-1">
                    {isSaving ? "Saving..." : "Save Changes"}
                  </Button>
                  <Button
                    onClick={() => setIsEditing(false)}
                    variant="outline"
                    className="flex-1"
                    disabled={isSaving}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            )}
          </Card>

          {/* Visibility Card */}
          <Card className="rounded-2xl p-6 shadow-md border-0 bg-white">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Profile Visibility</h3>
                <p className="text-sm text-gray-600 mt-1">
                  {isPublic
                    ? "Your profile is visible to all users and appears in the search directory."
                    : "Your profile is private and only visible to you."}
                </p>
              </div>

              <div>
                <button
                  onClick={handleToggleVisibility}
                  disabled={isTogglingVisibility}
                  className={`px-4 py-2 rounded-md text-sm font-medium ${
                    isPublic ? "bg-[#B6FF00] text-[#1C073A]" : "bg-gray-200 text-gray-800"
                  }`}
                >
                  {isTogglingVisibility ? "Updating..." : isPublic ? "Make Private" : "Make Public"}
                </button>
              </div>
            </div>
                        <CalendarStrip />
          </Card>
        </div>

        {/* Column 2: Stats & Activity (span 4) */}
        <div className="lg:col-span-4 space-y-6">

        {/* Activity & Progress */}
          <Card className="rounded-2xl p-6 shadow-md border-0 bg-white">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Activity & Progress</h3>
              <div className="text-sm text-gray-500">Overview</div>
            </div>

            <div className="grid grid-cols-1 gap-4">
              <div className="p-4 rounded-lg bg-gray-50">
                <p className="text-xs text-gray-500">Portfolio Status</p>
                <p className="mt-2 font-semibold capitalize">{profile.verification_status ?? "not submitted"}</p>
              </div>

              <div className="p-4 rounded-lg bg-gray-50">
                <p className="text-xs text-gray-500">Last Verified</p>
                <p className="mt-2 font-semibold">
                  {profile.last_verified_at ? new Date(profile.last_verified_at).toLocaleDateString() : "N/A"}
                </p>
              </div>

              <div className="p-4 rounded-lg bg-gray-50">
                <p className="text-xs text-gray-500">Admin Rating</p>
                <p className="mt-2 font-semibold">{profile.star_rating ? `${profile.star_rating}/5 ⭐` : "—"}</p>
              </div>
            </div>
          </Card>
          {/* Quick stats card */}
         <WorkProgressCard />
          <Card className="rounded-2xl p-6 shadow-md border-0 bg-white">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm text-gray-500">Skill Score</h4>
                <p className="text-2xl font-semibold">{profile.skill_score ?? 0}</p>
              </div>
              <div className="text-right">
                <h4 className="text-sm text-gray-500">Verified</h4>
                <p className="text-2xl font-semibold">{profile.verified_skills?.length ?? 0}</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Column 3: AI Verification & Experience (span 4) */}
        <div className="lg:col-span-4 space-y-6">
          {/* Portfolio Verification */}
          <div>
            <AIVerificationProcess
              status={profile?.verification_status || "pending"}
              skillScore={profile?.skill_score}
              adminFeedback={profile?.admin_feedback}
              starRating={profile?.star_rating}
            />
          </div>

          {/* User Experience and Background Display */}
          <div>
            <UserExperienceDisplay
              learningSource={profile?.expertise}
              hasWorkExperience={profile?.experience ? true : false}
              previousExperience={profile?.experience}
              selectedJobs={profile?.interests?.split(", ").filter(Boolean)}
            />
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
