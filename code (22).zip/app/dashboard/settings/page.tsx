"use client"

import { useState } from "react"
import DashboardLayout from "@/components/dashboard/layout-wrapper"
import { Bell, Shield, Eye, Lock } from 'lucide-react'
import { Button } from "@/components/ui/button"

interface SettingItem {
  id: string
  title: string
  description: string
  icon: React.ComponentType<{ className: string }>
  enabled: boolean
}

export default function SettingsPage() {
  const [settings, setSettings] = useState<SettingItem[]>([
    {
      id: "notifications",
      title: "Email Notifications",
      description: "Receive email updates about your profile",
      icon: Bell,
      enabled: true,
    },
    {
      id: "privacy",
      title: "Profile Visibility",
      description: "Make your profile publicly visible",
      icon: Eye,
      enabled: true,
    },
    {
      id: "security",
      title: "Two-Factor Authentication",
      description: "Add an extra layer of security",
      icon: Shield,
      enabled: false,
    },
    {
      id: "password",
      title: "Password Protection",
      description: "Change your password regularly",
      icon: Lock,
      enabled: true,
    },
  ])

  const toggleSetting = (id: string) => {
    setSettings((prev) =>
      prev.map((setting) =>
        setting.id === id ? { ...setting, enabled: !setting.enabled } : setting
      )
    )
  }

  return (
    <DashboardLayout title="Settings" description="Manage your account settings">
      <div className="max-w-2xl space-y-4">
        {settings.map((setting) => {
          const Icon = setting.icon
          return (
            <div
              key={setting.id}
              className="bg-white rounded-lg border border-gray-200 p-6 flex items-center justify-between hover:shadow-md transition"
            >
              <div className="flex items-start gap-4">
                <Icon className="w-6 h-6 text-indigo-600 mt-1" />
                <div>
                  <h3 className="font-semibold text-gray-900">{setting.title}</h3>
                  <p className="text-sm text-gray-600">{setting.description}</p>
                </div>
              </div>
              <button
                onClick={() => toggleSetting(setting.id)}
                className={`relative inline-flex h-8 w-14 items-center rounded-full transition ${
                  setting.enabled ? "bg-indigo-600" : "bg-gray-300"
                }`}
              >
                <span
                  className={`inline-block h-6 w-6 transform rounded-full bg-white transition ${
                    setting.enabled ? "translate-x-7" : "translate-x-1"
                  }`}
                />
              </button>
            </div>
          )
        })}
      </div>
    </DashboardLayout>
  )
}
