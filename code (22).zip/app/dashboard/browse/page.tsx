"use client"

import DashboardLayout from "@/components/dashboard/layout-wrapper"
import LatestRolesSection from "@/components/shiftza/sections/latest-roles"

export default function BrowseProfessionalsPage() {
  return (
    <DashboardLayout 
      title="Discover Professionals" 
      description="Browse and connect with verified professionals"
    >
      <div className="space-y-6">
        <LatestRolesSection />
      </div>
    </DashboardLayout>
  )
}
