"use client"

import { useState, useEffect } from "react"
import DashboardLayout from "@/components/dashboard/layout-wrapper"
import { ProfileView } from "@/components/dashboard/profile-editor/profile-view"
import { ProfileForm } from "@/components/dashboard/profile-editor/profile-form"
import { ProfileData } from "@/components/dashboard/profile-editor/profile-form"
import { Loader2 } from 'lucide-react'

const DEFAULT_PROFILE: ProfileData = {
  id: "user-123",
  name: "John Doe",
  email: "john@example.com",
  phone: "+1 (555) 123-4567",
  bio: "Full stack developer passionate about building amazing products",
  role: "Full Stack Developer",
  location: "San Francisco, CA",
  skills: ["React", "TypeScript", "Next.js"],
  username: "johndoe",
  avatar_url: "",
  created_at: new Date().toISOString(),
  updated_at: new Date().toISOString(),
}

export default function ProfilePage() {
  const [profile, setProfile] = useState<ProfileData>(DEFAULT_PROFILE)
  const [isEditing, setIsEditing] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Simulate loading profile from backend
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 500)

    return () => clearTimeout(timer)
  }, [])

  const handleSave = async (updates: Partial<ProfileData>) => {
    // In production, send to backend
    await new Promise((resolve) => setTimeout(resolve, 800))
    setProfile((prev) => ({
      ...prev,
      ...updates,
      updated_at: new Date().toISOString(),
    }))
    setIsEditing(false)
  }

  if (isLoading) {
    return (
      <DashboardLayout title="Profile" description="View and manage your profile">
        <div className="flex items-center justify-center min-h-[400px]">
          <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout title={isEditing ? "Edit Profile" : "My Profile"} 
      description={isEditing ? "Update your profile information" : "View your profile information"}>
      <div className="max-w-4xl">
        {isEditing ? (
          <ProfileForm
            profile={profile}
            onSave={handleSave}
            onCancel={() => setIsEditing(false)}
          />
        ) : (
          <ProfileView profile={profile} onEdit={() => setIsEditing(true)} />
        )}
      </div>
    </DashboardLayout>
  )
}
