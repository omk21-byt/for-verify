"use client"

import { useState } from "react"
import DashboardLayout from "@/components/dashboard/layout-wrapper"
import { Send, Smile } from 'lucide-react'

interface Message {
  id: string
  from: string
  avatar: string
  preview: string
  timestamp: Date
  read: boolean
}

export default function MessagesPage() {
  const [messages] = useState<Message[]>([
    {
      id: "1",
      from: "Sarah Chen",
      avatar: "https://placeholder.svg?height=40&width=40&query=profile-avatar",
      preview: "Hey! I saw your profile and I'm impressed with your work...",
      timestamp: new Date(Date.now() - 1000 * 60 * 30),
      read: false,
    },
    {
      id: "2",
      from: "Alex Johnson",
      avatar: "https://placeholder.svg?height=40&width=40&query=profile-avatar",
      preview: "Thanks for connecting! Let's discuss the project...",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2),
      read: true,
    },
    {
      id: "3",
      from: "Emma Wilson",
      avatar: "https://placeholder.svg?height=40&width=40&query=profile-avatar",
      preview: "I'd like to collaborate on your next project...",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24),
      read: true,
    },
  ])

  const [replyText, setReplyText] = useState("")

  const handleSendMessage = () => {
    if (replyText.trim()) {
      setReplyText("")
      // Handle sending message
    }
  }

  return (
    <DashboardLayout title="Messages" description="Manage your conversations">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Messages List */}
        <div className="lg:col-span-1 space-y-2">
          <h3 className="font-semibold text-gray-900 px-4 py-2">Conversations</h3>
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`p-4 rounded-lg cursor-pointer transition hover:bg-gray-50 ${
                !msg.read ? "bg-blue-50 border border-blue-200" : "border border-gray-200"
              }`}
            >
              <p className="font-medium text-gray-900 text-sm">{msg.from}</p>
              <p className="text-xs text-gray-600 mt-1 line-clamp-2">{msg.preview}</p>
            </div>
          ))}
        </div>

        {/* Chat Area */}
        <div className="lg:col-span-2 bg-white rounded-lg border border-gray-200 p-6 flex flex-col">
          <div className="flex-1 mb-6 space-y-4">
            <div className="text-center py-8 text-gray-500">
              <p>Select a message to start chatting</p>
            </div>
          </div>

          <div className="border-t pt-4">
            <div className="flex gap-2">
              <input
                type="text"
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                placeholder="Type your message..."
                className="flex-1 px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-600"
              />
              <button className="p-2 text-gray-400 hover:text-gray-600 transition">
                <Smile className="w-5 h-5" />
              </button>
              <button
                onClick={handleSendMessage}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
