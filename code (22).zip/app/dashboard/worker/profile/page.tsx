"use client"

import { useEffect, useState } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import { Clock, Loader2, Save } from "lucide-react"
import Sidebar from "@/components/dashboard/Sidebar"
import Topbar from "@/components/dashboard/Topbar"
import { SkillCategorySelector, getJobsForSkills } from "@/components/Signup/skill-category-selector"
import { ExperienceSourceSelector } from "@/components/Signup/experience-source-selector"
import { SkillProofSelector } from "@/components/Signup/skill-proof-selector"
import { JobProfileSelector } from "@/components/Signup/job-profile-selector"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"

export default function ProfileEditorPage() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const userId = searchParams.get("userId")

  const [profile, setProfile] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  const [formData, setFormData] = useState({
    name: "",
    expertise: "",
    interests: "",
    portfolio_url: "",
    experience: "",
  })

  const [skillsData, setSkillsData] = useState<string[]>([])
  const [selectedJobs, setSelectedJobs] = useState<string[]>([])
  const [learningSource, setLearningSource] = useState("")
  const [hasWorkExperience, setHasWorkExperience] = useState(false)
  const [previousExperience, setPreviousExperience] = useState("")
  const [canProveSkill, setCanProveSkill] = useState(false)
  const [proofLink, setProofLink] = useState("")
  const [proofDescription, setProofDescription] = useState("")

  useEffect(() => {
    if (!userId) return

    const fetchProfile = async () => {
      try {
        const response = await fetch(`/api/dashboard/profile?userId=${userId}`)
        if (!response.ok) throw new Error("Failed to fetch profile")

        const data = await response.json()
        setProfile(data.profile)

        setFormData({
          name: data.profile?.name || "",
          expertise: data.profile?.expertise || "",
          interests: data.profile?.interests || "",
          portfolio_url: data.profile?.portfolio_url || "",
          experience: data.profile?.experience || "",
        })

        setLearningSource(data.profile?.learning_source || "")
        setHasWorkExperience(data.profile?.has_work_experience || false)
        setPreviousExperience(data.profile?.work_experience || "")
        setCanProveSkill(data.profile?.can_prove_skill || false)

        if (data.profile?.verified_skills) {
          const skillNames = Array.isArray(data.profile.verified_skills)
            ? data.profile.verified_skills
            : Object.keys(data.profile.verified_skills)
          setSkillsData(skillNames)
          setSelectedJobs(getJobsForSkills(skillNames))
        }
      } catch (error) {
        console.error("[v0] Failed to fetch profile:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchProfile()
  }, [userId])

  const handleSaveProfile = async () => {
    if (!userId) return

    setSaving(true)
    try {
      const response = await fetch("/api/dashboard/profile/update", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId,
          name: formData.name,
          expertise: formData.expertise,
          interests: formData.interests,
          portfolio_url: formData.portfolio_url,
          experience: formData.experience,
          verified_skills: skillsData,
          selected_job: selectedJobs.join(","),
          learningSource,
          hasWorkExperience,
          previousExperience,
          canProveSkill,
          proofLink,
          proofDescription,
          skills: skillsData.map((skill) => ({
            skill_name: skill,
            proof_link: proofLink,
            proof_description: proofDescription,
          })),
        }),
      })

      if (!response.ok) throw new Error("Failed to save profile")

      alert("Profile updated successfully! Awaiting admin verification.")
      router.push(`/dashboard/worker?userId=${userId}`)
    } catch (error) {
      console.error("[v0] Failed to save profile:", error)
      alert("Failed to save profile. Please try again.")
    } finally {
      setSaving(false)
    }
  }

  if (loading) return <div className="min-h-screen bg-white">Loading...</div>
  if (!userId) return <div className="min-h-screen bg-white">Invalid session</div>

  return (
    <div className="min-h-screen bg-stone-100 text-[#1a1a2e]">
      <Sidebar />
      <Topbar name={profile?.name || "User"} />

      <main className="pt-24 pr-8 pb-12 pl-80">
        <div className="mb-6">
          <h1 className="text-4xl font-semibold">Edit Your Profile</h1>
          <p className="text-sm text-gray-600 mt-1">
            Update all your professional information. Changes will require admin re-verification.
          </p>
        </div>

        <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg flex items-start gap-3">
          <Clock className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
          <div>
            <p className="font-semibold text-blue-900">Profile Updates Require Re-Verification</p>
            <p className="text-sm text-blue-800">
              When you save changes, your profile will be set to pending and require admin verification before showing
              as verified again.
            </p>
          </div>
        </div>

        <div className="space-y-6 max-w-4xl">
          {/* Basic Information */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h2 className="text-xl font-semibold mb-4">Basic Information</h2>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Enter your full name"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Portfolio / Work Link</label>
                <Input
                  type="url"
                  value={formData.portfolio_url}
                  onChange={(e) => setFormData({ ...formData, portfolio_url: e.target.value })}
                  placeholder="https://yourportfolio.com"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Expertise</label>
                <Textarea
                  value={formData.expertise}
                  onChange={(e) => setFormData({ ...formData, expertise: e.target.value })}
                  placeholder="Describe your areas of expertise"
                  className="min-h-24"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Interests</label>
                <Textarea
                  value={formData.interests}
                  onChange={(e) => setFormData({ ...formData, interests: e.target.value })}
                  placeholder="What are you interested in?"
                  className="min-h-24"
                />
              </div>
            </div>
          </div>

          {/* Skills Section */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h2 className="text-xl font-semibold mb-4">Select Your Skills</h2>
            <p className="text-sm text-gray-600 mb-4">
              Choose skills you want to highlight. These will appear on your profile and require admin verification.
            </p>
            <SkillCategorySelector
              selectedSkills={skillsData}
              onSkillsChange={(newSkills) => {
                setSkillsData(newSkills)
                setSelectedJobs(getJobsForSkills(newSkills))
              }}
            />
          </div>

          {/* Experience & Proof */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h2 className="text-xl font-semibold mb-4">Experience & Proof</h2>
            <ExperienceSourceSelector
              learningSource={learningSource}
              hasWorkExperience={hasWorkExperience}
              previousExperience={previousExperience}
              onLearningSourceChange={setLearningSource}
              onWorkExperienceChange={setHasWorkExperience}
              onPreviousExperienceChange={setPreviousExperience}
            />
          </div>

          {/* Skill Proof */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h2 className="text-xl font-semibold mb-4">Skill Proof</h2>
            <SkillProofSelector
              canProveSkill={canProveSkill}
              proofLink={proofLink}
              proofDescription={proofDescription}
              onCanProveChange={setCanProveSkill}
              onProofLinkChange={setProofLink}
              onProofDescriptionChange={setProofDescription}
            />
          </div>

          {/* Suggested Job Profiles */}
          {skillsData.length > 0 && (
            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <h2 className="text-xl font-semibold mb-4">Suggested Job Profiles</h2>
              <p className="text-sm text-gray-600 mb-4">
                Based on your selected skills, these are suggested roles you might be interested in.
              </p>
              <JobProfileSelector
                availableJobs={getJobsForSkills(skillsData)}
                selectedJobs={selectedJobs}
                onJobsChange={setSelectedJobs}
              />
            </div>
          )}

          {/* Profile Completion */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h2 className="text-xl font-semibold mb-4">Profile Completion</h2>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Completion Status</span>
                <span className="font-semibold">{calculateCompletion()}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className="bg-blue-500 h-3 rounded-full transition-all"
                  style={{ width: `${calculateCompletion()}%` }}
                />
              </div>
            </div>
          </div>

          {/* Save Button */}
          <div className="flex gap-3">
            <Button
              onClick={handleSaveProfile}
              disabled={saving}
              className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold flex items-center gap-2"
            >
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              {saving ? "Saving..." : "Save Changes"}
            </Button>
            <Button onClick={() => router.back()} variant="outline" className="px-6 py-3">
              Cancel
            </Button>
          </div>
        </div>
      </main>
    </div>
  )

  function calculateCompletion(): number {
    let completed = 0
    const total = 6

    if (formData.name) completed++
    if (formData.portfolio_url) completed++
    if (formData.expertise) completed++
    if (formData.interests) completed++
    if (skillsData.length > 0) completed++
    if (learningSource && (canProveSkill ? proofLink : true)) completed++

    return Math.round((completed / total) * 100)
  }
}
