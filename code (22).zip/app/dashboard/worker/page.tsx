"use client"

import { useEffect, useState } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import { AlertCircle, CheckCircle2, Clock, Eye, EyeOff, Edit2, Loader2 } from "lucide-react"
import ProfileCard from "@/components/dashboard/ProfileCard"
import SkillVerificationCard from "@/components/dashboard/SkillVerificationCard"
import Topbar from "@/components/dashboard/Topbar"
import Sidebar from "@/components/dashboard/Sidebar"

interface Profile {
  id: string
  name: string
  email: string
  avatar_url: string
  expertise: string
  interests: string
  experience: string
  verified_skills: string[]
  profile_public: boolean
  admin_review_status: string
  admin_feedback: string
  selected_job: string
  portfolio_url: string
  learning_source: string
  has_work_experience: boolean
  work_experience: string
  can_prove_skill: boolean
}

export default function WorkerDashboardPage() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const userId = searchParams.get("userId")

  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [isToggling, setIsToggling] = useState(false)

  useEffect(() => {
    const fetchData = async () => {
      try {
        if (!userId) {
          console.error("[v0] No userId provided")
          setLoading(false)
          return
        }

        const response = await fetch(`/api/dashboard/worker-data?userId=${userId}`)
        if (!response.ok) throw new Error("Failed to fetch")
        const result = await response.json()
        setData(result)
      } catch (error) {
        console.error("[v0] dashboard fetch error:", error)
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [userId])

  const handleToggleProfileVisibility = async () => {
    if (!userId) return

    setIsToggling(true)
    try {
      const response = await fetch("/api/dashboard/toggle-visibility", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId,
          isPublic: !data?.profile.profile_public,
        }),
      })

      if (!response.ok) throw new Error("Failed to toggle visibility")

      const updatedProfile = await response.json()
      setData((prev: any) => ({
        ...prev,
        profile: updatedProfile,
      }))
    } catch (error) {
      console.error("[v0] Error toggling visibility:", error)
    } finally {
      setIsToggling(false)
    }
  }

  if (loading) return <div className="min-h-screen bg-white">Loading...</div>
  if (!userId) return <div className="min-h-screen bg-white">Invalid session</div>
  if (!data) return <div className="min-h-screen bg-white">Failed to load profile</div>

  const { profile, skills } = data
  const isVerificationPending = profile?.admin_review_status === "pending"
  const isVerified = profile?.admin_review_status === "approved"
  const isRejected = profile?.admin_review_status === "rejected"

  return (
    <div className="min-h-screen bg-white text-[#1a1a2e]">
      <Sidebar />
      <Topbar name={profile?.name || "User"} />

      <main className="pt-24 pr-8 pb-12 bg-stone-100 pl-80">
        <div className="mb-6 flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-semibold text-[#1a1a2e]">Welcome, {profile?.name || "User"}</h1>
            <p className="text-sm text-gray-600 mt-1">Manage and verify your professional profile</p>
          </div>
          <button
            onClick={() => router.push(`/dashboard/worker/profile?userId=${userId}`)}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-lg transition flex items-center gap-2"
          >
            <Edit2 className="w-4 h-4" />
            Edit Complete Profile
          </button>
        </div>

        {isVerificationPending && (
          <div className="mb-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg flex items-start gap-3">
            <Clock className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-semibold text-yellow-900">Verification Pending</p>
              <p className="text-sm text-yellow-800">
                Your profile has been updated and is pending admin re-verification. Check back soon!
              </p>
            </div>
          </div>
        )}

        {isRejected && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-semibold text-red-900">Verification Rejected</p>
              {profile?.admin_feedback && (
                <p className="text-sm text-red-800 mt-1">
                  <span className="font-medium">Admin Feedback:</span> {profile.admin_feedback}
                </p>
              )}
              <button
                onClick={() => router.push(`/dashboard/worker/profile?userId=${userId}`)}
                className="text-sm text-red-600 hover:text-red-700 underline mt-2"
              >
                Update your profile to resubmit
              </button>
            </div>
          </div>
        )}

        {isVerified && (
          <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-semibold text-green-900">Profile Verified</p>
              <p className="text-sm text-green-800">Your profile has been verified and is visible in search results.</p>
              {profile?.admin_feedback && (
                <p className="text-sm text-green-800 mt-1">
                  <span className="font-medium">Admin Feedback:</span> {profile.admin_feedback}
                </p>
              )}
            </div>
          </div>
        )}

        <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg flex items-center justify-between">
          <div className="flex items-center gap-2">
            {profile?.profile_public ? (
              <>
                <Eye className="w-5 h-5 text-blue-600" />
                <div>
                  <p className="font-semibold text-blue-900">Profile Visibility: Public</p>
                  <p className="text-sm text-blue-800">Your profile is visible on the search page</p>
                </div>
              </>
            ) : (
              <>
                <EyeOff className="w-5 h-5 text-blue-600" />
                <div>
                  <p className="font-semibold text-blue-900">Profile Visibility: Hidden</p>
                  <p className="text-sm text-blue-800">Your profile is hidden from the search page</p>
                </div>
              </>
            )}
          </div>
          <button
            onClick={handleToggleProfileVisibility}
            disabled={isToggling}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition disabled:opacity-50 flex items-center gap-2"
          >
            {isToggling ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <>{profile?.profile_public ? "Hide Profile" : "Show Profile"}</>
            )}
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="space-y-6">
            <ProfileCard profile={profile} onEdit={() => router.push(`/dashboard/worker/profile?userId=${userId}`)} />
          </div>

          <div className="lg:col-span-2 space-y-6">
            {skills && skills.length > 0 && (
              <div className="bg-white rounded-lg border border-gray-200 p-6">
                <h3 className="text-lg font-semibold mb-4">Your Skills</h3>
                <div className="grid grid-cols-2 gap-3">
                  {skills.map((skill: any) => (
                    <div
                      key={skill.skill_name}
                      className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg border border-gray-200"
                    >
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900">{skill.skill_name}</p>
                        {skill.proof_link && (
                          <a
                            href={skill.proof_link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs text-blue-600 hover:underline"
                          >
                            View Proof
                          </a>
                        )}
                      </div>
                      {isVerified && skill.verified && (
                        <div className="px-2 py-1 bg-green-100 text-green-700 text-xs font-semibold rounded">
                          ✓ Verified
                        </div>
                      )}
                      {!isVerified && (
                        <div className="px-2 py-1 bg-yellow-100 text-yellow-700 text-xs font-semibold rounded">
                          Pending
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            <SkillVerificationCard skills={skills || []} />

            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <h3 className="text-lg font-semibold mb-4">Profile Information</h3>

              {profile?.expertise && (
                <div className="mb-4">
                  <p className="text-xs uppercase text-gray-600 mb-1">Expertise</p>
                  <p className="text-sm text-gray-900">{profile.expertise}</p>
                </div>
              )}

              {profile?.interests && (
                <div className="mb-4">
                  <p className="text-xs uppercase text-gray-600 mb-1">Interests</p>
                  <p className="text-sm text-gray-900">{profile.interests}</p>
                </div>
              )}

              {profile?.portfolio_url && (
                <div className="mb-4">
                  <p className="text-xs uppercase text-gray-600 mb-1">Portfolio</p>
                  <a
                    href={profile.portfolio_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm text-blue-600 hover:underline"
                  >
                    {profile.portfolio_url}
                  </a>
                </div>
              )}

              {profile?.selected_job && (
                <div>
                  <p className="text-xs uppercase text-gray-600 mb-1">Target Jobs</p>
                  <p className="text-sm text-gray-900">{profile.selected_job}</p>
                </div>
              )}
            </div>

            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <h3 className="text-lg font-semibold mb-4">Experience & Proof</h3>

              {profile?.learning_source && (
                <div className="mb-4">
                  <p className="text-xs uppercase text-gray-600 mb-1">Learning Source</p>
                  <p className="text-sm text-gray-900">{profile.learning_source}</p>
                </div>
              )}

              {profile?.has_work_experience !== undefined && (
                <div className="mb-4">
                  <p className="text-xs uppercase text-gray-600 mb-1">Work Experience</p>
                  <p className="text-sm text-gray-900">{profile.has_work_experience ? "Yes" : "No"}</p>
                </div>
              )}

              {profile?.work_experience && (
                <div className="mb-4">
                  <p className="text-xs uppercase text-gray-600 mb-1">Previous Experience Details</p>
                  <p className="text-sm text-gray-900">{profile.work_experience}</p>
                </div>
              )}

              {profile?.can_prove_skill !== undefined && (
                <div>
                  <p className="text-xs uppercase text-gray-600 mb-1">Can Prove Skills</p>
                  <p className="text-sm text-gray-900">{profile.can_prove_skill ? "Yes" : "No"}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
