import type React from "react"

export default function WorkerDashboardLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
