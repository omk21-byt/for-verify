"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Upload, Trash2, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"

interface GalleryItem {
  id: string
  title: string
  description?: string
  media_url: string
  media_type: string
  is_featured: boolean
}

export default function PortfolioGalleryPage() {
  const router = useRouter()
  const [galleryItems, setGalleryItems] = useState<GalleryItem[]>([])
  const [loading, setLoading] = useState(true)
  const [userId, setUserId] = useState<string>("")
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    media_url: "",
    media_type: "image",
  })

  useEffect(() => {
    const fetchSession = async () => {
      try {
        const res = await fetch("/api/auth/session")
        const data = await res.json()
        setUserId(data.user?.id || "")
      } catch (error) {
        console.error("Failed to fetch session:", error)
        router.push("/login")
      }
    }
    fetchSession()
  }, [router])

  useEffect(() => {
    if (!userId) return

    const fetchGallery = async () => {
      try {
        const res = await fetch(`/api/portfolio-gallery?userId=${userId}`)
        const data = await res.json()
        setGalleryItems(data)
      } catch (error) {
        console.error("Failed to fetch gallery:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchGallery()
  }, [userId])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.title || !formData.media_url) {
      alert("Please fill in title and media URL")
      return
    }

    try {
      const res = await fetch("/api/portfolio-gallery", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          user_id: userId,
          ...formData,
        }),
      })
      const newItem = await res.json()
      setGalleryItems([...galleryItems, newItem])
      setFormData({ title: "", description: "", media_url: "", media_type: "image" })
    } catch (error) {
      console.error("Failed to add gallery item:", error)
    }
  }

  const handleDelete = async (itemId: string) => {
    if (!confirm("Delete this item?")) return

    try {
      await fetch(`/api/portfolio-gallery/${itemId}`, { method: "DELETE" })
      setGalleryItems((prev) => prev.filter((item) => item.id !== itemId))
    } catch (error) {
      console.error("Failed to delete gallery item:", error)
    }
  }

  const handleToggleFeatured = async (itemId: string, currentFeatured: boolean) => {
    try {
      await fetch(`/api/portfolio-gallery/${itemId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ is_featured: !currentFeatured }),
      })
      setGalleryItems((prev) =>
        prev.map((item) => (item.id === itemId ? { ...item, is_featured: !currentFeatured } : item)),
      )
    } catch (error) {
      console.error("Failed to toggle featured:", error)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p>Loading portfolio gallery...</p>
      </div>
    )
  }

  return (
    <main className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Portfolio Gallery</h1>

        <Card className="p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">Add New Item</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Title</label>
              <Input
                type="text"
                placeholder="Project title"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Description</label>
              <Input
                type="text"
                placeholder="Brief description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Media URL</label>
              <Input
                type="url"
                placeholder="https://example.com/image.jpg"
                value={formData.media_url}
                onChange={(e) => setFormData({ ...formData, media_url: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Media Type</label>
              <select
                className="w-full border rounded px-3 py-2"
                value={formData.media_type}
                onChange={(e) => setFormData({ ...formData, media_type: e.target.value })}
              >
                <option value="image">Image</option>
                <option value="video">Video</option>
                <option value="document">Document</option>
              </select>
            </div>
            <Button type="submit" className="w-full">
              <Upload className="w-4 h-4 mr-2" />
              Add to Gallery
            </Button>
          </form>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {galleryItems.length === 0 ? (
            <p className="text-gray-500 col-span-full text-center py-8">No gallery items yet</p>
          ) : (
            galleryItems.map((item) => (
              <Card key={item.id} className="overflow-hidden">
                <div className="aspect-video bg-gray-100 relative">
                  {item.media_type === "image" && (
                    <img
                      src={item.media_url || "/placeholder.svg"}
                      alt={item.title}
                      className="w-full h-full object-cover"
                    />
                  )}
                  {item.is_featured && (
                    <div className="absolute top-2 right-2 bg-yellow-500 text-white p-2 rounded">
                      <Star className="w-4 h-4" />
                    </div>
                  )}
                </div>
                <div className="p-4">
                  <h3 className="font-semibold text-gray-900">{item.title}</h3>
                  {item.description && <p className="text-sm text-gray-600 mt-1">{item.description}</p>}
                  <div className="flex gap-2 mt-4">
                    <Button
                      size="sm"
                      variant={item.is_featured ? "default" : "outline"}
                      onClick={() => handleToggleFeatured(item.id, item.is_featured)}
                    >
                      <Star className="w-4 h-4" />
                    </Button>
                    <Button size="sm" variant="destructive" onClick={() => handleDelete(item.id)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>
      </div>
    </main>
  )
}
