"use client"

import { useEffect, useState } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import { Loader2, Save, AlertCircle, CheckCircle2 } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { SkillCategorySelector } from "@/components/Signup/skill-category-selector"
import { ExperienceSourceSelector } from "@/components/Signup/experience-source-selector"
import { SkillProofSelector } from "@/components/Signup/skill-proof-selector"
import { JobProfileSelector } from "@/components/Signup/job-profile-selector"
import { getJobsForSkills } from "@/components/Signup/skill-category-selector"

interface ProfileData {
  id: string
  name: string
  email: string
  avatar_url: string
  selected_job: string
  expertise: string
  interests: string
  experience: string
  portfolio_url: string
  profile_tags: Record<string, string>
  verified_skills: string[]
  admin_feedback: string
  admin_review_status: string
}

export default function ProfileEditorPage() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const userId = searchParams.get("userId")

  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null)

  // Profile Form State
  const [profile, setProfile] = useState<ProfileData | null>(null)
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [expertise, setExpertise] = useState("")
  const [interests, setInterests] = useState("")
  const [experience, setExperience] = useState("")
  const [portfolioUrl, setPortfolioUrl] = useState("")

  // Skill Selector State
  const [selectedSkills, setSelectedSkills] = useState<string[]>([])
  const [suggestedJobs, setSuggestedJobs] = useState<string[]>([])
  const [selectedJobs, setSelectedJobs] = useState<string[]>([])

  // Experience Source State
  const [learningSource, setLearningSource] = useState("self-taught")
  const [hasWorkExperience, setHasWorkExperience] = useState(false)
  const [previousExperience, setPreviousExperience] = useState("")

  // Skill Proof State
  const [canProveSkill, setCanProveSkill] = useState(false)
  const [proofLink, setProofLink] = useState("")
  const [proofDescription, setProofDescription] = useState("")

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        if (!userId) {
          setLoading(false)
          return
        }

        const response = await fetch(`/api/dashboard/profile?userId=${userId}`)
        if (!response.ok) throw new Error("Failed to fetch profile")

        const data = await response.json()
        setProfile(data)

        // Populate form fields
        setName(data.name || "")
        setEmail(data.email || "")
        setExpertise(data.expertise || "")
        setInterests(data.interests || "")
        setExperience(data.experience || "")
        setPortfolioUrl(data.portfolio_url || "")
        setSelectedSkills(data.verified_skills || [])
        setSelectedJobs([data.selected_job].filter(Boolean))

        // Update suggested jobs based on skills
        const jobs = getJobsForSkills(data.verified_skills || [])
        setSuggestedJobs(jobs)
      } catch (error) {
        console.error("[v0] Error fetching profile:", error)
        setMessage({ type: "error", text: "Failed to load profile" })
      } finally {
        setLoading(false)
      }
    }

    fetchProfile()
  }, [userId])

  useEffect(() => {
    // Update suggested jobs when skills change
    const jobs = getJobsForSkills(selectedSkills)
    setSuggestedJobs(jobs)
  }, [selectedSkills])

  const handleSaveProfile = async () => {
    if (!userId) return

    setSaving(true)
    try {
      const response = await fetch("/api/dashboard/profile/update", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId,
          name,
          email,
          expertise,
          interests,
          experience,
          portfolio_url: portfolioUrl,
          verified_skills: selectedSkills,
          selected_job: selectedJobs[0] || "",
          profile_tags: {
            learningSource,
            hasWorkExperience: String(hasWorkExperience),
            canProveSkill: String(canProveSkill),
          },
        }),
      })

      if (!response.ok) throw new Error("Failed to save profile")

      setMessage({
        type: "success",
        text: "Profile updated successfully! Pending admin re-verification.",
      })

      setTimeout(() => {
        router.push(`/dashboard/worker?userId=${userId}`)
      }, 2000)
    } catch (error) {
      console.error("[v0] Error saving profile:", error)
      setMessage({ type: "error", text: "Failed to save profile. Please try again." })
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
      </div>
    )
  }

  if (!userId) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="bg-white p-6 rounded-lg shadow text-center">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <p className="text-gray-900">Invalid session</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="mx-auto max-w-4xl">
        {/* Header */}
        <div className="mb-8">
          <button onClick={() => router.back()} className="text-sm text-indigo-600 hover:underline mb-4">
            ← Back
          </button>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Edit Your Profile</h1>
          <p className="text-gray-600">Update your profile information. Changes will require admin re-verification.</p>
        </div>

        {/* Message Alert */}
        {message && (
          <div
            className={`mb-6 p-4 rounded-lg flex items-center gap-2 ${
              message.type === "success"
                ? "bg-green-50 text-green-800 border border-green-200"
                : "bg-red-50 text-red-800 border border-red-200"
            }`}
          >
            {message.type === "success" ? <CheckCircle2 className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
            {message.text}
          </div>
        )}

        {/* Form */}
        <div className="bg-white rounded-lg shadow-sm p-6 space-y-8">
          {/* Basic Information */}
          <div>
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Basic Information</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                <Input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Your name"
                  className="w-full"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <Input
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Your email"
                  type="email"
                  className="w-full"
                  disabled
                />
                <p className="text-xs text-gray-500 mt-1">Email cannot be changed</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Portfolio URL</label>
                <Input
                  value={portfolioUrl}
                  onChange={(e) => setPortfolioUrl(e.target.value)}
                  placeholder="https://yourportfolio.com"
                  type="url"
                  className="w-full"
                />
              </div>
            </div>
          </div>

          {/* Professional Background */}
          <div>
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Professional Background</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Expertise</label>
                <Textarea
                  value={expertise}
                  onChange={(e) => setExpertise(e.target.value)}
                  placeholder="Describe your main areas of expertise..."
                  className="w-full min-h-24"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Experience</label>
                <Textarea
                  value={experience}
                  onChange={(e) => setExperience(e.target.value)}
                  placeholder="Describe your professional experience..."
                  className="w-full min-h-24"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Interests</label>
                <Input
                  value={interests}
                  onChange={(e) => setInterests(e.target.value)}
                  placeholder="E.g., React, Web Design, Startup Environment"
                  className="w-full"
                />
              </div>
            </div>
          </div>

          {/* Skills Section */}
          <div>
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Skills</h2>
            <SkillCategorySelector selectedSkills={selectedSkills} onSkillsChange={setSelectedSkills} />
          </div>

          {/* Experience Source Section */}
          <div>
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Experience & Learning</h2>
            <ExperienceSourceSelector
              learningSource={learningSource}
              hasWorkExperience={hasWorkExperience}
              previousExperience={previousExperience}
              onLearningSourceChange={setLearningSource}
              onWorkExperienceChange={setHasWorkExperience}
              onPreviousExperienceChange={setPreviousExperience}
            />
          </div>

          {/* Skill Proof Section */}
          <div>
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Proof of Skills</h2>
            <SkillProofSelector
              canProveSkill={canProveSkill}
              proofLink={proofLink}
              proofDescription={proofDescription}
              onCanProveChange={setCanProveSkill}
              onProofLinkChange={setProofLink}
              onProofDescriptionChange={setProofDescription}
            />
          </div>

          {/* Suggested Jobs */}
          <div>
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Job Profiles</h2>
            <JobProfileSelector
              availableJobs={suggestedJobs}
              selectedJobs={selectedJobs}
              onJobsChange={setSelectedJobs}
            />
          </div>

          {/* Admin Feedback (Read-only) */}
          {profile?.admin_feedback && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-sm font-semibold text-blue-900 mb-2">Admin Feedback</p>
              <p className="text-sm text-blue-800">{profile.admin_feedback}</p>
            </div>
          )}

          {/* Save Button */}
          <div className="flex gap-4 pt-4 border-t">
            <button
              onClick={handleSaveProfile}
              disabled={saving}
              className="flex-1 px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-lg transition disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {saving ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  Save Changes
                </>
              )}
            </button>
            <button
              onClick={() => router.back()}
              className="flex-1 px-6 py-3 bg-gray-200 hover:bg-gray-300 text-gray-900 font-medium rounded-lg transition"
            >
              Cancel
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
