"use client"

import { useState } from "react"
import DashboardLayout from "@/components/dashboard/layout-wrapper"
import { Trash2, CheckCircle2 } from 'lucide-react'

interface Notification {
  id: string
  title: string
  message: string
  timestamp: Date
  read: boolean
  type: "success" | "info" | "warning"
}

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: "1",
      title: "Profile Updated",
      message: "Your profile has been successfully updated",
      timestamp: new Date(Date.now() - 1000 * 60 * 5),
      read: false,
      type: "success",
    },
    {
      id: "2",
      title: "Welcome!",
      message: "Welcome to your dashboard. Start by updating your profile.",
      timestamp: new Date(Date.now() - 1000 * 60 * 60),
      read: false,
      type: "info",
    },
    {
      id: "3",
      title: "New Opportunity",
      message: "A new job opportunity matches your skills",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24),
      read: true,
      type: "info",
    },
  ])

  const handleMarkAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((notif) => (notif.id === id ? { ...notif, read: true } : notif))
    )
  }

  const handleDelete = (id: string) => {
    setNotifications((prev) => prev.filter((notif) => notif.id !== id))
  }

  const formatTime = (date: Date) => {
    const now = new Date()
    const seconds = Math.floor((now.getTime() - date.getTime()) / 1000)

    if (seconds < 60) return "Just now"
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`
    return `${Math.floor(seconds / 86400)}d ago`
  }

  return (
    <DashboardLayout
      title="Notifications"
      description="Stay updated with your latest notifications"
    >
      <div className="max-w-2xl space-y-4">
        {notifications.length === 0 ? (
          <div className="bg-white rounded-lg border border-gray-200 p-12 text-center">
            <p className="text-gray-600">No notifications yet</p>
          </div>
        ) : (
          notifications.map((notif) => (
            <div
              key={notif.id}
              className={`rounded-lg border p-4 flex gap-4 transition ${
                notif.read
                  ? "bg-gray-50 border-gray-200"
                  : "bg-blue-50 border-blue-200"
              }`}
            >
              <div className={`w-3 h-3 rounded-full mt-2 flex-shrink-0 ${
                notif.type === "success" ? "bg-green-500" :
                notif.type === "warning" ? "bg-yellow-500" :
                "bg-blue-500"
              }`} />
              
              <div className="flex-1">
                <h3 className="font-semibold text-gray-900">{notif.title}</h3>
                <p className="text-sm text-gray-600 mt-1">{notif.message}</p>
                <p className="text-xs text-gray-500 mt-2">{formatTime(notif.timestamp)}</p>
              </div>

              <div className="flex gap-2 flex-shrink-0">
                {!notif.read && (
                  <button
                    onClick={() => handleMarkAsRead(notif.id)}
                    className="p-2 hover:bg-white rounded-lg transition text-gray-400 hover:text-green-600"
                  >
                    <CheckCircle2 className="w-5 h-5" />
                  </button>
                )}
                <button
                  onClick={() => handleDelete(notif.id)}
                  className="p-2 hover:bg-white rounded-lg transition text-gray-400 hover:text-red-600"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </DashboardLayout>
  )
}
