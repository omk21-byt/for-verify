"use client"

import React, { useEffect, useRef, useState, useMemo } from "react"
import { useRouter, useSearchParams } from 'next/navigation'
import { CheckCircle2, Search, Star, Mail, Loader2, Shield, Tag, MessageSquare, ChevronDown } from 'lucide-react'

interface PublicProfile {
  id: string
  name: string
  email: string
  expertise: string
  interests: string
  avatar_url: string
  star_rating: number
  skill_score: number
  verification_status: string
  is_admin?: boolean
  admin_feedback?: string
  profile_tags?: Record<string, string>
  admin_review_status?: string
  selected_job?: string
  experience?: string
  verified_skills?: string[]
}

export default function SearchPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [profiles, setProfiles] = useState<PublicProfile[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState(searchParams.get("q") || "")
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null)
  const [expandedProfileId, setExpandedProfileId] = useState<string | null>(null)

  const ProfileCard = React.memo(function ProfileCard({ 
    profile, 
    isExpanded, 
    onToggle 
  }: { 
    profile: PublicProfile
    isExpanded: boolean
    onToggle: () => void
  }) {
    const instanceIdRef = useRef<string | null>(null)
    if (instanceIdRef.current === null) {
      instanceIdRef.current = `${profile.id ?? "profile"}_${Math.random().toString(36).slice(2, 9)}`
    }
    const instanceId = instanceIdRef.current

    const handleToggle = (e: React.MouseEvent) => {
      e.stopPropagation()
      onToggle()
    }

    useEffect(() => {
      // console.debug(`[ProfileCard] mounted`, instanceId, profile.id)
      return () => {
        // console.debug(`[ProfileCard] unmount`, instanceId, profile.id)
      }
    }, [instanceId, profile.id])

    return (
      <div
        data-instance-id={profile.id}
        aria-expanded={isExpanded}
        className="border rounded-xl shadow-sm transition-all bg-white overflow-hidden hover:shadow-lg flex flex-col"
      >
        <div className="p-4 border-b bg-gradient-to-r from-gray-50 to-white pb-0">
          {profile.admin_review_status === "approved" && (
            <div className="mb-2 flex items-center gap-1 w-fit px-2 py-1 rounded-md h-[22px] border-dashed border-lime-600 border-0 bg-stone-200">
              <Shield className="w-4 h-4" />
              <span className="text-xs font-semibold text-purple-600">AI Verified</span>
            </div>
          )}

          <div className="flex items-center gap-3 mb-3">
            <img
              src={profile.avatar_url || "/placeholder.svg?height=50&width=50"}
              alt={profile.name}
              className="rounded-full w-12 h-12 object-cover bg-gray-200"
            />
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-gray-800 flex items-center gap-1 truncate">
                {profile.name}
                {profile.verification_status === "verified" && (
                  <CheckCircle2 className="text-blue-500 h-4 w-4 flex-shrink-0" />
                )}
              </h3>
              {profile.selected_job && (
                <p className="text-xs text-indigo-600 font-semibold truncate">{profile.selected_job}</p>
              )}
            </div>
          </div>

          {profile.star_rating > 0 && (
            <div className="flex items-center gap-1 mb-2">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-3.5 h-3.5 ${
                    i < Math.round(profile.star_rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                  }`}
                />
              ))}
              <span className="text-xs font-semibold text-gray-700">{profile.star_rating}/5</span>
            </div>
          )}

          {profile.admin_review_status && (
            <div className="mb-2">
              <span
                className={`inline-flex items-center px-2 rounded-full text-xs font-medium py-0.5 ${
                  profile.admin_review_status === "approved"
                    ? "bg-green-100 text-green-700"
                    : profile.admin_review_status === "pending"
                    ? "bg-yellow-100 text-yellow-700"
                    : "bg-red-100 text-red-700"
                }`}
              >
                {profile.admin_review_status.charAt(0).toUpperCase() + profile.admin_review_status.slice(1)}
              </span>
            </div>
          )}
        </div>

        <button
          type="button"
          onClick={handleToggle}
          className="w-full py-3 px-4 text-indigo-600 hover:text-indigo-700 font-semibold text-sm hover:bg-gray-50 transition flex items-center justify-center gap-2 pb-2.5 pt-2.5 bg-white"
        >
          {isExpanded ? "Show Less" : "Show More Details"}
          <ChevronDown className={`w-4 h-4 transition-transform ${isExpanded ? "rotate-180" : ""}`} />
        </button>

        {isExpanded && (
          <div className="p-4 space-y-4 border-t bg-gray-50">
            {(profile.profile_tags || profile.selected_job) && (
              <div>
                <p className="mb-2 flex items-center gap-1 text-xs text-gray-600 uppercase font-semibold">
                  <Tag className="w-3 h-3" />
                  Tags
                </p>
                <div className="flex flex-wrap gap-2">
                  {profile.selected_job && (
                    <span className="text-xs bg-blue-100 px-2 text-blue-700 font-medium rounded-md py-0.5">
                      {profile.selected_job}
                    </span>
                  )}
                  {profile.profile_tags &&
                    Object.entries(profile.profile_tags).map(([key, value]) => (
                      <span
                        key={key}
                        className="text-xs bg-indigo-100 px-2 py-1 rounded-full text-indigo-700 font-medium"
                      >
                        {String(value)}
                      </span>
                    ))}
                </div>
              </div>
            )}

            {profile.expertise && (
              <div>
                <p className="text-xs font-semibold text-gray-600 uppercase mb-1">Expertise</p>
                <p className="text-sm text-gray-700">{profile.expertise}</p>
              </div>
            )}

            {profile.interests && (
              <div>
                <p className="text-xs font-semibold text-gray-600 uppercase mb-2">Interests</p>
                <div className="flex flex-wrap gap-2">
                  {profile.interests
                    .split(",")
                    .slice(0, 4)
                    .map((interest, i) => (
                      <span key={i} className="text-xs bg-gray-100 px-2 py-1 rounded-full text-gray-700">
                        {interest.trim()}
                      </span>
                    ))}
                </div>
              </div>
            )}

            {profile.admin_feedback && (
              <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                <p className="text-xs text-green-600 font-semibold uppercase mb-1 flex items-center gap-1">
                  <MessageSquare className="w-3 h-3" />
                  Admin Feedback
                </p>
                <p className="text-sm text-green-900">{profile.admin_feedback}</p>
              </div>
            )}

            {profile.skill_score > 0 && (
              <div className="p-2 bg-blue-50 rounded-lg border border-blue-200">
                <p className="text-xs text-blue-600 font-semibold">
                  Skill Score: <span className="text-sm text-blue-900 font-bold">{profile.skill_score}</span>
                </p>
              </div>
            )}

            {profile.verified_skills && profile.verified_skills.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-gray-600 uppercase mb-2">Verified Skills</p>
                <div className="flex flex-wrap gap-2">
                  {profile.verified_skills.map((skill) => (
                    <span
                      key={skill}
                      className="text-xs bg-green-100 px-2 py-1 rounded-full text-green-700 font-medium"
                    >
                      ✓ {skill}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {profile.experience && (
              <div>
                <p className="text-xs font-semibold text-gray-600 uppercase mb-1">Experience</p>
                <p className="text-sm text-gray-700">{profile.experience}</p>
              </div>
            )}

            <div className="pt-2 border-t">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation()
                  window.location.href = `mailto:${profile.email}`
                }}
                className="w-full text-white py-2 px-3 rounded-lg hover:bg-gray-900 transition flex items-center justify-center gap-2 bg-black text-sm font-medium"
              >
                <Mail className="w-4 h-4" />
                Contact {profile.name.split(" ")[0]}
              </button>
            </div>
          </div>
        )}
      </div>
    )
  })

  const MemoProfileCard = useMemo(() => ProfileCard, [])

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const sessionRes = await fetch("/api/auth/session")
        const sessionData = await sessionRes.json()

        if (!sessionData.user) {
          router.push("/login")
          return
        }

        setIsAuthenticated(true)
      } catch (error) {
        console.error("[v0] Auth check error:", error)
        router.push("/login")
      }
    }

    checkAuth()
  }, [router])

  useEffect(() => {
    if (!isAuthenticated) return

    const debounceTimer = setTimeout(() => {
      fetchProfiles(searchQuery, 1)
    }, 300)

    return () => clearTimeout(debounceTimer)
  }, [searchQuery, isAuthenticated])

  const fetchProfiles = async (search = "", page = 1) => {
    setLoading(true)
    setExpandedProfileId(null)
    try {
      const params = new URLSearchParams()
      if (search) params.append("search", search)
      params.append("page", page.toString())

      const response = await fetch(`/api/profiles/public?${params}`)
      if (!response.ok) throw new Error("Failed to fetch profiles")

      const data = await response.json()
      setProfiles(data.profiles)
      setTotalPages(data.totalPages)
      setCurrentPage(page)
    } catch (error) {
      console.error("[v0] Error fetching profiles:", error)
    } finally {
      setLoading(false)
    }
  }

  if (isAuthenticated === null) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    )
  }

  return (
    <main className="min-h-dvh bg-white font-sans">
      <div className="mx-auto max-w-7xl px-4 py-6 md:py-10 md:pt-0">
        <div className="flex justify-between items-center mb-8 mt-9">
          <h1 className="text-3xl font-bold flex items-center gap-2">Explore Verified Professionals</h1>
          <button onClick={() => router.push("/")} className="text-sm text-indigo-600 hover:underline">
            ← Back to home
          </button>
        </div>

        <div className="relative mb-8">
          <div className="flex items-center gap-2 rounded-lg border border-gray-200 px-2 bg-white">
            <Search className="text-gray-400 ml-2 h-6 w-6" />
            <input
              type="text"
              placeholder="Search by name, skills, or interests..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full md:w-1/2 p-3 focus:outline-none h-11 bg-transparent"
            />
          </div>
          <p className="text-xs text-gray-400 mt-2">
            Powered by <span className="text-indigo-500 font-medium">Shiftza Smart Match</span>
          </p>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <p className="text-gray-600">Loading profiles...</p>
          </div>
        ) : profiles.length === 0 ? (
          <div className="flex items-center justify-center py-12">
            <p className="text-gray-600">
              {searchQuery ? "No profiles found matching your search." : "No public profiles available yet."}
            </p>
          </div>
        ) : (
          <>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {profiles.map((profile) => (
                <MemoProfileCard 
                  key={`${profile.id}-${currentPage}`}
                  profile={profile}
                  isExpanded={expandedProfileId === profile.id}
                  onToggle={() => {
                    console.log("[v0] Toggle clicked for:", profile.id, "Current expanded:", expandedProfileId)
                    setExpandedProfileId(expandedProfileId === profile.id ? null : profile.id)
                  }}
                />
              ))}
            </div>

            {totalPages > 1 && (
              <div className="flex justify-center gap-2 mt-8">
                <button
                  onClick={() => fetchProfiles(searchQuery, currentPage - 1)}
                  disabled={currentPage === 1}
                  className="px-3 py-2 border rounded-md disabled:opacity-50 hover:bg-gray-50"
                >
                  Previous
                </button>
                <div className="flex items-center gap-2">
                  {[...Array(Math.min(totalPages, 5))].map((_, i) => {
                    const page = i + 1
                    return (
                      <button
                        key={page}
                        onClick={() => fetchProfiles(searchQuery, page)}
                        className={`px-3 py-2 rounded-md ${
                          currentPage === page ? "bg-indigo-600 text-white" : "border hover:bg-gray-50"
                        }`}
                      >
                        {page}
                      </button>
                    )
                  })}
                </div>
                <button
                  onClick={() => fetchProfiles(searchQuery, currentPage + 1)}
                  disabled={currentPage === totalPages}
                  className="px-3 py-2 border rounded-md disabled:opacity-50 hover:bg-gray-50"
                >
                  Next
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </main>
  )
}
