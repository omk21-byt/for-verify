"use client"

import { useEffect, useState } from "react"
import { useRouter } from 'next/navigation'
import { Bookmark, Loader2, Star, Trash2 } from 'lucide-react'
import DashboardLayout from "@/components/dashboard/layout-wrapper"

interface BookmarkedUser {
  id: string
  bookmarked_user_id: string
  created_at: string
  users: {
    id: string
    name: string
    avatar_url: string
    email: string
    expertise: string
    star_rating: number
  }
}

export default function BookmarksPage() {
  const router = useRouter()
  const [bookmarks, setBookmarks] = useState<BookmarkedUser[]>([])
  const [loading, setLoading] = useState(true)
  const [deleting, setDeleting] = useState<string | null>(null)

  useEffect(() => {
    const fetchBookmarks = async () => {
      try {
        const response = await fetch("/api/bookmarks")
        if (!response.ok) throw new Error("Failed to fetch bookmarks")
        const data = await response.json()
        setBookmarks(data.bookmarks || [])
      } catch (error) {
        console.error("[v0] Error fetching bookmarks:", error)
      } finally {
        setLoading(false)
      }
    }
    fetchBookmarks()
  }, [])

  const handleRemoveBookmark = async (bookmarkId: string) => {
    setDeleting(bookmarkId)
    try {
      const response = await fetch(`/api/bookmarks/${bookmarkId}`, {
        method: "DELETE",
      })
      if (!response.ok) throw new Error("Failed to delete bookmark")
      setBookmarks((prev) => prev.filter((b) => b.id !== bookmarkId))
    } catch (error) {
      console.error("[v0] Error deleting bookmark:", error)
    } finally {
      setDeleting(null)
    }
  }

  const handleAddBookmark = async (userId: string, userName: string) => {
    try {
      const response = await fetch("/api/bookmarks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ bookmarkedUserId: userId }),
      })
      if (!response.ok) throw new Error("Failed to add bookmark")
      
      // Create notification for the bookmarked user
      await fetch("/api/notifications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          user_id: userId,
          type: "bookmark",
          title: "You were bookmarked",
          description: `${userName} saved your profile to their bookmarks`,
          related_user_id: userId,
          related_item_id: userId,
        }),
      })

      // Refresh bookmarks
      const refreshResponse = await fetch("/api/bookmarks")
      const refreshData = await refreshResponse.json()
      setBookmarks(refreshData.bookmarks || [])
    } catch (error) {
      console.error("[v0] Error adding bookmark:", error)
    }
  }

  if (loading) {
    return (
      <DashboardLayout title="Bookmarks" description="Your saved professionals">
        <div className="flex items-center justify-center h-96">
          <p className="text-gray-600">Loading bookmarks...</p>
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout title="Bookmarks" description="Your saved professionals">
      {bookmarks.length === 0 ? (
        <div className="bg-white rounded-xl border border-gray-200 p-12 text-center shadow-sm my-10">
          <Bookmark className="w-12 h-12 mx-auto mb-3 text-gray-400" />
          <p className="text-gray-900 font-medium">No bookmarks yet</p>
          <p className="text-sm text-gray-600 mt-1">Save workers to revisit their profiles later</p>
          <button
            onClick={() => router.push("/search")}
            className="mt-6 px-6 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition font-medium"
          >
            Browse Professionals
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {bookmarks.map((bookmark) => (
            <div
              key={bookmark.id}
              className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-md transition shadow-sm"
            >
              <div className="flex items-start justify-between mb-4">
                <img
                  src={bookmark.users.avatar_url || "/placeholder.svg?height=48&width=48"}
                  alt={bookmark.users.name}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <button
                  onClick={() => handleRemoveBookmark(bookmark.id)}
                  disabled={deleting === bookmark.id}
                  className="p-2 hover:bg-gray-100 rounded-lg transition disabled:opacity-50"
                >
                  {deleting === bookmark.id ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Trash2 className="w-4 h-4 text-gray-500 hover:text-red-600" />
                  )}
                </button>
              </div>

              <h3 className="text-lg font-semibold text-gray-900 mb-1">{bookmark.users.name}</h3>
              <p className="text-sm text-gray-600 mb-3">{bookmark.users.email}</p>

              {bookmark.users.expertise && (
                <p className="text-sm text-gray-700 mb-3 line-clamp-2">{bookmark.users.expertise}</p>
              )}

              <div className="flex items-center gap-1 mb-4">
                <div className="flex">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${
                        i < (bookmark.users.star_rating || 0) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                      }`}
                    />
                  ))}
                </div>
                <span className="text-sm text-gray-600">({bookmark.users.star_rating || 0})</span>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => router.push(`/search?workerId=${bookmark.users.id}`)}
                  className="flex-1 px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded-lg transition"
                >
                  View Profile
                </button>
                <button
                  onClick={() => router.push(`/messages?userId=${bookmark.users.id}`)}
                  className="flex-1 px-3 py-2 border border-indigo-600 text-indigo-600 hover:bg-indigo-50 text-sm font-medium rounded-lg transition"
                >
                  Message
                </button>
              </div>

              <p className="text-xs text-gray-500 mt-3">Saved {new Date(bookmark.created_at).toLocaleDateString()}</p>
            </div>
          ))}
        </div>
      )}
    </DashboardLayout>
  )
}
