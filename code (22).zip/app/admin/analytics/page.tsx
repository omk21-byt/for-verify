"use client"

import { useEffect, useState } from "react"
import { TrendingUp, Users, CheckCircle2, Clock, XCircle, Star } from "lucide-react"
import Sidebar from "@/components/dashboard/Sidebar"
import Topbar from "@/components/dashboard/Topbar"

interface Analytics {
  stats: {
    totalUsers: number
    verifiedProfiles: number
    pendingProfiles: number
    rejectedProfiles: number
    verifiedSkills: number
    avgCompletionScore: number
  }
  topWorkers: Array<{
    id: string
    name: string
    email: string
    star_rating: number
  }>
  recentSignups: Array<{
    id: string
    name: string
    email: string
    created_at: string
  }>
}

export default function AdminAnalyticsPage() {
  const [analytics, setAnalytics] = useState<Analytics | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        const response = await fetch("/api/admin/analytics")
        if (!response.ok) throw new Error("Failed to fetch analytics")
        const data = await response.json()
        setAnalytics(data)
      } catch (error) {
        console.error("[v0] Error fetching analytics:", error)
      } finally {
        setLoading(false)
      }
    }
    fetchAnalytics()
  }, [])

  if (loading) return <div className="min-h-screen bg-stone-100">Loading...</div>
  if (!analytics) return <div className="min-h-screen bg-stone-100">Failed to load analytics</div>

  const stats = [
    {
      title: "Total Users",
      value: analytics.stats.totalUsers,
      icon: Users,
      bg: "bg-blue-50",
      color: "text-blue-600",
    },
    {
      title: "Verified Profiles",
      value: analytics.stats.verifiedProfiles,
      icon: CheckCircle2,
      bg: "bg-green-50",
      color: "text-green-600",
    },
    {
      title: "Pending Verification",
      value: analytics.stats.pendingProfiles,
      icon: Clock,
      bg: "bg-yellow-50",
      color: "text-yellow-600",
    },
    {
      title: "Rejected",
      value: analytics.stats.rejectedProfiles,
      icon: XCircle,
      bg: "bg-red-50",
      color: "text-red-600",
    },
    {
      title: "Skills Verified",
      value: analytics.stats.verifiedSkills,
      icon: TrendingUp,
      bg: "bg-purple-50",
      color: "text-purple-600",
    },
  ]

  return (
    <div className="min-h-screen bg-stone-100 text-[#1a1a2e]">
      <Sidebar />
      <Topbar name="Admin Analytics" />

      <main className="pt-24 pr-8 pb-12 pl-80">
        <div className="mb-8">
          <h1 className="text-4xl font-semibold">Analytics Dashboard</h1>
          <p className="text-sm text-gray-600 mt-1">Platform overview and statistics</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          {stats.map((stat, idx) => {
            const Icon = stat.icon
            return (
              <div key={idx} className={`${stat.bg} rounded-lg p-6 border border-gray-200`}>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-semibold text-gray-700">{stat.title}</h3>
                  <Icon className={`w-5 h-5 ${stat.color}`} />
                </div>
                <p className={`text-3xl font-bold ${stat.color}`}>{stat.value}</p>
              </div>
            )
          })}
        </div>

        {/* Avg Completion Score */}
        <div className="bg-white rounded-lg border border-gray-200 p-6 mb-8">
          <h2 className="text-lg font-semibold mb-4">Average Profile Completion</h2>
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className="bg-indigo-600 h-3 rounded-full transition-all"
                  style={{ width: `${analytics.stats.avgCompletionScore}%` }}
                ></div>
              </div>
            </div>
            <p className="text-2xl font-bold text-indigo-600 min-w-fit">
              {analytics.stats.avgCompletionScore.toFixed(1)}%
            </p>
          </div>
          <p className="text-xs text-gray-600 mt-3">
            Based on profile fields filled (name, email, expertise, interests, portfolio)
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Top Workers */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h2 className="text-lg font-semibold mb-4">Top Rated Workers</h2>
            <div className="space-y-3">
              {analytics.topWorkers.length === 0 ? (
                <p className="text-sm text-gray-600">No verified workers yet</p>
              ) : (
                analytics.topWorkers.map((worker, idx) => (
                  <div key={worker.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex-1">
                      <p className="font-medium text-sm">{worker.name}</p>
                      <p className="text-xs text-gray-600">{worker.email}</p>
                    </div>
                    <div className="flex items-center gap-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star
                          key={i}
                          className={`w-3 h-3 ${
                            i < (worker.star_rating || 0) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Recent Signups */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h2 className="text-lg font-semibold mb-4">Recent Signups</h2>
            <div className="space-y-3">
              {analytics.recentSignups.length === 0 ? (
                <p className="text-sm text-gray-600">No recent signups</p>
              ) : (
                analytics.recentSignups.map((user) => (
                  <div key={user.id} className="p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <p className="font-medium text-sm">{user.name}</p>
                        <p className="text-xs text-gray-600">{user.email}</p>
                      </div>
                      <p className="text-xs text-gray-500">{new Date(user.created_at).toLocaleDateString()}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
