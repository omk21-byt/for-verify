"use client"

import { useState, useEffect } from "react"
import { Shield, CheckCircle2, XCircle, Star, Loader2, Search, Filter, MessageSquare, Save, X } from "lucide-react"

interface UserProfile {
  id: string
  name: string
  email: string
  expertise: string
  interests: string
  avatar_url: string
  star_rating: number
  skill_score: number
  verification_status: string
  admin_review_status: string
  selected_job: string
  profile_tags: Record<string, string>
  admin_feedback: string
  experience: string
  verified_skills: string[]
  profile_public: boolean
  created_at: string
}

export default function AdminProfilesClient() {
  const [profiles, setProfiles] = useState<UserProfile[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [filterStatus, setFilterStatus] = useState<"all" | "pending" | "approved" | "rejected">("all")
  const [selectedProfile, setSelectedProfile] = useState<UserProfile | null>(null)
  const [editingFeedback, setEditingFeedback] = useState("")
  const [isUpdating, setIsUpdating] = useState(false)

  useEffect(() => {
    fetchProfiles()
  }, [])

  const fetchProfiles = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/admin/profiles")
      if (!response.ok) throw new Error("Failed to fetch profiles")
      const data = await response.json()
      const sortedProfiles = data.profiles.sort((a: UserProfile, b: UserProfile) => {
        if (a.admin_review_status === "pending" && b.admin_review_status !== "pending") return -1
        if (a.admin_review_status !== "pending" && b.admin_review_status === "pending") return 1
        return new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
      })
      setProfiles(sortedProfiles)
    } catch (error) {
      console.error("[v0] Error fetching profiles:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleVerify = async (profileId: string, status: "approved" | "rejected") => {
    setIsUpdating(true)
    try {
      const response = await fetch("/api/admin/profiles/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: profileId,
          status,
          feedback: editingFeedback,
        }),
      })

      if (!response.ok) throw new Error("Failed to verify profile")

      const updatedProfile = await response.json()
      setProfiles(profiles.map((p) => (p.id === profileId ? updatedProfile : p)))
      setSelectedProfile(null)
      setEditingFeedback("")
    } catch (error) {
      console.error("[v0] Error verifying profile:", error)
    } finally {
      setIsUpdating(false)
    }
  }

  const handleUpdateFeedback = async (profileId: string, feedback: string) => {
    try {
      const response = await fetch("/api/admin/profiles/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: profileId,
          feedback,
        }),
      })

      if (!response.ok) throw new Error("Failed to update feedback")

      const updatedProfile = await response.json()
      setProfiles(profiles.map((p) => (p.id === profileId ? updatedProfile : p)))
      setSelectedProfile(updatedProfile)
    } catch (error) {
      console.error("[v0] Error updating feedback:", error)
    }
  }

  const filteredProfiles = profiles.filter((profile) => {
    const matchesSearch =
      profile.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      profile.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      profile.expertise.toLowerCase().includes(searchQuery.toLowerCase())

    const normalizedStatus = profile.admin_review_status === "pending_review" ? "pending" : profile.admin_review_status
    const matchesStatus =
      filterStatus === "all" ||
      normalizedStatus === filterStatus ||
      (filterStatus === "pending" && profile.admin_review_status === "pending_review")

    return matchesSearch && matchesStatus
  })

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="mx-auto max-w-7xl">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2 mb-2">
            <Shield className="w-8 h-8 text-indigo-600" />
            Admin Profile Management
          </h1>
          <p className="text-gray-600">Manage and verify user profiles</p>
        </div>

        {/* Search and Filter */}
        <div className="bg-white rounded-lg shadow-sm p-4 mb-6 space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Search by name, email, or expertise..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <Filter className="w-5 h-5 text-gray-400 mt-2" />
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value as any)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="all">All Profiles</option>
                <option value="pending">Pending Review</option>
                <option value="approved">Approved</option>
                <option value="rejected">Rejected</option>
              </select>
            </div>
          </div>
          <p className="text-sm text-gray-600">
            Showing {filteredProfiles.length} of {profiles.length} profiles
          </p>
        </div>

        {/* Profiles Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filteredProfiles.map((profile) => (
            <div
              key={profile.id}
              className={`bg-white rounded-lg shadow-sm border-2 transition-all cursor-pointer ${
                selectedProfile?.id === profile.id
                  ? "border-indigo-500 ring-2 ring-indigo-100"
                  : "border-gray-200 hover:border-indigo-300"
              }`}
              onClick={() => setSelectedProfile(profile)}
            >
              {/* Profile Header */}
              <div className="p-4 border-b bg-gradient-to-r from-gray-50 to-white">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3 flex-1">
                    <img
                      src={profile.avatar_url || "/placeholder.svg?height=48&width=48"}
                      alt={profile.name}
                      className="rounded-full w-12 h-12 object-cover bg-gray-200"
                    />
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-800 flex items-center gap-2">
                        {profile.name}
                        {profile.verification_status === "verified" && (
                          <CheckCircle2 className="w-4 h-4 text-blue-500" />
                        )}
                      </h3>
                      <p className="text-xs text-gray-600">{profile.email}</p>
                    </div>
                  </div>

                  {/* Status Badge */}
                  <div
                    className={`px-2 py-1 rounded-full text-xs font-medium ${
                      profile.admin_review_status === "approved"
                        ? "bg-green-100 text-green-700"
                        : profile.admin_review_status === "pending"
                          ? "bg-yellow-100 text-yellow-700"
                          : "bg-red-100 text-red-700"
                    }`}
                  >
                    {profile.admin_review_status.charAt(0).toUpperCase() + profile.admin_review_status.slice(1)}
                  </div>
                </div>

                {/* Job Title and Rating */}
                {profile.selected_job && (
                  <p className="text-sm font-medium text-indigo-600 mb-2">{profile.selected_job}</p>
                )}
                {profile.star_rating > 0 && (
                  <div className="flex items-center gap-2">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-3.5 h-3.5 ${
                          i < Math.round(profile.star_rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                        }`}
                      />
                    ))}
                    <span className="text-xs font-medium text-gray-700">{profile.star_rating}/5</span>
                  </div>
                )}
              </div>

              {/* Profile Info */}
              <div className="p-4 space-y-3">
                {/* Expertise */}
                {profile.expertise && (
                  <div>
                    <p className="text-xs font-semibold text-gray-600 uppercase mb-1">Expertise</p>
                    <p className="text-sm text-gray-700">{profile.expertise}</p>
                  </div>
                )}

                {/* Skills */}
                {profile.verified_skills && profile.verified_skills.length > 0 && (
                  <div>
                    <p className="text-xs font-semibold text-gray-600 uppercase mb-2">Verified Skills</p>
                    <div className="flex flex-wrap gap-2">
                      {profile.verified_skills.map((skill) => (
                        <span
                          key={skill}
                          className="text-xs bg-green-100 px-2 py-1 rounded-full text-green-700 font-medium"
                        >
                          ✓ {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Profile Tags */}
                {profile.profile_tags && Object.keys(profile.profile_tags).length > 0 && (
                  <div>
                    <p className="text-xs font-semibold text-gray-600 uppercase mb-2">Profile Tags</p>
                    <div className="flex flex-wrap gap-2">
                      {Object.entries(profile.profile_tags).map(([key, value]) => (
                        <span key={key} className="text-xs bg-indigo-100 px-2 py-1 rounded-full text-indigo-700">
                          {String(value)}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Skill Score */}
                {profile.skill_score > 0 && (
                  <div className="p-2 bg-blue-50 rounded-lg border border-blue-200">
                    <p className="text-xs text-blue-600 font-semibold">
                      Skill Score: <span className="text-sm text-blue-900 font-bold">{profile.skill_score}</span>
                    </p>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Detail Panel */}
        {selectedProfile && (
          <div className="fixed right-0 top-0 bottom-0 w-96 bg-white shadow-lg border-l border-gray-200 overflow-y-auto z-40">
            <div className="p-6 space-y-6">
              {/* Header */}
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-gray-900">Profile Details</h2>
                <button
                  onClick={() => setSelectedProfile(null)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              {/* Full Profile Info */}
              <div className="space-y-4">
                <div>
                  <img
                    src={selectedProfile.avatar_url || "/placeholder.svg?height=100&width=100"}
                    alt={selectedProfile.name}
                    className="rounded-lg w-full h-48 object-cover bg-gray-200"
                  />
                </div>

                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{selectedProfile.name}</h3>
                  <p className="text-sm text-gray-600">{selectedProfile.email}</p>
                </div>

                {selectedProfile.selected_job && (
                  <div>
                    <p className="text-xs font-semibold text-gray-600 uppercase mb-1">Job Profile</p>
                    <p className="text-sm font-medium text-indigo-600">{selectedProfile.selected_job}</p>
                  </div>
                )}

                {selectedProfile.expertise && (
                  <div>
                    <p className="text-xs font-semibold text-gray-600 uppercase mb-1">Expertise</p>
                    <p className="text-sm text-gray-700">{selectedProfile.expertise}</p>
                  </div>
                )}

                {selectedProfile.interests && (
                  <div>
                    <p className="text-xs font-semibold text-gray-600 uppercase mb-2">Interests</p>
                    <div className="flex flex-wrap gap-2">
                      {selectedProfile.interests.split(",").map((interest) => (
                        <span key={interest} className="text-xs bg-gray-100 px-2 py-1 rounded-full text-gray-700">
                          {interest.trim()}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {selectedProfile.experience && (
                  <div>
                    <p className="text-xs font-semibold text-gray-600 uppercase mb-1">Experience</p>
                    <p className="text-sm text-gray-700">{selectedProfile.experience}</p>
                  </div>
                )}
              </div>

              {/* Admin Feedback Section */}
              <div className="border-t pt-4">
                <p className="text-xs font-semibold text-gray-600 uppercase mb-2 flex items-center gap-1">
                  <MessageSquare className="w-3 h-3" />
                  Admin Feedback
                </p>
                <textarea
                  value={editingFeedback || selectedProfile.admin_feedback}
                  onChange={(e) => setEditingFeedback(e.target.value)}
                  placeholder="Add feedback for this user..."
                  className="w-full p-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-24"
                />
                <button
                  onClick={() =>
                    handleUpdateFeedback(selectedProfile.id, editingFeedback || selectedProfile.admin_feedback)
                  }
                  className="w-full mt-2 px-3 py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 font-medium rounded-lg transition text-sm"
                >
                  <Save className="w-4 h-4 inline mr-2" />
                  Save Feedback
                </button>
              </div>

              {/* Verification Actions */}
              {selectedProfile.admin_review_status !== "approved" && (
                <div className="border-t pt-4 space-y-2">
                  <button
                    onClick={() => handleVerify(selectedProfile.id, "approved")}
                    disabled={isUpdating}
                    className="w-full px-4 py-2 bg-green-100 hover:bg-green-200 text-green-700 font-medium rounded-lg transition disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {isUpdating ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                    Approve Profile
                  </button>
                </div>
              )}

              {selectedProfile.admin_review_status !== "rejected" && (
                <div className="space-y-2">
                  <button
                    onClick={() => handleVerify(selectedProfile.id, "rejected")}
                    disabled={isUpdating}
                    className="w-full px-4 py-2 bg-red-100 hover:bg-red-200 text-red-700 font-medium rounded-lg transition disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {isUpdating ? <Loader2 className="w-4 h-4 animate-spin" /> : <XCircle className="w-4 h-4" />}
                    Reject Profile
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
