import { redirect } from "next/navigation"
import { getServerClient } from "@/lib/supabase/server"
import AdminPortfolioVerificationClient from "./client"

export default async function AdminPortfolioVerificationPage() {
  const supabase = await getServerClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: userData } = await supabase.from("users").select("is_admin").eq("id", user.id).single()

  if (!userData?.is_admin) {
    redirect("/dashboard")
  }

  return <AdminPortfolioVerificationClient />
}
