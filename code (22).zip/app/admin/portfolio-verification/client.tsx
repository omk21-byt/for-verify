"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Star, Check, X, Loader2, LogOut, Home } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

interface UserProfile {
  id: string
  name: string
  email: string
  portfolio_url: string
  skill_score: number
  verified_skills: string[] | null
  verification_feedback: string
  admin_review_status: string
  admin_feedback: string
  selected_job: string
  profile_type: string
  star_rating: number
  experience: string
  expertise: string
  interests: string
  avatar_url: string
}

const PROFILE_TYPES = ["Freelancer", "Full-time", "Project-based"]

export default function AdminPortfolioVerificationClient() {
  const router = useRouter()
  const { toast } = useToast()

  const [profiles, setProfiles] = useState<UserProfile[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedProfile, setSelectedProfile] = useState<UserProfile | null>(null)
  const [starRating, setStarRating] = useState(5)
  const [feedback, setFeedback] = useState("")
  const [isApproving, setIsApproving] = useState(false)
  const [isRejecting, setIsRejecting] = useState(false)
  const [selectedJob, setSelectedJob] = useState("")
  const [selectedProfileType, setSelectedProfileType] = useState("")
  const [activeTab, setActiveTab] = useState("pending")

  useEffect(() => {
    fetchAllProfiles()
  }, [])

  const fetchAllProfiles = async () => {
    try {
      const response = await fetch("/api/admin/profiles")
      if (!response.ok) throw new Error("Failed to fetch profiles")

      const data = await response.json()
      setProfiles(data.profiles || [])
    } catch (error) {
      console.error("[v0] Fetch profiles error:", error)
      toast({
        title: "Error",
        description: "Failed to load profiles",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const pendingProfiles = profiles.filter((p) => p.admin_review_status === "pending_review")
  const verifiedProfiles = profiles.filter((p) => p.admin_review_status === "approved")
  const rejectedProfiles = profiles.filter((p) => p.admin_review_status === "rejected")

  const handleApprove = async () => {
    if (!selectedProfile) return

    if (!selectedJob || !selectedProfileType) {
      toast({
        title: "Incomplete",
        description: "Please select job title and profile type",
        variant: "destructive",
      })
      return
    }

    setIsApproving(true)
    try {
      const response = await fetch("/api/portfolio/approve", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: selectedProfile.id,
          starRating,
          adminFeedback: feedback,
          selectedJob,
          profileType: selectedProfileType,
        }),
      })

      if (!response.ok) throw new Error("Failed to approve")

      toast({
        title: "Success",
        description: `${selectedProfile.name} verified with ${starRating} stars`,
      })

      setProfiles((prev) =>
        prev.map((p) => (p.id === selectedProfile.id ? { ...p, admin_review_status: "approved" } : p)),
      )
      setSelectedProfile(null)
      setStarRating(5)
      setFeedback("")
      setSelectedJob("")
      setSelectedProfileType("")
    } catch (error) {
      console.error("[v0] Approval error:", error)
      toast({
        title: "Error",
        description: "Failed to approve profile",
        variant: "destructive",
      })
    } finally {
      setIsApproving(false)
    }
  }

  const handleReject = async () => {
    if (!selectedProfile) return

    setIsRejecting(true)
    try {
      const response = await fetch("/api/portfolio/reject", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: selectedProfile.id,
          rejectionReason: feedback,
        }),
      })

      if (!response.ok) throw new Error("Failed to reject")

      toast({
        title: "Success",
        description: `${selectedProfile.name} rejected`,
      })

      setProfiles((prev) =>
        prev.map((p) => (p.id === selectedProfile.id ? { ...p, admin_review_status: "rejected" } : p)),
      )
      setSelectedProfile(null)
      setFeedback("")
    } catch (error) {
      console.error("[v0] Rejection error:", error)
      toast({
        title: "Error",
        description: "Failed to reject profile",
        variant: "destructive",
      })
    } finally {
      setIsRejecting(false)
    }
  }

  const handleLogout = async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST" })
      router.push("/login")
    } catch (error) {
      console.error("[v0] Logout error:", error)
    }
  }

  const renderProfileCard = (profile: UserProfile) => (
    <Card key={profile.id} className="flex flex-col">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-lg">{profile.name}</CardTitle>
            <CardDescription>{profile.email}</CardDescription>
          </div>
          <Badge
            variant={
              profile.admin_review_status === "approved"
                ? "default"
                : profile.admin_review_status === "rejected"
                  ? "destructive"
                  : "secondary"
            }
          >
            {profile.admin_review_status?.toUpperCase() || "PENDING"}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="flex-1 space-y-3">
        {/* User Details */}
        {profile.experience && (
          <div>
            <p className="text-xs font-medium text-slate-500 uppercase mb-1">Experience</p>
            <p className="text-sm text-slate-700">{profile.experience}</p>
          </div>
        )}

        {profile.expertise && (
          <div>
            <p className="text-xs font-medium text-slate-500 uppercase mb-1">Expertise</p>
            <p className="text-sm text-slate-700">{profile.expertise}</p>
          </div>
        )}

        {profile.interests && (
          <div>
            <p className="text-xs font-medium text-slate-500 uppercase mb-1">Interests</p>
            <p className="text-sm text-slate-700">{profile.interests}</p>
          </div>
        )}

        {/* Portfolio Link */}
        {profile.portfolio_url && (
          <div>
            <p className="text-xs font-medium text-slate-500 uppercase mb-1">Portfolio</p>
            <a
              href={profile.portfolio_url}
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-600 hover:underline break-all text-sm"
            >
              View Portfolio
            </a>
          </div>
        )}

        {/* AI Score */}
        {profile.skill_score && (
          <div>
            <p className="text-xs font-medium text-slate-500 uppercase mb-1">AI Score</p>
            <div className="flex items-center gap-2">
              <div className="flex-1 h-2 bg-slate-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-blue-500 to-blue-600"
                  style={{ width: `${profile.skill_score}%` }}
                />
              </div>
              <span className="font-bold text-sm text-blue-600">{profile.skill_score}/100</span>
            </div>
          </div>
        )}

        {/* Verified Skills */}
        {profile.verified_skills?.length > 0 && (
          <div>
            <p className="text-xs font-medium text-slate-500 uppercase mb-1">Skills</p>
            <div className="flex flex-wrap gap-1">
              {profile.verified_skills.map((skill) => (
                <Badge key={skill} variant="outline" className="text-xs">
                  {skill}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Star Rating */}
        {profile.star_rating && (
          <div>
            <p className="text-xs font-medium text-slate-500 uppercase mb-1">Rating</p>
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  className={`w-4 h-4 ${
                    star <= profile.star_rating ? "fill-amber-400 text-amber-400" : "text-slate-300"
                  }`}
                />
              ))}
            </div>
          </div>
        )}

        {/* Review Dialog */}
        <Dialog
          open={selectedProfile?.id === profile.id}
          onOpenChange={(open) => {
            if (!open) {
              setSelectedProfile(null)
              setSelectedJob("")
              setSelectedProfileType("")
              setFeedback("")
            }
          }}
        >
          <DialogTrigger asChild>
            <Button
              onClick={() => {
                setSelectedProfile(profile)
                setStarRating(profile.star_rating || 5)
                setFeedback(profile.admin_feedback || "")
                setSelectedJob(profile.selected_job || "")
                setSelectedProfileType(profile.profile_type || "")
              }}
              className="w-full"
            >
              Review Profile
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Review {profile.name}'s Profile</DialogTitle>
              <DialogDescription>View all details and assign verification status</DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              {/* User Details Display */}
              <div className="bg-slate-50 p-3 rounded space-y-2 text-sm">
                {profile.experience && (
                  <div>
                    <span className="font-medium">Experience:</span> {profile.experience}
                  </div>
                )}
                {profile.expertise && (
                  <div>
                    <span className="font-medium">Expertise:</span> {profile.expertise}
                  </div>
                )}
                {profile.interests && (
                  <div>
                    <span className="font-medium">Interests:</span> {profile.interests}
                  </div>
                )}
              </div>

              {/* Star Rating */}
              <div>
                <label className="text-sm font-medium mb-2 block">Star Rating (1-5)</label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button key={star} onClick={() => setStarRating(star)} className="transition-all">
                      <Star
                        className={`w-6 h-6 ${star <= starRating ? "fill-amber-400 text-amber-400" : "text-slate-300"}`}
                      />
                    </button>
                  ))}
                </div>
              </div>

              {/* Assign Job Title */}
              <div>
                <label className="text-sm font-medium mb-2 block">Assign Job Title</label>
                <Select value={selectedJob} onValueChange={setSelectedJob}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select job title" />
                  </SelectTrigger>
                  <SelectContent>
                    {PROFILE_TYPES.map((job) => (
                      <SelectItem key={job} value={job}>
                        {job}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Assign Profile Type */}
              <div>
                <label className="text-sm font-medium mb-2 block">Assign Profile Type</label>
                <Select value={selectedProfileType} onValueChange={setSelectedProfileType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select profile type" />
                  </SelectTrigger>
                  <SelectContent>
                    {PROFILE_TYPES.map((type) => (
                      <SelectItem key={type} value={type}>
                        {type}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Admin Feedback */}
              <div>
                <label className="text-sm font-medium mb-2 block">Admin Feedback / Notes</label>
                <Textarea
                  value={feedback}
                  onChange={(e) => setFeedback(e.target.value)}
                  placeholder="Enter your feedback or rejection reason..."
                  rows={3}
                />
              </div>

              {/* Actions */}
              <div className="flex gap-2 pt-4">
                <Button
                  onClick={handleApprove}
                  disabled={isApproving || isRejecting}
                  className="flex-1 gap-2 bg-green-600 hover:bg-green-700"
                >
                  {isApproving ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Approving...
                    </>
                  ) : (
                    <>
                      <Check className="w-4 h-4" />
                      Approve & Verify
                    </>
                  )}
                </Button>
                <Button
                  onClick={handleReject}
                  disabled={isApproving || isRejecting}
                  variant="destructive"
                  className="flex-1 gap-2"
                >
                  {isRejecting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Rejecting...
                    </>
                  ) : (
                    <>
                      <X className="w-4 h-4" />
                      Reject
                    </>
                  )}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  )

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Profile Verification</h1>
            <p className="text-slate-600 mt-1">Manage and verify all user profiles</p>
          </div>
          <div className="flex gap-3">
            <Button onClick={() => router.push("/")} variant="outline" className="gap-2">
              <Home className="w-4 h-4" />
              Home
            </Button>
            <Button onClick={handleLogout} variant="outline" className="gap-2 bg-transparent">
              <LogOut className="w-4 h-4" />
              Logout
            </Button>
          </div>
        </div>

        {/* Tabs for Status */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
          <TabsList>
            <TabsTrigger value="pending">Pending ({pendingProfiles.length})</TabsTrigger>
            <TabsTrigger value="verified">Verified ({verifiedProfiles.length})</TabsTrigger>
            <TabsTrigger value="rejected">Rejected ({rejectedProfiles.length})</TabsTrigger>
          </TabsList>

          {/* Pending Tab */}
          <TabsContent value="pending" className="mt-6">
            {pendingProfiles.length === 0 ? (
              <Card className="border-2 border-dashed">
                <CardContent className="flex items-center justify-center py-12">
                  <p className="text-slate-600">No pending profiles</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {pendingProfiles.map(renderProfileCard)}
              </div>
            )}
          </TabsContent>

          {/* Verified Tab */}
          <TabsContent value="verified" className="mt-6">
            {verifiedProfiles.length === 0 ? (
              <Card className="border-2 border-dashed">
                <CardContent className="flex items-center justify-center py-12">
                  <p className="text-slate-600">No verified profiles</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {verifiedProfiles.map(renderProfileCard)}
              </div>
            )}
          </TabsContent>

          {/* Rejected Tab */}
          <TabsContent value="rejected" className="mt-6">
            {rejectedProfiles.length === 0 ? (
              <Card className="border-2 border-dashed">
                <CardContent className="flex items-center justify-center py-12">
                  <p className="text-slate-600">No rejected profiles</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {rejectedProfiles.map(renderProfileCard)}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
