"use client"

import { useEffect, useState, useRef, Suspense } from "react"
import { useRouter } from 'next/navigation'
import { Navbar } from "@/components/shiftza/navbar"
import LatestRolesSection from "@/components/shiftza/sections/latest-roles"
import { Hero } from "@/components/shiftza/landing/Hero"
import Footer from "@/components/Home/footer"
import FAQSection from "@/components/Home/faq-section"

export default function Page() {
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [loggingOut, setLoggingOut] = useState(false)
  const router = useRouter()

  useEffect(() => {
    const fetchSession = async () => {
      const res = await fetch("/api/auth/session")
      const data = await res.json()
      setUser(data?.user ?? null)
      setLoading(false)
    }
    fetchSession()
  }, [])

  const handleLogout = async () => {
    setLoggingOut(true)
    await fetch("/api/auth/logout", { method: "POST" })
    setUser(null)
    router.push("/")
    setLoggingOut(false)
  }

  return (
    <main className="min-h-dvh bg-white dark:bg-neutral-950 overflow-hidden">
      <div className="mx-auto max-w-7xl px-4 py-6 md:py-7">
        <Navbar user={user} loading={loading} />

        <Hero user={user} loading={loading} handleLogout={handleLogout} />

        <div className="mt-0">
          <Suspense fallback={<div className="text-center py-12 text-gray-500">Loading professionals...</div>}>
            <LatestRolesSection />
          </Suspense>
          <FAQSection />
        </div>
      </div>
      <Footer />
    </main>
  )
}
