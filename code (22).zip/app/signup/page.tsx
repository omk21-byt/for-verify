"use client"

import type React from "react"
import { useEffect, useState } from "react"
import { useToast } from "@/hooks/use-toast"
import Link from "next/link"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import VerifySkills from "@/components/VerifySkills/VerifySkills"
import { useRouter } from "next/navigation"

export default function SignupPage() {
  const { toast } = useToast()
  const router = useRouter()
  const [showVerifySkills, setShowVerifySkills] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    portfolio: "",
  })

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }, [])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const handleBasicSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(formData.email.trim())) {
      toast({
        title: "Invalid email",
        description: "Please enter a valid email address",
        variant: "destructive",
      })
      return
    }

    if (formData.password.length < 6) {
      toast({
        title: "Password too short",
        description: "Password must be at least 6 characters",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      const supabase = createClient()

      const { data, error } = await supabase.auth.signUp({
        email: formData.email.trim(),
        password: formData.password,
        options: {
          data: {
            name: formData.name.trim(),
            portfolio_url: formData.portfolio.trim(),
          },
          emailRedirectTo: process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL || window.location.origin,
        },
      })

      if (error) {
        console.error("[v0] signup error:", error)
        toast({
          title: "Signup failed",
          description: error.message || "Please try again",
          variant: "destructive",
        })
        return
      }

      if (!data.user) {
        toast({
          title: "Error",
          description: "Failed to create account",
          variant: "destructive",
        })
        return
      }

      sessionStorage.setItem("userId", data.user.id)
      sessionStorage.setItem("userData", JSON.stringify(formData))

      toast({
        title: "Profile created successfully",
        description: "Please verify your email and continue below.",
      })

      setShowVerifySkills(true)

      setTimeout(() => {
        const section = document.getElementById("verify-section")
        section?.scrollIntoView({ behavior: "smooth" })
      }, 300)
    } catch (error) {
      console.error("[v0] signup error:", error)
      toast({
        title: "Error",
        description: "Failed to create profile",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <main className="min-h-screen py-10 px-6 mt-0 pt-6 pb-0">
      <div className="max-w-3xl mx-auto mb-4">
        <Link
          href="/"
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors w-fit"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Home
        </Link>
      </div>

      {/* SIGNUP FORM SECTION */}
      <section className="max-w-3xl mx-auto bg-white border border-gray-200 rounded-2xl p-8 shadow-sm px-8 mt-0 mb-0 py-0 pt-6 pb-5">
        <h1 className="text-3xl font-semibold text-center mb-2">Create Your Skill Profile</h1>
        <p className="text-center text-sm text-muted-foreground mb-8">
          No degree or resume needed — show what you can actually do.
        </p>

        <form onSubmit={handleBasicSubmit} className="grid gap-4">
          <Input
            type="text"
            name="name"
            placeholder="Full Name"
            value={formData.name}
            onChange={handleChange}
            required
            disabled={isLoading}
          />
          <Input
            type="email"
            name="email"
            placeholder="you@example.com"
            value={formData.email}
            onChange={handleChange}
            required
            disabled={isLoading}
          />
          <Input
            type="password"
            name="password"
            placeholder="Create a strong password (min 6 characters)"
            value={formData.password}
            onChange={handleChange}
            required
            disabled={isLoading}
          />
          <Input
            type="url"
            name="portfolio"
            placeholder="Portfolio / Work Link (e.g. GitHub, Behance, etc.)"
            value={formData.portfolio}
            onChange={handleChange}
            disabled={isLoading}
          />

          <Button type="submit" className="rounded-full mt-4" disabled={isLoading}>
            {isLoading ? "Creating Profile..." : "Create Profile"}
          </Button>
        </form>

        <p className="mt-4 text-center text-sm text-muted-foreground">
          Already have an account?{" "}
          <Link href="/login" className="text-foreground underline">
            Log in
          </Link>
        </p>
      </section>

      {/* VERIFY SKILLS SECTION (hidden until created) */}
      {showVerifySkills && (
        <div id="verify-section" className="animate-fadeIn">
          <VerifySkills formData={formData} />
        </div>
      )}
    </main>
  )
}
