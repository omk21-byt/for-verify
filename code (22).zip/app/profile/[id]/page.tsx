"use client"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Star, Mail, ExternalLink, ArrowLeft, Globe, Heart } from "lucide-react"

interface PublicProfileDetail {
  id: string
  name: string
  email: string
  expertise: string
  interests: string
  experience: string
  portfolio_url: string
  avatar_url: string
  star_rating: number
  skill_score: number
  verification_status: string
  verified_skills: any[]
  admin_feedback: string
  admin_review_status?: string
}

export default function ProfilePage() {
  const router = useRouter()
  const params = useParams()
  const userId = params.id as string

  const [profile, setProfile] = useState<PublicProfileDetail | null>(null)
  const [loading, setLoading] = useState(true)
  const [isBookmarked, setIsBookmarked] = useState(false)
  const [currentUserId, setCurrentUserId] = useState<string>("")
  const [bookmarkLoading, setBookmarkLoading] = useState(false)

  useEffect(() => {
    const fetchSession = async () => {
      try {
        const res = await fetch("/api/auth/session")
        const data = await res.json()
        if (data.user?.id) {
          setCurrentUserId(data.user.id)
          await checkIfBookmarked(data.user.id)
        }
      } catch (error) {
        console.error("Failed to fetch session:", error)
      }
    }
    fetchSession()
  }, [userId])

  const checkIfBookmarked = async (currentId: string) => {
    try {
      const res = await fetch("/api/bookmarks")
      const data = await res.json()
      if (data.bookmarks) {
        const bookmarked = data.bookmarks.some((b: any) => b.bookmarked_user_id === userId)
        setIsBookmarked(bookmarked)
      }
    } catch (error) {
      console.error("Failed to check bookmark status:", error)
    }
  }

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const response = await fetch(`/api/profile/get?userId=${userId}`)
        if (!response.ok) throw new Error("Failed to fetch profile")

        const data = await response.json()

        // Check if profile is public or if user is viewing their own profile
        const sessionRes = await fetch("/api/auth/session")
        const sessionData = await sessionRes.json()
        const isOwnProfile = sessionData.user?.id === userId

        if (!data.user.profile_public && !isOwnProfile) {
          router.push("/search")
          return
        }

        setProfile(data.user)
      } catch (error) {
        console.error("[v0] Error fetching profile:", error)
        router.push("/search")
      } finally {
        setLoading(false)
      }
    }

    fetchProfile()
  }, [userId, router])

  const handleHire = () => {
    if (profile?.email) {
      window.location.href = `mailto:${profile.email}?subject=Hiring%20Opportunity`
    }
  }

  const handleBookmark = async () => {
    if (!currentUserId) {
      router.push("/login")
      return
    }

    if (currentUserId === userId) {
      alert("You cannot bookmark your own profile")
      return
    }

    setBookmarkLoading(true)
    try {
      if (isBookmarked) {
        // Remove bookmark
        const res = await fetch("/api/bookmarks")
        const data = await res.json()
        const bookmarkId = data.bookmarks.find((b: any) => b.bookmarked_user_id === userId)?.id

        if (bookmarkId) {
          await fetch(`/api/bookmarks/${bookmarkId}`, { method: "DELETE" })
          setIsBookmarked(false)
        }
      } else {
        // Add bookmark
        const res = await fetch("/api/bookmarks", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ bookmarkedUserId: userId }),
        })

        if (res.ok) {
          setIsBookmarked(true)

          // Create notification for bookmarked user
          await fetch("/api/notifications", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              user_id: userId,
              type: "bookmark",
              title: "New Bookmark",
              description: `${profile?.name} saved your profile`,
              related_user_id: currentUserId,
            }),
          })
        }
      }
    } catch (error) {
      console.error("Failed to toggle bookmark:", error)
      alert("Failed to update bookmark")
    } finally {
      setBookmarkLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
        <p className="text-gray-600">Loading profile...</p>
      </div>
    )
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
        <p className="text-gray-600">Profile not found</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 px-4 sm:px-6 lg:px-8 py-12">
      <div className="max-w-3xl mx-auto">
        {/* Back Button */}
        <Button onClick={() => router.push("/search")} variant="outline" className="mb-6 gap-2">
          <ArrowLeft className="w-4 h-4" />
          Back to Search
        </Button>

        {/* Profile Card */}
        <Card className="bg-white rounded-xl shadow-lg border-0 p-8 mb-8">
          <div className="flex items-start gap-8 mb-8">
            {/* Avatar */}
            <img
              src={profile.avatar_url || "/placeholder.svg?height=150&width=150"}
              alt={profile.name}
              className="w-32 h-32 rounded-xl object-cover bg-gray-200 flex-shrink-0"
            />

            {/* Profile Info */}
            <div className="flex-1">
              <h1 className="text-3xl font-bold text-gray-900 mb-2">{profile.name}</h1>

              {profile.admin_review_status === "approved" && (
                <div className="mb-2 inline-flex items-center gap-1 bg-purple-100 px-2 py-1 rounded-full">
                  <span className="text-xs font-semibold text-purple-600">✓ Admin Verified</span>
                </div>
              )}

              {/* Rating */}
              {profile.star_rating > 0 && (
                <div className="flex items-center gap-2 mb-4">
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-5 h-5 ${
                          i < Math.round(profile.star_rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-lg font-semibold text-gray-700">{profile.star_rating}/5</span>
                </div>
              )}

              {/* Badges */}
              <div className="flex gap-2 mb-6 flex-wrap">
                {profile.verification_status === "verified" && (
                  <span className="inline-flex items-center gap-2 px-4 py-2 bg-green-100 text-green-700 rounded-lg font-semibold">
                    <span className="w-2 h-2 bg-green-700 rounded-full"></span>
                    Verified
                  </span>
                )}
                {profile.skill_score >= 80 && (
                  <span className="inline-flex items-center gap-2 px-4 py-2 bg-blue-100 text-blue-700 rounded-lg font-semibold">
                    <span className="w-2 h-2 bg-blue-700 rounded-full"></span>
                    High Skill Score ({profile.skill_score})
                  </span>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3 flex-wrap">
                <Button onClick={handleHire} className="bg-indigo-600 hover:bg-indigo-700 text-white gap-2">
                  <Mail className="w-4 h-4" />
                  Hire Now
                </Button>
                <Button
                  onClick={handleBookmark}
                  disabled={bookmarkLoading}
                  className={`gap-2 ${
                    isBookmarked ? "bg-red-600 hover:bg-red-700 text-white" : "bg-gray-600 hover:bg-gray-700 text-white"
                  }`}
                >
                  <Heart className={`w-4 h-4 ${isBookmarked ? "fill-white" : ""}`} />
                  {isBookmarked ? "Saved" : "Save"}
                </Button>
                {profile.portfolio_url && (
                  <Button
                    onClick={() => window.open(profile.portfolio_url, "_blank")}
                    variant="outline"
                    className="gap-2"
                  >
                    <Globe className="w-4 h-4" />
                    View Portfolio
                  </Button>
                )}
              </div>
            </div>
          </div>
        </Card>

        {profile.portfolio_url && (
          <Card className="bg-white rounded-xl shadow-lg border-0 p-6 mb-8">
            <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
              <Globe className="w-5 h-5" />
              Portfolio
            </h3>
            <div className="space-y-4">
              <p className="text-gray-600">
                <a
                  href={profile.portfolio_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-indigo-600 hover:underline font-medium inline-flex items-center gap-1"
                >
                  {profile.portfolio_url}
                  <ExternalLink className="w-4 h-4" />
                </a>
              </p>
              <div
                className="relative w-full bg-gray-100 rounded-lg overflow-hidden"
                style={{ paddingBottom: "66.67%" }}
              >
                <iframe
                  src={profile.portfolio_url}
                  className="absolute top-0 left-0 w-full h-full border-0"
                  title={`${profile.name} Portfolio`}
                  sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
                />
              </div>
            </div>
          </Card>
        )}

        {/* Expertise & Interests */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {profile.expertise && (
            <Card className="bg-white rounded-xl shadow-lg border-0 p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Expertise</h3>
              <p className="text-gray-700 leading-relaxed">{profile.expertise}</p>
            </Card>
          )}

          {profile.interests && (
            <Card className="bg-white rounded-xl shadow-lg border-0 p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Interests</h3>
              <p className="text-gray-700 leading-relaxed">{profile.interests}</p>
            </Card>
          )}
        </div>

        {/* Experience */}
        {profile.experience && (
          <Card className="bg-white rounded-xl shadow-lg border-0 p-6 mb-8">
            <h3 className="text-lg font-bold text-gray-900 mb-4">Experience</h3>
            <p className="text-gray-700 leading-relaxed">{profile.experience}</p>
          </Card>
        )}

        {/* Admin Feedback */}
        {profile.admin_feedback && (
          <Card className="bg-green-50 border-2 border-green-200 rounded-xl p-6 mb-8">
            <h3 className="text-lg font-bold text-green-900 mb-2">Admin Feedback</h3>
            <p className="text-green-800">{profile.admin_feedback}</p>
          </Card>
        )}

        {/* Verified Skills */}
        {profile.verified_skills && profile.verified_skills.length > 0 && (
          <Card className="bg-white rounded-xl shadow-lg border-0 p-6">
            <h3 className="text-lg font-bold text-gray-900 mb-4">Verified Skills</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {profile.verified_skills.map((skill) => (
                <div key={skill.id} className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                  <p className="font-semibold text-blue-900">{skill.skill_name}</p>
                  {skill.proof_link && (
                    <a
                      href={skill.proof_link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm text-blue-600 hover:underline mt-2 inline-flex items-center gap-1"
                    >
                      View Proof
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                </div>
              ))}
            </div>
          </Card>
        )}
      </div>
    </div>
  )
}
