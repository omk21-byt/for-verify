"use client"

import { useEffect, useState } from "react"
import { useRouter } from 'next/navigation'
import { CheckCircle2, MessageSquare, Award, Heart, User } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { useAuth } from '@/app/providers'
import DashboardLayout from "@/components/dashboard/layout-wrapper"

interface Notification {
  id: string
  type: string
  title: string
  description?: string
  read: boolean
  created_at: string
  related_user_id?: string
}

export default function NotificationsPage() {
  const router = useRouter()
  const { user, loading: userLoading } = useAuth()
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (userLoading || !user) return

    const fetchNotifications = async () => {
      try {
        const res = await fetch(`/api/notifications?userId=${user.id}`)
        if (!res.ok) throw new Error("Failed to fetch notifications")
        const data = await res.json()
        setNotifications(data)
      } catch (error) {
        console.error("[v0] Error fetching notifications:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchNotifications()
    const interval = setInterval(fetchNotifications, 3000)
    return () => clearInterval(interval)
  }, [user, userLoading])

  const handleMarkAsRead = async (notificationId: string) => {
    try {
      await fetch(`/api/notifications/${notificationId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ read: true }),
      })
      setNotifications((prev) => prev.map((n) => (n.id === notificationId ? { ...n, read: true } : n)))
    } catch (error) {
      console.error("[v0] Error marking notification as read:", error)
    }
  }

  const handleMarkAllAsRead = async () => {
    if (!user) return
    try {
      await fetch("/api/notifications/mark-all-read", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: user.id }),
      })
      setNotifications((prev) => prev.map((n) => ({ ...n, read: true })))
    } catch (error) {
      console.error("[v0] Error marking all as read:", error)
    }
  }

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "message":
        return <MessageSquare className="w-5 h-5 text-blue-500" />
      case "skill_verified":
      case "profile_verified":
        return <CheckCircle2 className="w-5 h-5 text-green-500" />
      case "review":
        return <Award className="w-5 h-5 text-yellow-500" />
      case "bookmark":
        return <Heart className="w-5 h-5 text-red-500" />
      default:
        return <User className="w-5 h-5 text-gray-500" />
    }
  }

  if (userLoading || loading) {
    return (
      <DashboardLayout title="Notifications" description="Stay updated">
        <div className="flex items-center justify-center h-96">
          <p className="text-gray-600">Loading notifications...</p>
        </div>
      </DashboardLayout>
    )
  }

  const unreadCount = notifications.filter((n) => !n.read).length

  return (
    <DashboardLayout title="Notifications" description="Stay updated with your activity">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          {unreadCount > 0 && (
            <span className="bg-red-500 text-white rounded-full px-3 py-1 text-sm font-semibold">{unreadCount}</span>
          )}
        </div>
        {unreadCount > 0 && (
          <Button onClick={handleMarkAllAsRead} variant="outline" size="sm">
            Mark all as read
          </Button>
        )}
      </div>

      {notifications.length === 0 ? (
        <div className="bg-white rounded-xl border border-gray-200 p-12 text-center shadow-sm">
          <p className="text-gray-900 font-medium">No notifications yet</p>
          <p className="text-sm text-gray-600 mt-1">You're all caught up!</p>
        </div>
      ) : (
        <div className="space-y-3">
          {notifications.map((notification) => (
            <div
              key={notification.id}
              className={`p-4 rounded-xl border transition-colors cursor-pointer shadow-sm ${
                notification.read ? "bg-white border-gray-200 hover:bg-gray-50" : "bg-blue-50 border-blue-200"
              }`}
              onClick={() => !notification.read && handleMarkAsRead(notification.id)}
            >
              <div className="flex items-start gap-4">
                <div className="mt-1">{getNotificationIcon(notification.type)}</div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-gray-900">{notification.title}</h3>
                  {notification.description && (
                    <p className="text-gray-600 text-sm mt-1">{notification.description}</p>
                  )}
                  <p className="text-gray-500 text-xs mt-2">
                    {new Date(notification.created_at).toLocaleDateString()} {new Date(notification.created_at).toLocaleTimeString()}
                  </p>
                </div>
                {!notification.read && <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0" />}
              </div>
            </div>
          ))}
        </div>
      )}
    </DashboardLayout>
  )
}
