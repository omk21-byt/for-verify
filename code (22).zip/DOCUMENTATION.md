# Shiftza - Project Documentation

## Table of Contents
1. [Project Overview](#project-overview)
2. [System Architecture](#system-architecture)
3. [Database Schema](#database-schema)
4. [User Workflows](#user-workflows)
5. [Admin Workflows](#admin-workflows)
6. [API Routes Reference](#api-routes-reference)
7. [Components Overview](#components-overview)
8. [Verification System](#verification-system)

---

## Project Overview

**Shiftza** is an AI-verified skills talent platform that connects workers with global opportunities. The platform focuses on:

- **Profile Verification**: Users create profiles and fill in skills, experience, and proof
- **Admin Review**: Admins review and verify profiles before they appear in search
- **Skill Verification**: Only verified skills show as "Verified" after admin approval
- **Public Search**: Verified workers appear in search with comprehensive profiles
- **Job Matching**: AI-powered job profile suggestions based on skills

### Key Features
- User profile management with skill tracking
- Experience and proof submission system
- Admin verification dashboard
- Portfolio verification process
- Public search with filtering
- Profile visibility controls
- AI skill analysis

---

## System Architecture

### High-Level Flow

\`\`\`
User Registration
    ↓
Profile Creation & Skill Addition
    ↓
Experience & Proof Submission
    ↓
Profile Status: "Pending" (awaiting admin review)
    ↓
Admin Review at /admin/portfolio-verification
    ↓
Admin Approves Profile & Verifies Skills
    ↓
Profile Status: "Approved" + Skills Marked "Verified"
    ↓
Profile Appears in /search with "Verified" Badges
    ↓
User Can Edit Profile Anytime (Status Resets to "Pending")
\`\`\`

### Core Concepts

**Profile Status States:**
- `"pending"` - Waiting for admin review (initial state after profile creation/update)
- `"approved"` - Admin has verified all profile information
- `"rejected"` - Admin rejected the profile (user can edit and resubmit)

**Skill Verification:**
- Skills are stored in `user_skills` table with `verified: boolean` flag
- Skills only show "Verified" badge when `admin_review_status = "approved"` AND `skill.verified = true`
- Admin must explicitly verify skills during approval process

**Re-verification Flow:**
- When user edits any profile field and saves, `admin_review_status` resets to `"pending"`
- Profile must be re-reviewed by admin before verified badges reappear
- All skills remain in `user_skills` table but re-verification is required

---

## Database Schema

### Table: `users`

Main user profile table storing all user information.

| Column | Type | Description |
|--------|------|-------------|
| `id` | UUID | Primary key |
| `email` | VARCHAR | User email address |
| `name` | VARCHAR | User full name |
| `password_hash` | VARCHAR | Hashed password |
| `expertise` | TEXT | Main expertise area (e.g., "Data Analytics") |
| `interests` | TEXT | User interests and preferences |
| `portfolio_url` | VARCHAR | Link to user's portfolio |
| `experience` | TEXT | Years/description of work experience |
| `avatar_url` | VARCHAR | User profile avatar URL |
| `profile_type` | ENUM | User-defined profile type |
| `selected_job` | VARCHAR | Target job role |
| `admin_review_status` | VARCHAR | Status: "pending", "approved", "rejected" |
| `verification_status` | VARCHAR | Deprecated - use admin_review_status |
| `verified_skills` | JSONB | Array of skill names verified by admin |
| `skill_score` | INTEGER | AI-calculated skill score (0-100) |
| `star_rating` | INTEGER | User rating (0-5) |
| `profile_tags` | JSONB | Tags assigned by admin |
| `admin_feedback` | TEXT | Admin comments on profile |
| `verification_feedback` | TEXT | Feedback if profile rejected |
| `is_admin` | BOOLEAN | Whether user is admin |
| `profile_public` | BOOLEAN | Whether profile visible in search |
| `reviewed_by_admin` | UUID | ID of admin who reviewed profile |
| `reviewed_at` | TIMESTAMP | When profile was reviewed |
| `last_verified_at` | TIMESTAMP | When profile was last verified |
| `created_at` | TIMESTAMP | Account creation date |
| `updated_at` | TIMESTAMP | Last profile update |

**RLS Policies:**
- Users can INSERT/UPDATE/SELECT only their own profile
- Admins can access all profiles via API

### Table: `user_skills`

Stores individual skills with proof and verification status.

| Column | Type | Description |
|--------|------|-------------|
| `id` | UUID | Primary key |
| `user_id` | UUID | Foreign key to users table |
| `skill_name` | VARCHAR | Name of the skill (e.g., "SQL", "Python") |
| `verified` | BOOLEAN | Verified by admin (set during approval) |
| `proof_link` | VARCHAR | URL proving skill (GitHub, portfolio, etc) |
| `proof_description` | TEXT | User's description of how they proved skill |
| `created_at` | TIMESTAMP | When skill was added |

**RLS Policies:**
- Users can INSERT/UPDATE their own skills
- Users can SELECT their own skills

---

## User Workflows

### 1. User Registration & Profile Setup

**URL:** `/signup`

**Steps:**
1. User registers with email and password
2. API: `/api/auth/signup` creates user account
3. User enters basic info: name, expertise, interests
4. User selects skills from 29 categories
5. User provides learning source (where skills learned)
6. User confirms work experience status
7. User provides proof of skills (links + descriptions)
8. System suggests target job profiles based on skills
9. Profile saved with `admin_review_status: "pending"`

**API Calls:**
- `POST /api/auth/signup` - Register account
- `POST /api/dashboard/profile/update` - Save profile data

### 2. User Dashboard Overview

**URL:** `/dashboard/worker`

**Displays:**
- Welcome message with user name
- Portfolio Verification status
- Verification status card (pending/approved/rejected)
- Verified skills (only after admin approval)
- Activity & Progress section
- Profile visibility toggle
- Edit Profile button

**Data Sources:**
- `GET /api/dashboard/profile` - Loads user profile
- `GET /api/auth/session` - Gets current user

### 3. Edit Profile

**URL:** `/dashboard/worker/profile`

**Components:**
- **Basic Info Section**
  - Full name (text input)
  - Job title/Role (dropdown)
  - Portfolio URL (text input)
  - Expertise area (text)
  - Interests (text)

- **Skills Section**
  - Skill category selector (29 categories)
  - Search & add skills interface
  - Analyze Skills button (AI analysis)

- **Experience & Proof Section**
  - Learning source dropdown (self-taught, bootcamp, degree, etc)
  - Work experience status (Yes/No buttons)
  - Previous job description
  - Skill proof capability (Can you prove this skill?)
  - Analyze Experience button

- **Suggested Job Profiles**
  - Auto-generated list based on skills
  - Checkboxes to select target roles

- **Profile Completion Tracker**
  - Visual progress bar
  - Completion checklist

**Data Flow:**
1. User loads page → `GET /api/dashboard/profile` retrieves saved data
2. User makes changes to form
3. User clicks "Save Changes"
4. `POST /api/dashboard/profile/update` sends new data
5. API updates user record with new fields
6. API sets `admin_review_status: "pending"` (re-verification required)
7. API clears `verified_skills` array (skills must be re-verified)
8. API returns success/error message

### 4. Search Public Profiles

**URL:** `/search`

**Features:**
- Search for verified workers by name, skill, expertise
- Filter by verification status, star rating
- View profile cards with always-visible header:
  - Admin verified badge (if approved)
  - User name with checkmark
  - Job title
  - 5-star rating
  - "Approved" status badge
- Click "Show More Details" to expand and see:
  - Expertise and interests
  - Verified skills (only if profile approved)
  - Admin feedback
  - Suggested job profiles

**Data Source:**
- `GET /api/profiles/public` - Returns only approved profiles with verified_skills

### 5. Profile Visibility Control

**Feature:** Toggle profile visibility from dashboard

**API:** `POST /app/api/dashboard/toggle-visibility`

**States:**
- `profile_public: true` - Profile appears in search (if approved)
- `profile_public: false` - Profile hidden from search (private)

---

## Admin Workflows

### 1. Admin Portfolio Verification Dashboard

**URL:** `/admin/portfolio-verification`

**View:**
- List of pending portfolio submissions
- Search/filter by status, name, expertise
- Click profile to open detailed review dialog

**Dialog Contains:**
- User profile preview (all information)
- Job title selector (assign profile type)
- Profile type selector (role category)
- Assign Profile Tags (multi-select)
- Admin feedback text area
- Approve / Reject buttons

**Review Process:**
1. Admin clicks on pending profile
2. Dialog opens showing all profile information
3. Admin reviews:
   - User expertise and experience
   - Submitted skills and proof
   - Work experience details
4. Admin provides feedback (optional)
5. Admin assigns job title and profile type
6. Admin clicks "Approve"
7. API marks profile as approved and verifies skills

**API Endpoint:**
- `POST /api/portfolio/approve` - Approve profile and verify skills
- `POST /api/portfolio/reject` - Reject profile with feedback

### 2. Admin Profiles Dashboard

**URL:** `/admin/profiles`

**View:**
- All profiles (pending, approved, rejected)
- Tab filters for status
- Search by name
- Click profile to view details and edit

**Capabilities:**
- View complete profile information
- Edit any profile field
- Update admin feedback
- Change verification status
- View user audit trail (when reviewed, by whom)

**API:**
- `GET /api/admin/profiles/route` - Get all profiles
- `POST /api/admin/profiles/verify/route` - Verify profile
- `POST /api/admin/profiles/feedback/route` - Update feedback

### 3. Verification Logic

**When Admin Approves Profile:**

1. User's profile record updated:
   - `admin_review_status` = `"approved"`
   - `reviewed_at` = current timestamp
   - `reviewed_by_admin` = admin user ID

2. User's skills marked as verified:
   - All skills in `user_skills` table: `verified` = `true`
   - `verified_skills` JSONB array populated with skill names

3. Result:
   - Profile now visible in `/search`
   - Skills show with "Verified" badges
   - User can see "Approved" status in dashboard

**When Admin Rejects Profile:**

1. User's profile record updated:
   - `admin_review_status` = `"rejected"`
   - `verification_feedback` = admin's rejection reason

2. User sees:
   - "Rejected" status in dashboard
   - Admin feedback on why rejected
   - Can edit profile and resubmit for re-review

**When User Updates Profile:**

1. On save, API updates:
   - `admin_review_status` = `"pending"` (reset for re-review)
   - `verified_skills` = `[]` (clear verified array)
   - All user skills remain but `verified` = `false`

2. Result:
   - Profile removed from search (status not approved)
   - Verified badges disappear from dashboard
   - Profile must be re-reviewed by admin

---

## API Routes Reference

### Authentication Routes

#### `POST /api/auth/signup`
Register new user account
- **Body:** `{ email, password, name }`
- **Returns:** User object or error

#### `POST /api/auth/login`
Login user
- **Body:** `{ email, password }`
- **Returns:** Session token

#### `GET /api/auth/session`
Get current logged-in user
- **Returns:** User object or null

#### `POST /api/auth/logout`
Logout user
- **Returns:** Success message

### Profile Routes

#### `GET /api/dashboard/profile`
Get logged-in user's profile
- **Returns:** Full user object with all fields

#### `POST /api/dashboard/profile/update`
Update user profile and trigger re-verification
- **Body:** All profile fields to update
- **Side Effects:** Sets `admin_review_status` to "pending"
- **Returns:** Updated profile

#### `POST /api/dashboard/toggle-visibility`
Toggle profile visibility in search
- **Body:** `{ visible: boolean }`
- **Updates:** `profile_public` field

#### `GET /api/profiles/public`
Get all approved public profiles
- **Query:** `search`, `skills`, `expertise`, `rating`
- **Returns:** Array of profiles with verified_skills only

### Admin Routes

#### `GET /api/admin/profiles/route`
Get all profiles (admin only)
- **Query:** `status`, `search`
- **Returns:** All profiles with all fields

#### `POST /api/admin/profiles/verify/route`
Verify/approve a profile (admin only)
- **Body:** `{ userId, status, feedback }`
- **Side Effects:** Updates verified_skills, marks skills verified
- **Returns:** Updated profile

#### `POST /api/admin/profiles/feedback/route`
Update admin feedback on profile (admin only)
- **Body:** `{ userId, feedback }`
- **Returns:** Updated profile

#### `GET /api/admin/pending-portfolios/route`
Get all pending profiles awaiting review
- **Returns:** Array of pending profiles

### Portfolio Routes

#### `POST /api/portfolio/approve`
Approve portfolio and mark skills as verified
- **Body:** `{ userId, adminFeedback, jobTitle, profileType }`
- **Side Effects:** Sets all user skills to `verified: true`, populates `verified_skills` array
- **Returns:** Updated user profile

#### `POST /api/portfolio/reject`
Reject portfolio submission
- **Body:** `{ userId, feedback }`
- **Returns:** Updated profile with rejected status

### Skills Routes

#### `POST /api/skills/save`
Save user's skills
- **Body:** `{ skills: [{ name, proofLink, proofDescription }] }`
- **Updates:** `user_skills` table with `verified: false`
- **Returns:** Saved skills array

#### `GET /api/profile/get`
Get user profile by ID
- **Query:** `userId`
- **Returns:** User profile object

---

## Components Overview

### User Dashboard Components

#### ProfileCard (`/components/dashboard/ProfileCard.tsx`)
- Shows user info: name, email, avatar
- "Edit" button to go to profile editor
- Shows basic user identification

#### SkillVerificationCard (`/components/dashboard/SkillVerificationCard.tsx`)
- Displays user's skills
- Shows verification status: "Pending" or "✓ Verified"
- "View Proof" link for each skill (only if verified)

#### PortfolioVerificationCard (`/components/dashboard/PortfolioVerificationCard.tsx`)
- Shows portfolio verification status
- If pending: displays estimated review time
- Shows admin feedback if profile rejected
- Shows admin rating and skill score if approved

#### ActivityProgressCard (`/components/dashboard/ActivityProgressCard.tsx`)
- Portfolio status: pending/approved/rejected
- Last verified date
- Admin feedback display

### Profile Editor Components

#### SkillCategorySelector (`/components/Signup/skill-category-selector.tsx`)
- Browse 29 skill categories
- Search and add skills
- "Analyze Skills" button for AI analysis
- Profile preview updates as skills added

#### ExperienceSourceSelector (`/components/Signup/experience-source-selector.tsx`)
- "Where did you learn these skills?" dropdown
- Options: Self-taught, Bootcamp, Degree, Online Course, Work Experience
- "Have you worked in this field before?" Yes/No buttons
- "Can you prove this skill?" Yes/No buttons

#### SkillProofSelector (`/components/Signup/skill-proof-selector.tsx`)
- Input for proof link (GitHub, portfolio, etc)
- Text area for proof description
- "Analyze Experience" button
- "Verify Proof" button

#### JobProfileSelector (`/components/Signup/job-profile-selector.tsx`)
- Shows suggested job profiles based on skills
- Checkboxes to select target roles
- AI-powered job matching
- Selected jobs displayed in profile preview

### Search Page Components

#### ProfileSearchCard
- Always-visible header: name, title, rating, approved status
- Click "Show More Details" to expand
- Shows expertise, interests, verified skills (if approved)
- Admin feedback section (if approved)
- "View Portfolio" button links to portfolio URL
- "Hire" button for contacting user

### Admin Components

#### ProfileReviewDialog (`/app/admin/portfolio-verification/client.tsx`)
- User profile preview
- Job title selector
- Profile type selector
- Admin feedback textarea
- Assign profile tags
- Approve/Reject buttons

---

## Verification System

### Verification States Diagram

\`\`\`
User Creates/Updates Profile
    ↓
admin_review_status = "pending"
verified_skills = []
Skills have verified: false
    ↓
Admin Reviews at /admin/portfolio-verification
    ↓
    ├─→ Admin Clicks "Approve"
    │       ↓
    │   admin_review_status = "approved"
    │   verified_skills = ["SQL", "Python", ...]
    │   All skills: verified = true
    │   reviewed_at = now
    │       ↓
    │   Profile Appears in Search
    │   "Verified" badges show on skills
    │
    └─→ Admin Clicks "Reject"
            ↓
        admin_review_status = "rejected"
        verification_feedback = admin message
            ↓
        Profile Hidden from Search
        User Can Edit & Resubmit
\`\`\`

### Key Rules

1. **Profile Visibility in Search:**
   - Only shown if `admin_review_status === "approved"`
   - AND `profile_public === true`

2. **"Verified" Skill Badges:**
   - Show only if `admin_review_status === "approved"`
   - AND `skill.verified === true`

3. **Re-verification on Edit:**
   - Any profile field save → `admin_review_status` = "pending"
   - Skills reset to `verified: false`
   - `verified_skills` array cleared

4. **Admin Authority:**
   - Can approve/reject any profile
   - Can edit any profile field
   - Can assign tags and feedback
   - Can access all pending portfolios

---

## Data Persistence

### Profile Update Flow

\`\`\`
User saves profile in /dashboard/worker/profile
    ↓
POST /api/dashboard/profile/update
    ↓
API receives all form fields
    ↓
Update users table:
  - expertise
  - interests
  - portfolio_url
  - selected_job (career goal)
  - learning_source
  - has_work_experience
  - work_experience (description)
  - can_prove_skill
    ↓
Reset verification:
  - admin_review_status = "pending"
  - verified_skills = []
    ↓
Update user_skills table:
  - Keep existing skills but set verified: false
    ↓
Return updated profile to frontend
    ↓
Dashboard displays new data immediately
    ↓
User sees all fields saved and visible
\`\`\`

---

## Summary

**Shiftza** implements a complete skill verification system where:

1. **Users** create comprehensive profiles with skills, experience, and proof
2. **All data** persists immediately and displays on user dashboard
3. **Admin approval** is required before profile appears publicly
4. **Skills** only show as "Verified" after explicit admin approval
5. **Re-verification** is triggered on any profile update
6. **Admin** has complete authority over all verifications
7. **Users** can edit profiles anytime but must wait for re-verification

The system ensures data integrity and verified information in the public search while providing flexibility for users to update their profiles at any time.
