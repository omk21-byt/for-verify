-- Create trigger function to automatically create user profile on signup
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.users (
    id, 
    email, 
    name, 
    expertise, 
    interests, 
    portfolio_url, 
    experience,
    password_hash
  )
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data ->> 'name', ''),
    coalesce(new.raw_user_meta_data ->> 'expertise', ''),
    coalesce(new.raw_user_meta_data ->> 'interests', ''),
    coalesce(new.raw_user_meta_data ->> 'portfolio_url', ''),
    coalesce(new.raw_user_meta_data ->> 'experience', ''),
    'migrated'
  )
  on conflict (id) do nothing;

  return new;
end;
$$;

-- Drop existing trigger if it exists
drop trigger if exists on_auth_user_created on auth.users;

-- Create trigger on auth.users table
create trigger on_auth_user_created
  after insert on auth.users
  for each row
  execute function public.handle_new_user();
