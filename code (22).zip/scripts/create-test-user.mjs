import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseServiceKey);

const testEmail = 'test@example.com';
const testPassword = 'Test123456!';

async function createTestUser() {
  try {
    // Create auth user
    const { data: authData, error: authError } = await supabase.auth.admin.createUser({
      email: testEmail,
      password: testPassword,
      email_confirm: true,
    });

    if (authError) {
      console.error('Error creating auth user:', authError.message);
      return;
    }

    console.log('[v0] Auth user created:', authData.user.id);

    // Create corresponding user profile
    const { data: profileData, error: profileError } = await supabase
      .from('users')
      .insert({
        id: authData.user.id,
        email: testEmail,
        name: 'Test User',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });

    if (profileError) {
      console.error('Error creating user profile:', profileError.message);
      return;
    }

    console.log('[v0] Test user created successfully!');
    console.log(`Email: ${testEmail}`);
    console.log(`Password: ${testPassword}`);
  } catch (error) {
    console.error('Error:', error.message);
  }
}

createTestUser();
