-- Migration to ensure user_skills table has all AI verification columns
ALTER TABLE user_skills ADD COLUMN IF NOT EXISTS ai_score INTEGER DEFAULT 0;
ALTER TABLE user_skills ADD COLUMN IF NOT EXISTS ai_feedback TEXT;
ALTER TABLE user_skills ADD COLUMN IF NOT EXISTS verified_by_ai BOOLEAN DEFAULT false;
ALTER TABLE user_skills ADD COLUMN IF NOT EXISTS ai_verified_at TIMESTAMP;

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_user_skills_verified_by_ai ON user_skills(verified_by_ai);
CREATE INDEX IF NOT EXISTS idx_user_skills_ai_score ON user_skills(ai_score DESC);

-- Update any existing verified skills to have ai_verified_at timestamp
UPDATE user_skills 
SET ai_verified_at = CURRENT_TIMESTAMP 
WHERE verified_by_ai = true AND ai_verified_at IS NULL;
