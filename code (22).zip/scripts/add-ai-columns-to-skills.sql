-- Add AI verification columns to user_skills table
ALTER TABLE user_skills ADD COLUMN IF NOT EXISTS ai_score INTEGER DEFAULT 0;
ALTER TABLE user_skills ADD COLUMN IF NOT EXISTS ai_feedback TEXT;
ALTER TABLE user_skills ADD COLUMN IF NOT EXISTS verified_by_ai BOOLEAN DEFAULT false;
ALTER TABLE user_skills ADD COLUMN IF NOT EXISTS ai_verified_at TIMESTAMP;

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_user_skills_verified_by_ai ON user_skills(verified_by_ai);
