-- Create calendar_events table
CREATE TABLE IF NOT EXISTS public.calendar_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  date TEXT NOT NULL,
  type VARCHAR(50) NOT NULL CHECK (type IN ('job', 'skill', 'goal', 'ai')),
  title VARCHAR(255) NOT NULL,
  time VARCHAR(100) NOT NULL,
  created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITHOUT TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.calendar_events ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can view their own calendar events"
  ON public.calendar_events
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own calendar events"
  ON public.calendar_events
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own calendar events"
  ON public.calendar_events
  FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own calendar events"
  ON public.calendar_events
  FOR DELETE
  USING (auth.uid() = user_id);

-- Insert demo events
INSERT INTO public.calendar_events (user_id, date, type, title, time)
SELECT 
  id,
  date,
  type,
  title,
  time
FROM 
  public.users,
  (VALUES
    ('2025-11-05', 'job', 'Interview – Shiftza', '3:00 PM'),
    ('2025-11-05', 'goal', 'Prepare Portfolio', '1:30 PM'),
    ('2025-11-09', 'skill', 'Complete UX Design Module', 'All Day'),
    ('2025-11-14', 'goal', 'Upload Resume Update', '6:00 PM'),
    ('2025-11-14', 'job', 'Check Job Matches', '10:00 AM'),
    ('2025-11-17', 'ai', 'AI Suggested New Roles', 'Anytime'),
    ('2025-11-22', 'ai', 'AI Career Insights Generated', '8:00 PM'),
    ('2025-11-25', 'skill', 'Complete Skill Test', '11:00 AM')
  ) AS demo_data(date, type, title, time)
LIMIT 1;
