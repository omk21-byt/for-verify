-- Add profile_public column to users table to control profile visibility
ALTER TABLE users ADD COLUMN IF NOT EXISTS profile_public BOOLEAN DEFAULT FALSE;

-- Create an index for faster public profile queries
CREATE INDEX IF NOT EXISTS idx_users_profile_public ON users(profile_public) WHERE profile_public = TRUE;
