-- Drop existing RLS policies
DROP POLICY IF EXISTS "Users can view their own profile" ON users;
DROP POLICY IF EXISTS "Users can update their own profile" ON users;
DROP POLICY IF EXISTS "Users can view their own skills" ON user_skills;
DROP POLICY IF EXISTS "Users can insert their own skills" ON user_skills;

-- Create new RLS policies that allow authenticated users to manage their own data
CREATE POLICY "Allow users to insert their own profile"
  ON users FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Allow users to view their own profile"
  ON users FOR SELECT
  USING (true);

CREATE POLICY "Allow users to update their own profile"
  ON users FOR UPDATE
  USING (true);

CREATE POLICY "Allow users to view their own skills"
  ON user_skills FOR SELECT
  USING (true);

CREATE POLICY "Allow users to insert their own skills"
  ON user_skills FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Allow users to update their own skills"
  ON user_skills FOR UPDATE
  USING (true);
