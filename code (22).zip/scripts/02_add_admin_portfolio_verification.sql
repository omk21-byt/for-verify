-- Add admin review columns to users table
ALTER TABLE users
ADD COLUMN IF NOT EXISTS verification_status VARCHAR(20) DEFAULT 'pending',
ADD COLUMN IF NOT EXISTS admin_review_status VARCHAR(20) DEFAULT 'pending_review',
ADD COLUMN IF NOT EXISTS star_rating INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS reviewed_by_admin UUID,
ADD COLUMN IF NOT EXISTS reviewed_at TIMESTAMP,
ADD COLUMN IF NOT EXISTS admin_feedback TEXT,
ADD COLUMN IF NOT EXISTS is_admin BOOLEAN DEFAULT FALSE;

-- Create index for faster admin queries
CREATE INDEX IF NOT EXISTS idx_admin_review_status ON users(admin_review_status);
CREATE INDEX IF NOT EXISTS idx_reviewed_at ON users(reviewed_at DESC);
