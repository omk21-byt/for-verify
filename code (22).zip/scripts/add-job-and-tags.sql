-- Add new columns for job selection and profile tags
ALTER TABLE users
ADD COLUMN IF NOT EXISTS selected_job VARCHAR DEFAULT NULL,
ADD COLUMN IF NOT EXISTS profile_tags JSONB DEFAULT '[]'::jsonb,
ADD COLUMN IF NOT EXISTS profile_type VARCHAR DEFAULT NULL;

-- Create an enum for profile types
CREATE TYPE profile_type_enum AS ENUM ('Freelancer', 'Full-time', 'Project-based');

-- Drop and recreate the profile_type column with the correct type
ALTER TABLE users DROP COLUMN IF EXISTS profile_type CASCADE;
ALTER TABLE users ADD COLUMN profile_type profile_type_enum DEFAULT NULL;

-- Add comment to clarify the profile_tags structure
COMMENT ON COLUMN users.profile_tags IS 'JSON array of profile tags assigned by admin, e.g. ["Software Engineer", "Web Developer"]';
COMMENT ON COLUMN users.selected_job IS 'Job title or role selected by the user';
COMMENT ON COLUMN users.profile_type IS 'Type of profile: Freelancer, Full-time, or Project-based';
