-- Clean dump: Only runs if tables don't have policies yet
-- This prevents duplicate policy errors

-- Drop existing policies if they exist (safe way to recreate them)
DROP POLICY IF EXISTS "Users can view their own notifications" ON notifications;
DROP POLICY IF EXISTS "Users can update their own notifications" ON notifications;
DROP POLICY IF EXISTS "System can insert notifications" ON notifications;
DROP POLICY IF EXISTS "Users can view gallery items of public/verified profiles" ON portfolio_gallery;
DROP POLICY IF EXISTS "Users can manage their own gallery" ON portfolio_gallery;

-- Re-create the policies cleanly
CREATE POLICY "Users can view their own notifications"
  ON notifications FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own notifications"
  ON notifications FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "System can insert notifications"
  ON notifications FOR INSERT
  WITH CHECK (TRUE);

CREATE POLICY "Users can view gallery items of public/verified profiles"
  ON portfolio_gallery FOR SELECT
  USING (
    auth.uid() = user_id OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = user_id AND (is_public = true OR verified_status = 'verified')
    )
  );

CREATE POLICY "Users can manage their own gallery"
  ON portfolio_gallery FOR ALL
  USING (auth.uid() = user_id);
