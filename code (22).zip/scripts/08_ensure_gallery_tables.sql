-- Ensure portfolio_gallery table exists with proper structure
CREATE TABLE IF NOT EXISTS portfolio_gallery (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  media_url VARCHAR(500) NOT NULL,
  media_type VARCHAR(50) DEFAULT 'image', -- 'image', 'video', 'document'
  display_order INTEGER DEFAULT 0,
  is_featured BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE portfolio_gallery ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist (to avoid conflicts)
DROP POLICY IF EXISTS "Users can view gallery items of public/verified profiles" ON portfolio_gallery;
DROP POLICY IF EXISTS "Users can manage their own gallery" ON portfolio_gallery;

-- Portfolio gallery RLS policies
CREATE POLICY "Users can view gallery items of public/verified profiles"
  ON portfolio_gallery FOR SELECT
  USING (
    auth.uid() = user_id OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = user_id AND (is_public = true OR verified_status = 'verified')
    )
  );

CREATE POLICY "Users can manage their own gallery"
  ON portfolio_gallery FOR ALL
  USING (auth.uid() = user_id);

-- Create indexes for performance if they don't exist
CREATE INDEX IF NOT EXISTS idx_portfolio_gallery_user_id ON portfolio_gallery(user_id);
CREATE INDEX IF NOT EXISTS idx_portfolio_gallery_featured ON portfolio_gallery(is_featured);
