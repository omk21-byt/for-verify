-- Add portfolio verification columns to users table
ALTER TABLE users
ADD COLUMN IF NOT EXISTS skill_score INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS verified_skills JSONB DEFAULT '[]',
ADD COLUMN IF NOT EXISTS verification_status VARCHAR(20) DEFAULT 'pending',
ADD COLUMN IF NOT EXISTS last_verified_at TIMESTAMP,
ADD COLUMN IF NOT EXISTS verification_feedback TEXT;

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_verification_status ON users(verification_status);
